import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  Plus, Trash2, ChevronDown, ChevronUp, Settings2, Globe, Search, 
  Code2, Zap, Bot, Loader2, CheckCircle, AlertCircle, Eye, EyeOff,
  Wrench, Database, FileSearch, Link2, Webhook, Brain, Sparkles
} from 'lucide-react';

interface CustomApi {
  id: string;
  name: string;
  description: string;
  apiUrl: string;
  apiKey: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers: Record<string, string>;
  bodyTemplate: string;
  responseParser: string;
  enabled: boolean;
  category: 'ai' | 'scraper' | 'search' | 'tool' | 'webhook' | 'database';
}

interface AgenticCapability {
  id: string;
  name: string;
  description: string;
  triggerKeywords: string[];
  apiId: string;
  enabled: boolean;
  systemPromptAddition: string;
}

const CATEGORY_CONFIG = {
  ai: { label: 'AI Model', icon: Brain, color: 'text-purple-500', bgColor: 'bg-purple-500/10' },
  scraper: { label: 'Web Scraper', icon: FileSearch, color: 'text-blue-500', bgColor: 'bg-blue-500/10' },
  search: { label: 'Search Engine', icon: Search, color: 'text-green-500', bgColor: 'bg-green-500/10' },
  tool: { label: 'Tool/Utility', icon: Wrench, color: 'text-orange-500', bgColor: 'bg-orange-500/10' },
  webhook: { label: 'Webhook', icon: Webhook, color: 'text-pink-500', bgColor: 'bg-pink-500/10' },
  database: { label: 'Database', icon: Database, color: 'text-cyan-500', bgColor: 'bg-cyan-500/10' },
};

const UniversalApiConfig = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [customApis, setCustomApis] = useState<CustomApi[]>([]);
  const [agenticCapabilities, setAgenticCapabilities] = useState<AgenticCapability[]>([]);
  const [expandedApis, setExpandedApis] = useState<Record<string, boolean>>({});
  const [expandedCapabilities, setExpandedCapabilities] = useState<Record<string, boolean>>({});
  const [showApiKeys, setShowApiKeys] = useState<Record<string, boolean>>({});
  const [testingApi, setTestingApi] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { success: boolean; message: string }>>({});

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const [apisResult, capabilitiesResult] = await Promise.all([
        supabase.from('site_settings').select('value').eq('key', 'custom_apis').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'agentic_capabilities').maybeSingle()
      ]);

      if (apisResult.data?.value) {
        const apisValue = apisResult.data.value;
        if (Array.isArray(apisValue)) {
          setCustomApis(apisValue as unknown as CustomApi[]);
        }
      }

      if (capabilitiesResult.data?.value) {
        const capValue = capabilitiesResult.data.value;
        if (Array.isArray(capValue)) {
          setAgenticCapabilities(capValue as unknown as AgenticCapability[]);
        }
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({ title: 'Error', description: 'Failed to load settings', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const saveSettings = async () => {
    setIsSaving(true);
    try {
      // Convert to JSON-safe format
      const apisToSave = JSON.parse(JSON.stringify(customApis));
      const capabilitiesToSave = JSON.parse(JSON.stringify(agenticCapabilities));

      const { error: apiError } = await supabase
        .from('site_settings')
        .upsert({ 
          key: 'custom_apis', 
          value: apisToSave, 
          updated_at: new Date().toISOString() 
        }, { onConflict: 'key' });

      if (apiError) throw apiError;

      const { error: capError } = await supabase
        .from('site_settings')
        .upsert({ 
          key: 'agentic_capabilities', 
          value: capabilitiesToSave, 
          updated_at: new Date().toISOString() 
        }, { onConflict: 'key' });

      if (capError) throw capError;

      toast({ title: 'Settings Saved', description: 'Universal API configuration saved successfully.' });
    } catch (error: any) {
      console.error('Save error:', error);
      toast({ title: 'Error', description: error.message || 'Failed to save settings', variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  const addCustomApi = () => {
    const newApi: CustomApi = {
      id: `api_${Date.now()}`,
      name: '',
      description: '',
      apiUrl: '',
      apiKey: '',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      bodyTemplate: '{}',
      responseParser: 'data',
      enabled: true,
      category: 'tool',
    };
    setCustomApis([...customApis, newApi]);
    setExpandedApis({ ...expandedApis, [newApi.id]: true });
  };

  const removeCustomApi = (id: string) => {
    setCustomApis(customApis.filter(api => api.id !== id));
    setAgenticCapabilities(agenticCapabilities.filter(cap => cap.apiId !== id));
  };

  const updateCustomApi = (id: string, updates: Partial<CustomApi>) => {
    setCustomApis(customApis.map(api => api.id === id ? { ...api, ...updates } : api));
  };

  const addAgenticCapability = () => {
    const newCapability: AgenticCapability = {
      id: `cap_${Date.now()}`,
      name: '',
      description: '',
      triggerKeywords: [],
      apiId: '',
      enabled: true,
      systemPromptAddition: '',
    };
    setAgenticCapabilities([...agenticCapabilities, newCapability]);
    setExpandedCapabilities({ ...expandedCapabilities, [newCapability.id]: true });
  };

  const removeAgenticCapability = (id: string) => {
    setAgenticCapabilities(agenticCapabilities.filter(cap => cap.id !== id));
  };

  const updateAgenticCapability = (id: string, updates: Partial<AgenticCapability>) => {
    setAgenticCapabilities(agenticCapabilities.map(cap => cap.id === id ? { ...cap, ...updates } : cap));
  };

  const testApi = async (api: CustomApi) => {
    setTestingApi(api.id);
    setTestResults({ ...testResults, [api.id]: { success: false, message: 'Testing...' } });

    try {
      const headers: Record<string, string> = { ...api.headers };
      if (api.apiKey) {
        headers['Authorization'] = `Bearer ${api.apiKey}`;
      }

      const response = await fetch(api.apiUrl, {
        method: api.method,
        headers,
        body: api.method !== 'GET' ? api.bodyTemplate : undefined,
      });

      if (response.ok) {
        setTestResults({
          ...testResults,
          [api.id]: { success: true, message: `✅ API is working! Status: ${response.status}` }
        });
        toast({ title: 'API Test Successful', description: `${api.name} is responding correctly.` });
      } else {
        const errorText = await response.text().catch(() => '');
        setTestResults({
          ...testResults,
          [api.id]: { success: false, message: `❌ Failed: ${response.status} - ${errorText.substring(0, 100)}` }
        });
        toast({ title: 'API Test Failed', description: `Status: ${response.status}`, variant: 'destructive' });
      }
    } catch (error: any) {
      setTestResults({
        ...testResults,
        [api.id]: { success: false, message: `❌ Error: ${error.message}` }
      });
      toast({ title: 'API Test Error', description: error.message, variant: 'destructive' });
    } finally {
      setTestingApi(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-muted-foreground p-4">
        <Loader2 className="h-4 w-4 animate-spin" />
        Loading configuration...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Custom APIs Section */}
      <Card className="glass border-secondary/50">
        <CardHeader className="pb-3 sm:pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
                <Globe className="h-5 w-5 text-primary flex-shrink-0" />
                <span>Universal APIs</span>
              </CardTitle>
              <CardDescription className="text-sm mt-1">
                Add any API for AI models, web scrapers, search engines, and more
              </CardDescription>
            </div>
            <Button onClick={addCustomApi} size="sm" className="flex-shrink-0">
              <Plus className="h-4 w-4 mr-2" />
              Add API
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {customApis.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Code2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No custom APIs configured yet.</p>
              <p className="text-xs mt-1">Click "Add API" to connect your first API.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {customApis.map((api) => {
                const CategoryIcon = CATEGORY_CONFIG[api.category]?.icon || Globe;
                const categoryConfig = CATEGORY_CONFIG[api.category] || CATEGORY_CONFIG.tool;
                
                return (
                  <Collapsible
                    key={api.id}
                    open={expandedApis[api.id]}
                    onOpenChange={() => setExpandedApis({ ...expandedApis, [api.id]: !expandedApis[api.id] })}
                  >
                    <Card className={`border transition-all ${api.enabled ? 'border-border' : 'border-border/50 opacity-60'}`}>
                      <CollapsibleTrigger className="w-full">
                        <CardHeader className="p-3 sm:p-4 cursor-pointer">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                              <div className={`p-1.5 sm:p-2 rounded-lg ${categoryConfig.bgColor} flex-shrink-0`}>
                                <CategoryIcon className={`h-4 w-4 sm:h-5 sm:w-5 ${categoryConfig.color}`} />
                              </div>
                              <div className="text-left min-w-0 flex-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h4 className="font-semibold text-sm sm:text-base truncate">
                                    {api.name || 'Unnamed API'}
                                  </h4>
                                  <span className={`text-xs px-1.5 py-0.5 rounded ${categoryConfig.bgColor} ${categoryConfig.color}`}>
                                    {categoryConfig.label}
                                  </span>
                                </div>
                                <p className="text-xs text-muted-foreground truncate hidden sm:block">
                                  {api.description || api.apiUrl || 'No description'}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <Switch
                                checked={api.enabled}
                                onCheckedChange={(checked) => updateCustomApi(api.id, { enabled: checked })}
                                onClick={(e) => e.stopPropagation()}
                              />
                              {expandedApis[api.id] ? (
                                <ChevronUp className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                              ) : (
                                <ChevronDown className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                              )}
                            </div>
                          </div>
                        </CardHeader>
                      </CollapsibleTrigger>

                      <CollapsibleContent>
                        <CardContent className="pt-0 px-3 pb-3 sm:px-4 sm:pb-4 space-y-4">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label className="text-sm">API Name</Label>
                              <Input
                                placeholder="My Custom API"
                                value={api.name}
                                onChange={(e) => updateCustomApi(api.id, { name: e.target.value })}
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm">Category</Label>
                              <Select
                                value={api.category}
                                onValueChange={(value: CustomApi['category']) => updateCustomApi(api.id, { category: value })}
                              >
                                <SelectTrigger className="text-sm">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {Object.entries(CATEGORY_CONFIG).map(([key, config]) => (
                                    <SelectItem key={key} value={key}>
                                      <div className="flex items-center gap-2">
                                        <config.icon className={`h-4 w-4 ${config.color}`} />
                                        {config.label}
                                      </div>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm">Description</Label>
                            <Input
                              placeholder="What does this API do?"
                              value={api.description}
                              onChange={(e) => updateCustomApi(api.id, { description: e.target.value })}
                              className="text-sm"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                            <div className="space-y-2 sm:col-span-3">
                              <Label className="text-sm">API URL</Label>
                              <Input
                                placeholder="https://api.example.com/v1/endpoint"
                                value={api.apiUrl}
                                onChange={(e) => updateCustomApi(api.id, { apiUrl: e.target.value })}
                                className="text-sm font-mono"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm">Method</Label>
                              <Select
                                value={api.method}
                                onValueChange={(value: CustomApi['method']) => updateCustomApi(api.id, { method: value })}
                              >
                                <SelectTrigger className="text-sm">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="GET">GET</SelectItem>
                                  <SelectItem value="POST">POST</SelectItem>
                                  <SelectItem value="PUT">PUT</SelectItem>
                                  <SelectItem value="DELETE">DELETE</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm flex items-center gap-2">
                              API Key <span className="text-xs text-muted-foreground">(Optional)</span>
                            </Label>
                            <div className="relative">
                              <Input
                                type={showApiKeys[api.id] ? 'text' : 'password'}
                                placeholder="Enter API key..."
                                value={api.apiKey}
                                onChange={(e) => updateCustomApi(api.id, { apiKey: e.target.value })}
                                className="text-sm pr-10"
                              />
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                                onClick={() => setShowApiKeys({ ...showApiKeys, [api.id]: !showApiKeys[api.id] })}
                              >
                                {showApiKeys[api.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </Button>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm">Request Body Template (JSON)</Label>
                            <Textarea
                              placeholder='{"prompt": "{{message}}", "max_tokens": 1000}'
                              value={api.bodyTemplate}
                              onChange={(e) => updateCustomApi(api.id, { bodyTemplate: e.target.value })}
                              className="text-sm font-mono min-h-[80px]"
                            />
                            <p className="text-xs text-muted-foreground">
                              Use <code className="bg-muted px-1 rounded">{'{{message}}'}</code> for user input, <code className="bg-muted px-1 rounded">{'{{context}}'}</code> for chat history
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm">Response Path</Label>
                            <Input
                              placeholder="data.choices[0].message.content"
                              value={api.responseParser}
                              onChange={(e) => updateCustomApi(api.id, { responseParser: e.target.value })}
                              className="text-sm font-mono"
                            />
                            <p className="text-xs text-muted-foreground">
                              JSON path to extract the response (e.g., <code className="bg-muted px-1 rounded">data.text</code>)
                            </p>
                          </div>

                          {testResults[api.id] && (
                            <div className={`p-3 rounded-lg border ${
                              testResults[api.id].success 
                                ? 'bg-green-500/10 border-green-500/20' 
                                : 'bg-destructive/10 border-destructive/20'
                            }`}>
                              <div className={`flex items-center gap-2 text-sm ${
                                testResults[api.id].success ? 'text-green-600 dark:text-green-400' : 'text-destructive'
                              }`}>
                                {testResults[api.id].success ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                                <span className="font-medium">{testResults[api.id].message}</span>
                              </div>
                            </div>
                          )}

                          <div className="flex flex-col sm:flex-row gap-2 pt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => testApi(api)}
                              disabled={testingApi === api.id || !api.apiUrl}
                              className="flex-1"
                            >
                              {testingApi === api.id ? (
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              ) : (
                                <Zap className="h-4 w-4 mr-2" />
                              )}
                              Test API
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => removeCustomApi(api.id)}
                              className="flex-1 sm:flex-none"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Remove
                            </Button>
                          </div>
                        </CardContent>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Agentic Capabilities Section */}
      <Card className="glass border-secondary/50">
        <CardHeader className="pb-3 sm:pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
                <Sparkles className="h-5 w-5 text-primary flex-shrink-0" />
                <span>Agentic Capabilities</span>
              </CardTitle>
              <CardDescription className="text-sm mt-1">
                Define when the chatbot should use specific APIs based on user intent
              </CardDescription>
            </div>
            <Button onClick={addAgenticCapability} size="sm" className="flex-shrink-0" disabled={customApis.length === 0}>
              <Plus className="h-4 w-4 mr-2" />
              Add Capability
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {agenticCapabilities.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Bot className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No agentic capabilities configured yet.</p>
              <p className="text-xs mt-1">
                {customApis.length === 0 
                  ? 'Add a custom API first, then create capabilities.'
                  : 'Click "Add Capability" to define chatbot behaviors.'
                }
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {agenticCapabilities.map((capability) => {
                const linkedApi = customApis.find(api => api.id === capability.apiId);
                
                return (
                  <Collapsible
                    key={capability.id}
                    open={expandedCapabilities[capability.id]}
                    onOpenChange={() => setExpandedCapabilities({ 
                      ...expandedCapabilities, 
                      [capability.id]: !expandedCapabilities[capability.id] 
                    })}
                  >
                    <Card className={`border transition-all ${capability.enabled ? 'border-border' : 'border-border/50 opacity-60'}`}>
                      <CollapsibleTrigger className="w-full">
                        <CardHeader className="p-3 sm:p-4 cursor-pointer">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                              <div className="p-1.5 sm:p-2 rounded-lg bg-primary/10 flex-shrink-0">
                                <Bot className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                              </div>
                              <div className="text-left min-w-0 flex-1">
                                <h4 className="font-semibold text-sm sm:text-base truncate">
                                  {capability.name || 'Unnamed Capability'}
                                </h4>
                                <p className="text-xs text-muted-foreground truncate hidden sm:block">
                                  {linkedApi ? `Uses: ${linkedApi.name}` : 'No API linked'}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <Switch
                                checked={capability.enabled}
                                onCheckedChange={(checked) => updateAgenticCapability(capability.id, { enabled: checked })}
                                onClick={(e) => e.stopPropagation()}
                              />
                              {expandedCapabilities[capability.id] ? (
                                <ChevronUp className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                              ) : (
                                <ChevronDown className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                              )}
                            </div>
                          </div>
                        </CardHeader>
                      </CollapsibleTrigger>

                      <CollapsibleContent>
                        <CardContent className="pt-0 px-3 pb-3 sm:px-4 sm:pb-4 space-y-4">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label className="text-sm">Capability Name</Label>
                              <Input
                                placeholder="Web Search"
                                value={capability.name}
                                onChange={(e) => updateAgenticCapability(capability.id, { name: e.target.value })}
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label className="text-sm">Linked API</Label>
                              <Select
                                value={capability.apiId}
                                onValueChange={(value) => updateAgenticCapability(capability.id, { apiId: value })}
                              >
                                <SelectTrigger className="text-sm">
                                  <SelectValue placeholder="Select an API..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {customApis.map((api) => (
                                    <SelectItem key={api.id} value={api.id}>
                                      {api.name || 'Unnamed API'}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm">Description</Label>
                            <Input
                              placeholder="What this capability does..."
                              value={capability.description}
                              onChange={(e) => updateAgenticCapability(capability.id, { description: e.target.value })}
                              className="text-sm"
                            />
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm">Trigger Keywords</Label>
                            <Input
                              placeholder="search, find, look up, google (comma-separated)"
                              value={capability.triggerKeywords.join(', ')}
                              onChange={(e) => updateAgenticCapability(capability.id, { 
                                triggerKeywords: e.target.value.split(',').map(k => k.trim()).filter(Boolean)
                              })}
                              className="text-sm"
                            />
                            <p className="text-xs text-muted-foreground">
                              When users mention these words, this capability will be triggered
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm">System Prompt Addition</Label>
                            <Textarea
                              placeholder="Additional instructions for the AI when this capability is used..."
                              value={capability.systemPromptAddition}
                              onChange={(e) => updateAgenticCapability(capability.id, { systemPromptAddition: e.target.value })}
                              className="text-sm min-h-[80px]"
                            />
                          </div>

                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => removeAgenticCapability(capability.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Remove Capability
                          </Button>
                        </CardContent>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={saveSettings} disabled={isSaving} size="lg">
          {isSaving ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Settings2 className="h-4 w-4 mr-2" />
          )}
          Save All Configuration
        </Button>
      </div>
    </div>
  );
};

export default UniversalApiConfig;
