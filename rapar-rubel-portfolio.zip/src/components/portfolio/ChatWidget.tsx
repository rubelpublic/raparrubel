import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, X, Bot, User, Send, Loader2, Volume2, VolumeX, Mic, MicOff, Globe, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Language configuration with speech recognition codes and TTS voice IDs
const LANGUAGES = [
  { code: 'en-US', name: 'English', flag: '🇺🇸', voiceId: 'CwhRBWXzGAHq8TQ4Fs17' }, // Roger
  { code: 'es-ES', name: 'Español', flag: '🇪🇸', voiceId: 'pFZP5JQG7iQjIQuC4Bku' }, // Lily
  { code: 'fr-FR', name: 'Français', flag: '🇫🇷', voiceId: 'XrExE9yKIg1WjnnlVkGX' }, // Matilda
  { code: 'de-DE', name: 'Deutsch', flag: '🇩🇪', voiceId: 'onwK4e9ZLuTAKqWW03F9' }, // Daniel
  { code: 'pt-BR', name: 'Português', flag: '🇧🇷', voiceId: 'EXAVITQu4vr4xnSDxMaL' }, // Sarah
  { code: 'zh-CN', name: '中文', flag: '🇨🇳', voiceId: 'Xb7hH8MSUJpSbSDYk0k2' }, // Alice
  { code: 'ja-JP', name: '日本語', flag: '🇯🇵', voiceId: 'cgSgspJ2msm6clMCkdW9' }, // Jessica
  { code: 'ko-KR', name: '한국어', flag: '🇰🇷', voiceId: 'IKne3meq5aSn9XLyUdCD' }, // Charlie
  { code: 'ar-SA', name: 'العربية', flag: '🇸🇦', voiceId: 'nPczCjzI2devNBz1zQrb' }, // Brian
  { code: 'hi-IN', name: 'हिन्दी', flag: '🇮🇳', voiceId: 'TX3LPaxmHKxFdv7VOQHJ' }, // Liam
  { code: 'bn-BD', name: 'বাংলা', flag: '🇧🇩', voiceId: 'JBFqnCBsd6RMkjVDRZzb' }, // George
] as const;

type LanguageCode = typeof LANGUAGES[number]['code'];

// TypeScript declarations for Web Speech API
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognitionInterface extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onend: (() => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInterface;
    webkitSpeechRecognition?: new () => SpeechRecognitionInterface;
  }
}

interface ChatWidgetProps {
  isOpen: boolean;
  onToggle: () => void;
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;
const TTS_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/elevenlabs-tts`;

const ChatWidget = ({ isOpen, onToggle }: ChatWidgetProps) => {
  const { toast } = useToast();
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode>('en-US');
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hi! I'm Rubel's AI assistant. I can help you with:\n\n• **Strategy**: How Rubel scales businesses\n• **Services**: AI Automation & Marketing\n• **Hiring**: Book a meeting with Rubel\n• **Web Crawling**: Scrape any website or search the web\n\n🎤 Click the mic to talk, or 🔊 to hear responses!\n🌐 Select your language from the dropdown!\n\nHow can I help you today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<SpeechRecognitionInterface | null>(null);

  const currentLanguage = LANGUAGES.find(l => l.code === selectedLanguage) || LANGUAGES[0];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize and update speech recognition with selected language
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = selectedLanguage;

      recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('');
        setInput(transcript);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          toast({
            title: "Microphone Access Required",
            description: "Please enable microphone access to use voice input.",
            variant: "destructive",
          });
        }
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [toast, selectedLanguage]);

  const toggleListening = useCallback(() => {
    if (!recognitionRef.current) {
      toast({
        title: "Not Supported",
        description: "Speech recognition is not supported in your browser.",
        variant: "destructive",
      });
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setInput('');
      recognitionRef.current.start();
      setIsListening(true);
    }
  }, [isListening, toast]);

  const speakText = useCallback(async (text: string) => {
    if (isSpeaking && audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
      setIsSpeaking(false);
      return;
    }

    // Clean text for speech (remove markdown)
    const cleanText = text
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/#{1,6}\s/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\n+/g, '. ')
      .substring(0, 1000); // Limit for TTS

    try {
      setIsSpeaking(true);
      
      const response = await fetch(TTS_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ 
          text: cleanText,
          voiceId: currentLanguage.voiceId,
          languageCode: selectedLanguage,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate speech");
      }

      const data = await response.json();
      
      if (data.audioContent) {
        const audioUrl = `data:audio/mpeg;base64,${data.audioContent}`;
        audioRef.current = new Audio(audioUrl);
        audioRef.current.onended = () => setIsSpeaking(false);
        audioRef.current.onerror = () => setIsSpeaking(false);
        await audioRef.current.play();
      }
    } catch (error) {
      console.error("TTS error:", error);
      setIsSpeaking(false);
      toast({
        title: "Voice Error",
        description: "Failed to play audio response.",
        variant: "destructive",
      });
    }
  }, [isSpeaking, toast, currentLanguage.voiceId, selectedLanguage]);

  const fallbackResponses = [
    "Great question! Rubel specializes in bridging business strategy with technical execution. He's helped multiple startups scale through AI automation and data-driven decision making.",
    "Rubel's approach focuses on ownership and systems thinking. Whether it's building an ERP system or designing a marketing funnel, the goal is always measurable outcomes.",
    "I'd recommend booking a call with Rubel to discuss your specific needs. You can reach him at rubel.public@gmail.com or +880 1676 464807.",
    "Rubel has founded multiple ventures including Myook (fashion), Cha Khaben? (tea chain), and Bhangariwala (e-waste recycling). Each demonstrates his multidisciplinary expertise.",
    "For AI automation services, Rubel can help integrate LLMs into your operations, build automation workflows, and reduce redundancy in your processes.",
  ];

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    // Stop listening if active
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }

    const userMessage = input.trim();
    setInput("");
    const newUserMessage: Message = { role: "user", content: userMessage };
    setMessages((prev) => [...prev, newUserMessage]);
    setIsLoading(true);

    let assistantContent = "";

    try {
      let response: Response;
      
      try {
        response = await fetch(CHAT_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ 
            messages: [...messages, newUserMessage].map(m => ({
              role: m.role,
              content: m.content
            })),
            language: currentLanguage.name,
            languageCode: selectedLanguage,
          }),
        });
      } catch {
        const fallbackResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        setMessages((prev) => [...prev, { role: "assistant", content: fallbackResponse }]);
        if (autoSpeak) speakText(fallbackResponse);
        setIsLoading(false);
        return;
      }

      if (response.status === 402) {
        // AI quota exceeded - show friendly message
        const quotaMessage = "⚠️ **AI Service Temporarily Unavailable**\n\nThe AI assistant is currently at capacity. But don't worry! Here's what I know:\n\n" + 
          fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)] + 
          "\n\n📧 For immediate assistance, contact Rubel directly at **rubel.public@gmail.com**";
        setMessages((prev) => [...prev, { role: "assistant", content: quotaMessage }]);
        if (autoSpeak) speakText(quotaMessage);
        setIsLoading(false);
        return;
      }

      if (response.status === 429) {
        // Rate limited - show friendly message
        const rateLimitMessage = "⏳ **Too Many Requests**\n\nPlease wait a moment before sending another message. In the meantime:\n\n" +
          fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        setMessages((prev) => [...prev, { role: "assistant", content: rateLimitMessage }]);
        if (autoSpeak) speakText(rateLimitMessage);
        setIsLoading(false);
        return;
      }

      if (!response.ok) {
        const fallbackResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        setMessages((prev) => [...prev, { role: "assistant", content: fallbackResponse }]);
        if (autoSpeak) speakText(fallbackResponse);
        setIsLoading(false);
        return;
      }

      if (!response.body) {
        throw new Error("No response body");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";

      setMessages((prev) => [...prev, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) {
              assistantContent += content;
              setMessages((prev) => {
                const updated = [...prev];
                updated[updated.length - 1] = { 
                  role: "assistant", 
                  content: assistantContent 
                };
                return updated;
              });
            }
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      // Auto-speak the response if enabled
      if (autoSpeak && assistantContent) {
        speakText(assistantContent);
      }
    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive",
      });
      if (!assistantContent) {
        setMessages((prev) => prev.slice(0, -1));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const formatContent = (content: string) => {
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br/>');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="mb-4 w-[350px] md:w-[400px] h-[550px] glass border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-secondary p-4 border-b border-border flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <Bot className="text-primary-foreground w-5 h-5" />
                  </div>
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-secondary rounded-full" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground text-sm">Rubel AI Assistant</h3>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer py-0.5 px-1.5 rounded hover:bg-background/50">
                        <Globe className="w-3 h-3" />
                        <span>{currentLanguage.flag}</span>
                        <span>{currentLanguage.name}</span>
                        <ChevronDown className="w-3 h-3" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="max-h-[300px] overflow-y-auto z-[100]">
                      {LANGUAGES.map((lang) => (
                        <DropdownMenuItem
                          key={lang.code}
                          onClick={() => setSelectedLanguage(lang.code)}
                          className={`cursor-pointer ${selectedLanguage === lang.code ? 'bg-primary/10 text-primary' : ''}`}
                        >
                          <span className="mr-2">{lang.flag}</span>
                          <span>{lang.name}</span>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setAutoSpeak(!autoSpeak)}
                  className={`hover:bg-background/50 h-8 w-8 ${autoSpeak ? 'text-primary' : 'text-muted-foreground'}`}
                  title={autoSpeak ? "Auto-speak on" : "Auto-speak off"}
                >
                  {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </Button>
                <Button variant="ghost" size="icon" onClick={onToggle} className="hover:bg-background/50 h-8 w-8">
                  <X className="w-4 h-4 text-muted-foreground" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-background/50">
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === "assistant" ? "bg-primary/10" : "bg-secondary"
                    }`}
                  >
                    {message.role === "assistant" ? (
                      <Bot className="w-4 h-4 text-primary" />
                    ) : (
                      <User className="w-4 h-4 text-foreground" />
                    )}
                  </div>
                  <div className="flex flex-col gap-1 max-w-[80%]">
                    <div
                      className={`p-3 rounded-2xl text-sm ${
                        message.role === "assistant"
                          ? "bg-secondary text-secondary-foreground rounded-tl-none border border-border"
                          : "bg-primary text-primary-foreground rounded-tr-none"
                      }`}
                    >
                      <div 
                        className="whitespace-pre-line"
                        dangerouslySetInnerHTML={{ __html: formatContent(message.content) }}
                      />
                    </div>
                    {message.role === "assistant" && message.content && (
                      <button
                        onClick={() => speakText(message.content)}
                        className={`self-start flex items-center gap-1 text-xs px-2 py-1 rounded-full transition-colors ${
                          isSpeaking ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-primary hover:bg-primary/5'
                        }`}
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>{isSpeaking ? 'Playing...' : 'Listen'}</span>
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
              
              {isLoading && messages[messages.length - 1]?.content === "" && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                  <div className="bg-secondary p-3 rounded-2xl rounded-tl-none border border-border flex gap-1 items-center h-10">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 bg-card border-t border-border">
              <div className="relative flex items-center gap-2">
                <Button
                  size="icon"
                  variant={isListening ? "default" : "outline"}
                  onClick={toggleListening}
                  className={`h-9 w-9 flex-shrink-0 ${isListening ? 'bg-red-500 hover:bg-red-600 animate-pulse' : ''}`}
                  title={isListening ? "Stop listening" : "Start voice input"}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </Button>
                <div className="relative flex-1">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSend()}
                    placeholder={isListening ? "Listening..." : "Ask anything or scrape a URL..."}
                    className="bg-secondary border-border focus:border-primary pr-10"
                    disabled={isLoading}
                  />
                  <Button
                    size="icon"
                    onClick={handleSend}
                    disabled={isLoading || !input.trim()}
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 bg-primary hover:bg-primary/90 rounded-lg"
                  >
                    {isLoading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Send className="w-3.5 h-3.5" />
                    )}
                  </Button>
                </div>
              </div>
              {isListening && (
                <p className="text-xs text-muted-foreground mt-2 text-center animate-pulse">
                  🎤 Speak now... Click mic to stop
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        onClick={onToggle}
        className="group relative flex items-center justify-center w-14 h-14 bg-primary hover:bg-primary/90 rounded-full glow-primary transition-all duration-300"
      >
        <MessageSquare className="w-6 h-6 text-primary-foreground" />
      </motion.button>
    </div>
  );
};

export default ChatWidget;
