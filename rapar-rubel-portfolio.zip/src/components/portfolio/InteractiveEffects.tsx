import { useEffect, useState, useCallback, useRef } from 'react';
import { useInteractiveSounds, SoundTheme } from '@/hooks/useInteractiveSounds';

export const InteractiveEffects = () => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [soundTheme, setSoundTheme] = useState<SoundTheme>('space');
  const [isFirstInteraction, setIsFirstInteraction] = useState(true);
  
  const { playNote, initAudioContext } = useInteractiveSounds({
    enabled: soundEnabled,
    volume: 0.25,
    theme: soundTheme,
  });

  const handleInteraction = useCallback((clientX: number, clientY: number) => {
    // Initialize audio on first interaction
    if (isFirstInteraction) {
      initAudioContext();
      setIsFirstInteraction(false);
    }

    // Play sound
    playNote(clientX, clientY);
  }, [playNote, initAudioContext, isFirstInteraction]);

  useEffect(() => {
    const handleMouseDown = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('button, a, input, textarea, select, [role="button"], .no-sound')) {
        return;
      }
      handleInteraction(e.clientX, e.clientY);
    };

    const handleTouchStart = (e: TouchEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('button, a, input, textarea, select, [role="button"], .no-sound')) {
        return;
      }
      
      Array.from(e.changedTouches).forEach(touch => {
        handleInteraction(touch.clientX, touch.clientY);
      });
    };

    document.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('touchstart', handleTouchStart, { passive: true });

    return () => {
      document.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('touchstart', handleTouchStart);
    };
  }, [handleInteraction]);

  // Keyboard shortcut to toggle sound
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      if (e.key === 'm' && e.ctrlKey) {
        setSoundEnabled(prev => !prev);
      }
    };

    document.addEventListener('keydown', handleKeydown);
    return () => document.removeEventListener('keydown', handleKeydown);
  }, []);

  // Export state for external control
  useEffect(() => {
    (window as any).__setSoundEnabled = setSoundEnabled;
    (window as any).__getSoundEnabled = () => soundEnabled;
    (window as any).__setSoundTheme = setSoundTheme;
    (window as any).__getSoundTheme = () => soundTheme;
    return () => {
      delete (window as any).__setSoundEnabled;
      delete (window as any).__getSoundEnabled;
      delete (window as any).__setSoundTheme;
      delete (window as any).__getSoundTheme;
    };
  }, [soundEnabled, soundTheme]);

  return null;
};

export default InteractiveEffects;
