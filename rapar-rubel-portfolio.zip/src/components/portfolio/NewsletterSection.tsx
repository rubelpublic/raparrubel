import { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Zap, Brain, Rocket, Mail, Loader2, CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";

const emailSchema = z.string().trim().email("Please enter a valid email address").max(255);

const NewsletterSection = () => {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [error, setError] = useState("");

  const features = [
    {
      icon: Brain,
      title: "AI Insights",
      description: "Weekly deep-dives into practical AI applications for business",
    },
    {
      icon: Zap,
      title: "Automation Tips",
      description: "Step-by-step guides to automate your workflows",
    },
    {
      icon: Rocket,
      title: "Early Access",
      description: "Be the first to know about new tools and strategies",
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const result = emailSchema.safeParse(email);
    if (!result.success) {
      setError(result.error.errors[0].message);
      return;
    }

    setIsSubmitting(true);

    try {
      const { error: dbError } = await supabase.from("newsletter_subscribers").insert({
        email: result.data,
      });

      if (dbError) {
        if (dbError.code === "23505") {
          // Unique constraint violation - already subscribed
          toast({
            title: "Already subscribed!",
            description: "You're already on our AI revolution list.",
          });
          setIsSubscribed(true);
        } else {
          throw dbError;
        }
      } else {
        setIsSubscribed(true);
        setEmail("");
        toast({
          title: "Welcome to the AI Revolution!",
          description: "You'll receive our next newsletter soon.",
        });
      }
    } catch (err) {
      console.error("Newsletter subscription error:", err);
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Animated background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-[120px] animate-pulse animation-delay-2000" />
      
      <div className="max-w-6xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary animate-pulse" />
              <span className="text-sm font-bold text-primary">AI Revolution Newsletter</span>
            </div>

            <h2 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-6 leading-tight">
              Stay Ahead of the{" "}
              <span className="text-gradient">AI Revolution</span>
            </h2>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Get exclusive insights on how AI is transforming business strategy, 
              automation workflows, and growth systems. Join 500+ founders and 
              executives who are building the future.
            </p>

            {/* Features */}
            <div className="space-y-4">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-foreground">{feature.title}</h4>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right - Subscription Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <div className="glass p-8 rounded-3xl border border-border relative overflow-hidden">
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/20 to-transparent rounded-full blur-2xl" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-accent/20 to-transparent rounded-full blur-2xl" />

              {isSubscribed ? (
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="relative z-10 text-center py-8"
                >
                  <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-green-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-3">
                    You're In! 🚀
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Welcome to the AI revolution. Check your inbox for a confirmation 
                    and get ready for insights that will transform your business.
                  </p>
                  <div className="flex flex-wrap justify-center gap-2">
                    <span className="px-3 py-1 bg-primary/10 rounded-full text-xs font-bold text-primary">
                      #AIAutomation
                    </span>
                    <span className="px-3 py-1 bg-accent/10 rounded-full text-xs font-bold text-accent">
                      #BusinessStrategy
                    </span>
                    <span className="px-3 py-1 bg-emerald-500/10 rounded-full text-xs font-bold text-emerald-500">
                      #GrowthHacking
                    </span>
                  </div>
                </motion.div>
              ) : (
                <div className="relative z-10">
                  <div className="text-center mb-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                      <Mail className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-foreground mb-2">
                      Join the Newsletter
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      No spam, just valuable AI insights. Unsubscribe anytime.
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Input
                        type="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (error) setError("");
                        }}
                        placeholder="Enter your email"
                        className={`bg-secondary border-border focus:border-primary h-14 text-base ${error ? "border-red-500" : ""}`}
                        disabled={isSubmitting}
                      />
                      {error && <p className="text-xs text-red-500">{error}</p>}
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white rounded-xl font-bold text-base glow-primary hover:scale-[1.02] active:scale-[0.98] transition-all"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Subscribing...
                        </>
                      ) : (
                        <>
                          Subscribe Now
                          <ArrowRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </Button>
                  </form>

                  <p className="text-center text-xs text-muted-foreground/60 mt-4">
                    By subscribing, you agree to receive emails from Rubel Miah.
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default NewsletterSection;
