import { motion } from "framer-motion";
import { Mail, Phone, Linkedin, Facebook, Twitter, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";
import casualImage from "@/assets/rubel-casual.jpeg";

const Footer = () => {
  const socialLinks = [
    { icon: Linkedin, href: "https://www.linkedin.com/in/rubel-miah-a16706134" },
    { icon: Facebook, href: "https://www.facebook.com/share/1A6CLXujoi/?mibextid=wwXIfr" },
    { icon: Twitter, href: "https://x.com/raparrubel1" },
    { icon: Instagram, href: "https://www.instagram.com/rapar.rubel" },
  ];

  return (
    <footer className="bg-card border-t border-border pt-20 pb-10">
      <div className="max-w-6xl mx-auto px-6">
        {/* About Section with B&W Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-12 items-center mb-16"
        >
          {/* Image */}
          <div className="relative group mx-auto md:mx-0">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/30 to-accent/30 rounded-3xl blur-2xl opacity-50 group-hover:opacity-70 transition-opacity" />
            <div className="relative w-64 h-80 md:w-80 md:h-96 rounded-3xl overflow-hidden border border-border shadow-2xl">
              <img
                src={casualImage}
                alt="Rubel Miah"
                className="w-full h-full object-cover transition-all duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-60" />
            </div>
          </div>

          {/* Text Content */}
          <div className="text-center md:text-left">
            <h2 className="text-4xl font-display font-bold text-foreground mb-6">
              Ready to Scale?
            </h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              I focus on ownership, systems, and outcomes rather than titles. Whether you need strategic guidance, AI automation, or a full-stack growth partner—let's build something efficient together.
            </p>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <Button
                asChild
                className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl font-bold px-8 py-6 glow-primary hover:scale-105 active:scale-95 transition-all"
              >
                <a href="mailto:rubel.public@gmail.com">
                  <Mail className="w-5 h-5 mr-2" />
                  Reach Me
                </a>
              </Button>
              <Button
                asChild
                variant="secondary"
                className="bg-secondary hover:bg-secondary/80 text-secondary-foreground rounded-xl font-bold px-8 py-6 hover:scale-105 active:scale-95 transition-all"
              >
                <a href="tel:+8801676464807">
                  <Phone className="w-5 h-5 mr-2" />
                  Call Me
                </a>
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Social Links & Copyright */}
        <div className="border-t border-border pt-8">
          <div className="flex justify-center gap-8 mb-6">
            {socialLinks.map((social, index) => (
              <motion.a
                key={index}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="text-muted-foreground hover:text-foreground transition-colors hover:scale-110 transform"
              >
                <social.icon className="w-5 h-5" />
              </motion.a>
            ))}
          </div>

          <p className="text-muted-foreground/60 text-sm text-center">
            © 2026 Rubel Miah. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
