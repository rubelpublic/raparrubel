import { motion } from "framer-motion";
import { ShoppingBag, Coffee, Recycle, PenTool } from "lucide-react";

const ventures = [
  {
    name: "Myook",
    category: "Affordable Luxury Fashion",
    description: "A digital-first men's fashion brand focusing on branding, community building, and short-form content growth.",
    icon: ShoppingBag,
    color: "text-primary",
    bgColor: "text-primary/10",
  },
  {
    name: "Cha Khaben?",
    category: "Organic Tea Chain",
    description: "Positioning tea as a lifestyle experience. Built with a long-term vision of nationwide presence and global expansion.",
    icon: Coffee,
    color: "text-amber-500",
    bgColor: "text-amber-500/10",
  },
  {
    name: "Bhangariwala",
    category: "CleanTech / Sustainability",
    description: "E-waste recycling platform designed to create environmental impact through structured, technology-supported processes.",
    icon: Recycle,
    color: "text-emerald-500",
    bgColor: "text-emerald-500/10",
  },
  {
    name: "Bekkol",
    category: "Creative Marketing Agency",
    description: "Funny-smart, bold personality. Specializing in short-form content, brand voice creation, and culturally relevant communication.",
    icon: PenTool,
    color: "text-purple-500",
    bgColor: "text-purple-500/10",
  },
];

const VenturesSection = () => {
  return (
    <section id="ventures" className="py-24 max-w-7xl mx-auto px-6">
      <motion.h2
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className="text-3xl lg:text-4xl font-display font-bold text-foreground mb-12"
      >
        Founder-Led Ventures
      </motion.h2>

      <div className="grid md:grid-cols-2 gap-8">
        {ventures.map((venture, index) => (
          <motion.div
            key={venture.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="group relative bg-card rounded-3xl p-8 border border-border overflow-hidden hover-card-effect"
          >
            {/* Background Icon */}
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-700">
              <venture.icon className={`w-32 h-32 ${venture.color}`} />
            </div>

            <h3 className="text-2xl font-bold text-foreground mb-2">{venture.name}</h3>
            <div className={`${venture.color} text-xs font-bold uppercase tracking-wider mb-4`}>
              {venture.category}
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed relative z-10">
              {venture.description}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default VenturesSection;