import { motion, AnimatePresence } from "framer-motion";
import { X, Download, Mail, Phone, MapPin, Linkedin, Globe, Loader2, Award, Briefcase, GraduationCap, Star, Code, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useRef } from "react";
import { useCVData } from "@/hooks/useCVData";
import { Skeleton } from "@/components/ui/skeleton";
import rubelPhoto from "@/assets/rubel-profile.jpeg";

interface CVModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const A4_WIDTH_MM = 210;
const A4_HEIGHT_MM = 297;

const CVModal = ({ isOpen, onClose }: CVModalProps) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const cvRef = useRef<HTMLDivElement>(null);
  const {
    cvData,
    experience,
    education,
    certifications,
    skills,
    competencies,
    ventures,
    languages,
    isLoading,
  } = useCVData();

  const photoUrl = cvData?.photo_url || rubelPhoto;

  // Group skills by category
  const skillsByCategory = skills.reduce((acc, skill) => {
    const category = skill.category || 'Other';
    if (!acc[category]) acc[category] = [];
    acc[category].push(skill.name);
    return acc;
  }, {} as Record<string, string[]>);

  const handleDownloadPDF = async () => {
    if (!cvRef.current) return;
    
    setIsGenerating(true);
    
    try {
      const html2canvas = (await import('html2canvas')).default;
      const { jsPDF } = await import('jspdf');
      
      const canvas = await html2canvas(cvRef.current, {
        scale: 2.5,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        width: cvRef.current.scrollWidth,
        height: cvRef.current.scrollHeight,
      });
      
      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });
      
      const pdfWidth = A4_WIDTH_MM;
      const pdfHeight = A4_HEIGHT_MM;
      
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = pdfWidth / imgWidth;
      const scaledHeight = imgHeight * ratio;
      
      if (scaledHeight <= pdfHeight) {
        pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, scaledHeight);
      } else {
        let remainingHeight = scaledHeight;
        let position = 0;
        let pageNum = 0;
        
        while (remainingHeight > 0) {
          if (pageNum > 0) {
            pdf.addPage();
          }
          
          pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, scaledHeight);
          
          remainingHeight -= pdfHeight;
          position -= pdfHeight;
          pageNum++;
        }
      }
      
      const fileName = cvData?.full_name?.replace(/\s+/g, '_') || 'Professional_CV';
      pdf.save(`${fileName}_Resume.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-background/90 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white text-slate-900 rounded-2xl max-w-[900px] w-full max-h-[95vh] overflow-y-auto shadow-2xl relative"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-white border-b border-slate-200 p-4 flex justify-between items-center z-10">
            <h3 className="font-bold text-lg text-slate-800">Professional Resume</h3>
            <div className="flex gap-2">
              <Button 
                onClick={handleDownloadPDF} 
                size="sm" 
                className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white shadow-lg"
                disabled={isGenerating || isLoading}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating PDF...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Download A4 PDF
                  </>
                )}
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-slate-100">
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="p-8 space-y-4">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          ) : (
            <div 
              ref={cvRef} 
              style={{ 
                width: '210mm', 
                minHeight: '297mm', 
                backgroundColor: '#ffffff',
                fontFamily: 'Arial, Helvetica, sans-serif',
              }}
            >
              {/* Header Section with Gradient Background */}
              <header style={{ 
                background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0891b2 100%)',
                padding: '24px 28px',
                color: '#ffffff',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
                  {/* Profile Photo */}
                  <div style={{ flexShrink: 0 }}>
                    <img
                      src={photoUrl}
                      alt={cvData?.full_name || 'Profile Photo'}
                      crossOrigin="anonymous"
                      style={{
                        width: '110px',
                        height: '110px',
                        borderRadius: '50%',
                        objectFit: 'cover',
                        border: '4px solid rgba(255,255,255,0.3)',
                        boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
                      }}
                    />
                  </div>
                  
                  {/* Name and Title */}
                  <div style={{ flex: 1 }}>
                    <h1 style={{ 
                      fontSize: '32px', 
                      fontWeight: 'bold', 
                      margin: '0 0 6px 0',
                      letterSpacing: '-0.5px',
                      textShadow: '0 2px 4px rgba(0,0,0,0.2)'
                    }}>
                      {cvData?.full_name || 'Your Name'}
                    </h1>
                    <h2 style={{ 
                      fontSize: '16px', 
                      fontWeight: '500', 
                      color: '#67e8f9',
                      textTransform: 'uppercase',
                      letterSpacing: '2px',
                      margin: '0 0 16px 0'
                    }}>
                      {cvData?.title || 'Your Professional Title'}
                    </h2>
                    
                    {/* Contact Info Row */}
                    <div style={{ 
                      display: 'flex', 
                      flexWrap: 'wrap', 
                      gap: '16px', 
                      fontSize: '11px',
                      color: 'rgba(255,255,255,0.9)'
                    }}>
                      {cvData?.email && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ 
                            width: '20px', 
                            height: '20px', 
                            backgroundColor: 'rgba(255,255,255,0.15)', 
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>✉</span>
                          {cvData.email}
                        </span>
                      )}
                      {cvData?.phone && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ 
                            width: '20px', 
                            height: '20px', 
                            backgroundColor: 'rgba(255,255,255,0.15)', 
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>📱</span>
                          {cvData.phone}
                        </span>
                      )}
                      {cvData?.location && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ 
                            width: '20px', 
                            height: '20px', 
                            backgroundColor: 'rgba(255,255,255,0.15)', 
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>📍</span>
                          {cvData.location}
                        </span>
                      )}
                      {cvData?.linkedin_url && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ 
                            width: '20px', 
                            height: '20px', 
                            backgroundColor: 'rgba(255,255,255,0.15)', 
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>in</span>
                          {cvData.linkedin_url.replace('https://', '').replace('www.', '')}
                        </span>
                      )}
                      {cvData?.website_url && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ 
                            width: '20px', 
                            height: '20px', 
                            backgroundColor: 'rgba(255,255,255,0.15)', 
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>🌐</span>
                          {cvData.website_url.replace('https://', '').replace('www.', '')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </header>

              {/* Main Content */}
              <div style={{ padding: '20px 28px' }}>
                
                {/* Professional Summary */}
                {cvData?.summary && (
                  <section style={{ marginBottom: '20px' }}>
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '10px',
                      marginBottom: '10px'
                    }}>
                      <div style={{ 
                        width: '28px', 
                        height: '28px', 
                        backgroundColor: '#0891b2', 
                        borderRadius: '6px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff',
                        fontSize: '14px'
                      }}>★</div>
                      <h3 style={{ 
                        fontSize: '14px', 
                        fontWeight: 'bold', 
                        color: '#0f172a', 
                        textTransform: 'uppercase',
                        letterSpacing: '1px',
                        margin: 0
                      }}>
                        Professional Summary
                      </h3>
                    </div>
                    <p style={{ 
                      fontSize: '11px', 
                      color: '#475569', 
                      lineHeight: '1.7', 
                      margin: 0,
                      paddingLeft: '38px',
                      borderLeft: '3px solid #e2e8f0'
                    }}>
                      {cvData.summary}
                    </p>
                  </section>
                )}

                {/* Core Competencies - Horizontal Pills */}
                {competencies.length > 0 && (
                  <section style={{ marginBottom: '20px' }}>
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '10px',
                      marginBottom: '12px'
                    }}>
                      <div style={{ 
                        width: '28px', 
                        height: '28px', 
                        backgroundColor: '#8b5cf6', 
                        borderRadius: '6px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff',
                        fontSize: '14px'
                      }}>⚡</div>
                      <h3 style={{ 
                        fontSize: '14px', 
                        fontWeight: 'bold', 
                        color: '#0f172a', 
                        textTransform: 'uppercase',
                        letterSpacing: '1px',
                        margin: 0
                      }}>
                        Core Competencies
                      </h3>
                    </div>
                    <div style={{ 
                      display: 'grid', 
                      gridTemplateColumns: 'repeat(3, 1fr)', 
                      gap: '10px',
                      paddingLeft: '38px'
                    }}>
                      {competencies.map((comp) => (
                        <div
                          key={comp.id}
                          style={{ 
                            padding: '10px 12px', 
                            borderRadius: '8px',
                            background: comp.color === 'purple' ? 'linear-gradient(135deg, #f5f3ff 0%, #ede9fe 100%)' : 
                                       comp.color === 'green' ? 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)' :
                                       comp.color === 'orange' ? 'linear-gradient(135deg, #fff7ed 0%, #fed7aa 100%)' :
                                       comp.color === 'blue' ? 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)' :
                                       comp.color === 'pink' ? 'linear-gradient(135deg, #fdf2f8 0%, #fce7f3 100%)' : 
                                       'linear-gradient(135deg, #ecfeff 0%, #cffafe 100%)',
                            border: `1px solid ${comp.color === 'purple' ? '#c4b5fd' : 
                                                 comp.color === 'green' ? '#86efac' :
                                                 comp.color === 'orange' ? '#fdba74' :
                                                 comp.color === 'blue' ? '#93c5fd' :
                                                 comp.color === 'pink' ? '#f9a8d4' : '#67e8f9'}`
                          }}
                        >
                          <h4 style={{ fontSize: '10px', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>
                            {comp.title}
                          </h4>
                          {comp.subtitle && (
                            <p style={{ fontSize: '9px', color: '#64748b', margin: '3px 0 0 0' }}>
                              {comp.subtitle}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </section>
                )}

                {/* Two Column Layout */}
                <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '24px' }}>
                  
                  {/* Left Column */}
                  <div>
                    {/* Professional Experience */}
                    {experience.length > 0 && (
                      <section style={{ marginBottom: '20px' }}>
                        <div style={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: '10px',
                          marginBottom: '14px'
                        }}>
                          <div style={{ 
                            width: '28px', 
                            height: '28px', 
                            backgroundColor: '#059669', 
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '14px'
                          }}>💼</div>
                          <h3 style={{ 
                            fontSize: '14px', 
                            fontWeight: 'bold', 
                            color: '#0f172a', 
                            textTransform: 'uppercase',
                            letterSpacing: '1px',
                            margin: 0
                          }}>
                            Professional Experience
                          </h3>
                        </div>
                        
                        {experience.map((exp, index) => (
                          <div 
                            key={exp.id} 
                            style={{ 
                              marginBottom: '16px',
                              paddingLeft: '38px',
                              borderLeft: index === 0 ? '3px solid #059669' : '3px solid #e2e8f0',
                              paddingBottom: index === experience.length - 1 ? '0' : '16px'
                            }}
                          >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                              <div>
                                <h4 style={{ fontSize: '12px', fontWeight: 'bold', color: '#0f172a', margin: 0 }}>
                                  {exp.job_title}
                                </h4>
                                <p style={{ fontSize: '11px', fontWeight: '600', color: '#0891b2', margin: '3px 0 0 0' }}>
                                  {exp.company}
                                </p>
                              </div>
                              <span style={{ 
                                fontSize: '9px', 
                                fontWeight: '600', 
                                color: '#ffffff', 
                                backgroundColor: '#0891b2',
                                padding: '3px 10px',
                                borderRadius: '12px',
                                whiteSpace: 'nowrap'
                              }}>
                                {exp.start_date} - {exp.is_current ? 'Present' : exp.end_date || 'N/A'}
                              </span>
                            </div>
                            {exp.achievements && exp.achievements.length > 0 && (
                              <ul style={{ 
                                fontSize: '10px', 
                                color: '#475569', 
                                margin: '8px 0 0 0', 
                                paddingLeft: '14px',
                                listStyleType: 'none'
                              }}>
                                {exp.achievements.map((achievement, idx) => (
                                  <li key={idx} style={{ 
                                    marginBottom: '4px', 
                                    lineHeight: '1.5',
                                    position: 'relative',
                                    paddingLeft: '12px'
                                  }}>
                                    <span style={{
                                      position: 'absolute',
                                      left: 0,
                                      color: '#0891b2',
                                      fontWeight: 'bold'
                                    }}>▸</span>
                                    {achievement}
                                  </li>
                                ))}
                              </ul>
                            )}
                          </div>
                        ))}
                      </section>
                    )}

                    {/* Founder-Led Ventures */}
                    {ventures.length > 0 && (
                      <section>
                        <div style={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: '10px',
                          marginBottom: '12px'
                        }}>
                          <div style={{ 
                            width: '28px', 
                            height: '28px', 
                            backgroundColor: '#f59e0b', 
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '14px'
                          }}>🚀</div>
                          <h3 style={{ 
                            fontSize: '14px', 
                            fontWeight: 'bold', 
                            color: '#0f172a', 
                            textTransform: 'uppercase',
                            letterSpacing: '1px',
                            margin: 0
                          }}>
                            Founder-Led Ventures
                          </h3>
                        </div>
                        <div style={{ 
                          display: 'grid', 
                          gridTemplateColumns: '1fr 1fr', 
                          gap: '10px',
                          paddingLeft: '38px'
                        }}>
                          {ventures.map((venture) => (
                            <div 
                              key={venture.id} 
                              style={{ 
                                backgroundColor: '#fffbeb', 
                                padding: '10px 12px', 
                                borderRadius: '8px',
                                border: '1px solid #fde68a'
                              }}
                            >
                              <h4 style={{ fontSize: '10px', fontWeight: 'bold', color: '#92400e', margin: 0 }}>
                                {venture.name}
                              </h4>
                              {venture.description && (
                                <p style={{ fontSize: '9px', color: '#78716c', margin: '4px 0 0 0', lineHeight: '1.4' }}>
                                  {venture.description}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      </section>
                    )}
                  </div>

                  {/* Right Column */}
                  <div>
                    {/* Technical Skills */}
                    {skills.length > 0 && (
                      <section style={{ marginBottom: '20px' }}>
                        <div style={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: '10px',
                          marginBottom: '12px'
                        }}>
                          <div style={{ 
                            width: '28px', 
                            height: '28px', 
                            backgroundColor: '#3b82f6', 
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '14px'
                          }}>💻</div>
                          <h3 style={{ 
                            fontSize: '14px', 
                            fontWeight: 'bold', 
                            color: '#0f172a', 
                            textTransform: 'uppercase',
                            letterSpacing: '1px',
                            margin: 0
                          }}>
                            Technical Skills
                          </h3>
                        </div>
                        <div style={{ paddingLeft: '38px' }}>
                          {Object.entries(skillsByCategory).map(([category, skillList]) => (
                            <div key={category} style={{ marginBottom: '10px' }}>
                              <p style={{ 
                                fontSize: '10px', 
                                fontWeight: '600', 
                                color: '#374151', 
                                margin: '0 0 6px 0' 
                              }}>
                                {category}:
                              </p>
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
                                {skillList.map((skill, idx) => (
                                  <span
                                    key={idx}
                                    style={{ 
                                      fontSize: '9px', 
                                      fontWeight: '500',
                                      background: 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)',
                                      color: '#1e40af',
                                      padding: '4px 8px',
                                      borderRadius: '4px',
                                      border: '1px solid #93c5fd'
                                    }}
                                  >
                                    {skill}
                                  </span>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </section>
                    )}

                    {/* Education */}
                    {education.length > 0 && (
                      <section style={{ marginBottom: '20px' }}>
                        <div style={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: '10px',
                          marginBottom: '12px'
                        }}>
                          <div style={{ 
                            width: '28px', 
                            height: '28px', 
                            backgroundColor: '#ec4899', 
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '14px'
                          }}>🎓</div>
                          <h3 style={{ 
                            fontSize: '14px', 
                            fontWeight: 'bold', 
                            color: '#0f172a', 
                            textTransform: 'uppercase',
                            letterSpacing: '1px',
                            margin: 0
                          }}>
                            Education
                          </h3>
                        </div>
                        <div style={{ paddingLeft: '38px' }}>
                          {education.map((edu) => (
                            <div key={edu.id} style={{ 
                              marginBottom: '12px',
                              padding: '10px 12px',
                              backgroundColor: '#fdf2f8',
                              borderRadius: '8px',
                              borderLeft: '3px solid #ec4899'
                            }}>
                              <h4 style={{ fontSize: '11px', fontWeight: 'bold', color: '#831843', margin: 0 }}>
                                {edu.degree}
                              </h4>
                              <p style={{ fontSize: '10px', color: '#9d174d', margin: '3px 0 0 0', fontWeight: '500' }}>
                                {edu.institution}
                              </p>
                              {edu.year && (
                                <p style={{ fontSize: '9px', color: '#be185d', margin: '3px 0 0 0' }}>
                                  {edu.year}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      </section>
                    )}

                    {/* Certifications */}
                    {certifications.length > 0 && (
                      <section style={{ marginBottom: '20px' }}>
                        <div style={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: '10px',
                          marginBottom: '12px'
                        }}>
                          <div style={{ 
                            width: '28px', 
                            height: '28px', 
                            backgroundColor: '#10b981', 
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '14px'
                          }}>🏆</div>
                          <h3 style={{ 
                            fontSize: '14px', 
                            fontWeight: 'bold', 
                            color: '#0f172a', 
                            textTransform: 'uppercase',
                            letterSpacing: '1px',
                            margin: 0
                          }}>
                            Certifications
                          </h3>
                        </div>
                        <div style={{ paddingLeft: '38px' }}>
                          {certifications.map((cert) => (
                            <div 
                              key={cert.id} 
                              style={{ 
                                display: 'flex', 
                                alignItems: 'flex-start', 
                                gap: '8px',
                                marginBottom: '8px'
                              }}
                            >
                              <div style={{ 
                                width: '6px', 
                                height: '6px', 
                                borderRadius: '50%', 
                                backgroundColor: '#10b981',
                                marginTop: '4px',
                                flexShrink: 0
                              }} />
                              <div>
                                <p style={{ fontSize: '10px', fontWeight: '600', color: '#1e293b', margin: 0 }}>
                                  {cert.name}
                                </p>
                                {cert.issuer && (
                                  <p style={{ fontSize: '9px', color: '#64748b', margin: '2px 0 0 0' }}>
                                    {cert.issuer} {cert.year && `• ${cert.year}`}
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </section>
                    )}

                    {/* Languages */}
                    {languages.length > 0 && (
                      <section>
                        <div style={{ 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: '10px',
                          marginBottom: '12px'
                        }}>
                          <div style={{ 
                            width: '28px', 
                            height: '28px', 
                            backgroundColor: '#6366f1', 
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '14px'
                          }}>🌍</div>
                          <h3 style={{ 
                            fontSize: '14px', 
                            fontWeight: 'bold', 
                            color: '#0f172a', 
                            textTransform: 'uppercase',
                            letterSpacing: '1px',
                            margin: 0
                          }}>
                            Languages
                          </h3>
                        </div>
                        <div style={{ 
                          display: 'flex', 
                          flexWrap: 'wrap',
                          gap: '10px', 
                          paddingLeft: '38px'
                        }}>
                          {languages.map((lang) => (
                            <div 
                              key={lang.id}
                              style={{
                                background: 'linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%)',
                                padding: '8px 14px',
                                borderRadius: '20px',
                                border: '1px solid #a5b4fc',
                                textAlign: 'center'
                              }}
                            >
                              <p style={{ fontSize: '10px', fontWeight: '700', color: '#3730a3', margin: 0 }}>
                                {lang.language}
                              </p>
                              <p style={{ fontSize: '8px', color: '#6366f1', margin: '2px 0 0 0' }}>
                                {lang.proficiency}
                              </p>
                            </div>
                          ))}
                        </div>
                      </section>
                    )}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <footer style={{ 
                borderTop: '2px solid #e2e8f0',
                padding: '12px 28px',
                textAlign: 'center',
                backgroundColor: '#f8fafc'
              }}>
                <p style={{ 
                  fontSize: '9px', 
                  color: '#94a3b8', 
                  margin: 0 
                }}>
                  References available upon request • Generated on {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </p>
              </footer>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default CVModal;
