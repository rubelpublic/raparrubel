import { useEffect } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "Who is Rapar Rubel?",
    answer: "Rapar Rubel is a multidisciplinary specialist based in Dhaka, Bangladesh, integrating Business Strategy, Software Systems, and AI Automation. He bridges vision and execution for businesses seeking digital transformation and growth."
  },
  {
    question: "What services does Rapar Rubel offer?",
    answer: "Rapar Rubel offers Business Strategy Consulting, AI Automation Solutions, Software Development, Digital Transformation, Process Optimization, and Technical Advisory services. He specializes in helping businesses leverage AI and technology for competitive advantage."
  },
  {
    question: "Where is Rapar Rubel located?",
    answer: "Rapar Rubel is based in Dhaka, Bangladesh, but works with clients globally through remote collaboration and consulting services."
  },
  {
    question: "How can I book a consultation with Rapar Rubel?",
    answer: "You can book a consultation directly through this website using the booking system. Select your preferred date, time, and service type, then provide your contact details to schedule a meeting."
  },
  {
    question: "What industries does Rapar Rubel work with?",
    answer: "Rapar Rubel works across multiple industries including Technology, E-commerce, Finance, Healthcare, Education, and Manufacturing. His expertise in AI and business strategy applies to any industry seeking digital innovation."
  },
  {
    question: "What is Rapar Rubel's expertise in AI and automation?",
    answer: "Rapar Rubel specializes in AI integration, workflow automation, chatbot development, machine learning implementation, and building intelligent systems that streamline business operations and enhance productivity."
  },
  {
    question: "Does Rapar Rubel offer remote consulting?",
    answer: "Yes, Rapar Rubel offers remote consulting services worldwide. Virtual meetings, project collaboration, and ongoing support are available through video conferencing and digital communication tools."
  },
  {
    question: "What makes Rapar Rubel different from other consultants?",
    answer: "Rapar Rubel combines deep technical expertise with strategic business acumen. His unique ability to bridge the gap between business vision and technical execution, coupled with hands-on AI implementation experience, sets him apart from traditional consultants."
  },
  {
    question: "Can Rapar Rubel help with startup development?",
    answer: "Absolutely. Rapar Rubel has founded and scaled multiple ventures. He provides startup advisory services including business model development, technical architecture, MVP building, and growth strategy consulting."
  },
  {
    question: "How can I contact Rapar Rubel?",
    answer: "You can reach Rapar Rubel through the contact form on this website, via email, or through his LinkedIn profile. For immediate inquiries, use the AI chat assistant available on this site."
  }
];

const FAQSection = () => {
  // Inject JSON-LD structured data for SEO
  useEffect(() => {
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = "faq-schema";
    script.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqs.map(faq => ({
        "@type": "Question",
        "name": faq.question,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": faq.answer
        }
      }))
    });
    
    // Remove existing script if any
    const existingScript = document.getElementById("faq-schema");
    if (existingScript) {
      existingScript.remove();
    }
    
    document.head.appendChild(script);
    
    return () => {
      const scriptToRemove = document.getElementById("faq-schema");
      if (scriptToRemove) {
        scriptToRemove.remove();
      }
    };
  }, []);

  return (
    <section id="faq" className="py-20 md:py-32 bg-muted/30">
      <div className="container max-w-4xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <HelpCircle className="w-4 h-4" />
            Frequently Asked Questions
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground mb-4">
            Common Questions
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Everything you need to know about working with me and my services.
          </p>
        </div>

        {/* FAQ Accordion */}
        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem 
              key={index} 
              value={`item-${index}`}
              className="bg-card border border-border rounded-xl px-6 data-[state=open]:shadow-lg transition-shadow"
            >
              <AccordionTrigger className="text-left text-base md:text-lg font-medium hover:no-underline py-5">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground text-base pb-5">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        {/* Additional SEO Text */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground text-sm">
            Have more questions? <a href="#contact" className="text-primary hover:underline font-medium">Get in touch</a> or use the AI assistant for instant answers.
          </p>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
