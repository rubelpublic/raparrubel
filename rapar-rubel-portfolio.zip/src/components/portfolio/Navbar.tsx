import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Menu, X, Download, MessageSquare, BookOpen, ChevronDown, Calendar, Sun, Moon, Volume2, VolumeX, Music, Brain } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useTheme } from "@/contexts/ThemeContext";
import { SOUND_THEMES, SoundTheme } from "@/hooks/useInteractiveSounds";

interface NavbarProps {
  onChatToggle: () => void;
  onDownloadCV: () => void;
}

const Navbar = ({ onChatToggle, onDownloadCV }: NavbarProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [soundTheme, setSoundTheme] = useState<SoundTheme>('space');
  const { theme, toggleTheme } = useTheme();

  // Sync with InteractiveEffects sound state
  useEffect(() => {
    const checkSoundState = () => {
      const getSoundEnabled = (window as any).__getSoundEnabled;
      const getSoundTheme = (window as any).__getSoundTheme;
      if (getSoundEnabled) {
        setSoundEnabled(getSoundEnabled());
      }
      if (getSoundTheme) {
        setSoundTheme(getSoundTheme());
      }
    };
    
    checkSoundState();
    const interval = setInterval(checkSoundState, 500);
    return () => clearInterval(interval);
  }, []);

  const toggleSound = () => {
    const newState = !soundEnabled;
    setSoundEnabled(newState);
    const setter = (window as any).__setSoundEnabled;
    if (setter) {
      setter(newState);
    }
  };

  const changeTheme = (newTheme: SoundTheme) => {
    setSoundTheme(newTheme);
    const setter = (window as any).__setSoundTheme;
    if (setter) {
      setter(newTheme);
    }
    // Enable sound when selecting a theme
    if (!soundEnabled) {
      setSoundEnabled(true);
      const soundSetter = (window as any).__setSoundEnabled;
      if (soundSetter) {
        soundSetter(true);
      }
    }
  };

  const mainLinks = [
    { href: "#home", label: "Home" },
    { href: "#expertise", label: "Expertise" },
    { href: "#ventures", label: "Ventures" },
    { href: "#testimonials", label: "Testimonials" },
  ];

  const moreLinks = [
    { href: "#skills", label: "Skills" },
    { href: "#projects", label: "Projects" },
    { href: "#blog", label: "Blog", icon: BookOpen },
    { href: "#experience", label: "Experience" },
    { href: "#faq", label: "FAQ" },
    { href: "#contact", label: "Contact" },
  ];

  const allLinks = [...mainLinks, ...moreLinks];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="fixed w-full z-50 glass border-b border-border/50"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <a href="#" className="font-display font-bold text-2xl tracking-tight text-foreground group flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground text-sm group-hover:rotate-12 transition-transform duration-300">
              RM
            </div>
            <span>
              RUBEL<span className="text-primary group-hover:text-foreground transition-colors">.MIAH</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-6">
            {mainLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hover:scale-105 transform"
              >
                {link.label}
              </a>
            ))}

            {/* More Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                More <ChevronDown className="w-3 h-3" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="glass border-border/50">
                {moreLinks.map((link) => (
                  <DropdownMenuItem key={link.href} asChild>
                    <a href={link.href} className="flex items-center gap-2 cursor-pointer">
                      {link.icon && <link.icon className="w-3 h-3" />}
                      {link.label}
                    </a>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* AI Expertise Page Link */}
            <Link
              to="/ai-expertise"
              className="flex items-center gap-1.5 text-sm font-bold text-primary hover:text-primary/80 transition-colors hover:scale-105 transform"
            >
              <Brain className="w-4 h-4" />
              AI Expertise
            </Link>

            <div className="w-px h-6 bg-border" />

            {/* Book Now - Primary CTA */}
            <a
              href="#booking"
              className="group flex items-center gap-2 text-sm font-bold text-primary hover:text-primary/80 transition-colors"
            >
              <Calendar className="w-4 h-4 group-hover:scale-110 transition-transform" />
              Book Now
            </a>

            <button
              onClick={onDownloadCV}
              className="group flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Download className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
              CV
            </button>

            <Button
              onClick={onChatToggle}
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-5 py-2.5 rounded-full text-sm font-bold transition-all glow-primary hover:scale-105 active:scale-95"
            >
              Let's Talk
            </Button>

            <div className="w-px h-6 bg-border" />

            {/* Sound Theme Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger className="p-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all no-sound flex items-center gap-1">
                {soundEnabled ? (
                  <>
                    <span className="text-sm">{SOUND_THEMES[soundTheme].icon}</span>
                    <Music className="w-3 h-3" />
                  </>
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="glass border-border/50 min-w-[160px]">
                <DropdownMenuItem
                  onClick={toggleSound}
                  className="cursor-pointer flex items-center gap-2"
                >
                  {soundEnabled ? (
                    <>
                      <VolumeX className="w-4 h-4" />
                      <span>Mute Sounds</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4" />
                      <span>Enable Sounds</span>
                    </>
                  )}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <div className="px-2 py-1.5 text-xs text-muted-foreground font-medium">
                  Sound Themes
                </div>
                {(Object.keys(SOUND_THEMES) as SoundTheme[]).map((themeKey) => (
                  <DropdownMenuItem
                    key={themeKey}
                    onClick={() => changeTheme(themeKey)}
                    className={`cursor-pointer flex items-center gap-2 ${
                      soundTheme === themeKey ? "bg-primary/10 text-primary" : ""
                    }`}
                  >
                    <span className="text-lg">{SOUND_THEMES[themeKey].icon}</span>
                    <span>{SOUND_THEMES[themeKey].name}</span>
                    {soundTheme === themeKey && (
                      <span className="ml-auto text-xs">✓</span>
                    )}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all"
              title={theme === 'dark' ? "Switch to light mode" : "Switch to dark mode"}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Tablet Navigation (smaller screens) */}
          <div className="hidden md:flex lg:hidden items-center gap-3">
            {/* Sound Theme Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger className="p-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all no-sound">
                {soundEnabled ? (
                  <span className="text-sm">{SOUND_THEMES[soundTheme].icon}</span>
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="glass border-border/50 min-w-[160px]">
                <DropdownMenuItem onClick={toggleSound} className="cursor-pointer">
                  {soundEnabled ? "Mute Sounds" : "Enable Sounds"}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {(Object.keys(SOUND_THEMES) as SoundTheme[]).map((themeKey) => (
                  <DropdownMenuItem
                    key={themeKey}
                    onClick={() => changeTheme(themeKey)}
                    className={`cursor-pointer ${soundTheme === themeKey ? "bg-primary/10" : ""}`}
                  >
                    <span className="mr-2">{SOUND_THEMES[themeKey].icon}</span>
                    {SOUND_THEMES[themeKey].name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>

            <a
              href="#booking"
              className="text-sm font-bold text-primary"
            >
              Book Now
            </a>
            <Button
              onClick={onChatToggle}
              size="sm"
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full"
            >
              Let's Talk
            </Button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu Button + Controls */}
          <div className="md:hidden flex items-center gap-2">
            {/* Sound Theme Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger className="p-2 rounded-full text-muted-foreground hover:text-foreground transition-all no-sound">
                {soundEnabled ? (
                  <span className="text-sm">{SOUND_THEMES[soundTheme].icon}</span>
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="glass border-border/50 min-w-[160px]">
                <DropdownMenuItem onClick={toggleSound} className="cursor-pointer">
                  {soundEnabled ? "Mute Sounds" : "Enable Sounds"}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {(Object.keys(SOUND_THEMES) as SoundTheme[]).map((themeKey) => (
                  <DropdownMenuItem
                    key={themeKey}
                    onClick={() => changeTheme(themeKey)}
                    className={`cursor-pointer ${soundTheme === themeKey ? "bg-primary/10" : ""}`}
                  >
                    <span className="mr-2">{SOUND_THEMES[themeKey].icon}</span>
                    {SOUND_THEMES[themeKey].name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full text-muted-foreground hover:text-foreground transition-all"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile/Tablet Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="lg:hidden glass border-t border-border p-4 space-y-3"
        >
          {/* Book Now - Featured CTA */}
          <a
            href="#booking"
            onClick={() => setIsMobileMenuOpen(false)}
            className="flex items-center gap-2 bg-primary/10 text-primary font-bold px-4 py-3 rounded-lg border border-primary/30"
          >
            <Calendar className="w-5 h-5" />
            Book a Session
          </a>

          <Link
            to="/ai-expertise"
            onClick={() => setIsMobileMenuOpen(false)}
            className="flex items-center gap-2 bg-accent/10 text-primary font-bold px-4 py-3 rounded-lg border border-primary/20"
          >
            <Brain className="w-5 h-5" />
            AI Expertise
          </Link>

          <div className="h-px bg-border my-2" />

          {allLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="block text-muted-foreground hover:text-foreground transition-colors font-medium py-1"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {link.label}
            </a>
          ))}

          <div className="h-px bg-border my-2" />

          <button
            onClick={() => {
              onDownloadCV();
              setIsMobileMenuOpen(false);
            }}
            className="block text-primary font-bold w-full text-left py-1"
          >
            Download CV
          </button>
          <Button
            onClick={() => {
              onChatToggle();
              setIsMobileMenuOpen(false);
            }}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-2"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Let's Talk
          </Button>
        </motion.div>
      )}
    </motion.nav>
  );
};

export default Navbar;
