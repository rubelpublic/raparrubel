import { useState, useEffect } from "react";
import { motion, useScroll, useSpring } from "framer-motion";

const ScrollProgress = () => {
  const [isVisible, setIsVisible] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 100);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      {/* Top progress bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary z-[100] origin-left"
        style={{ scaleX }}
      />
      
      {/* Floating progress indicator */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ 
          opacity: isVisible ? 1 : 0, 
          scale: isVisible ? 1 : 0.8 
        }}
        className="fixed bottom-24 left-6 z-50"
      >
        <div className="relative w-12 h-12">
          {/* Background circle */}
          <svg className="w-12 h-12 transform -rotate-90">
            <circle
              cx="24"
              cy="24"
              r="20"
              stroke="currentColor"
              strokeWidth="3"
              fill="none"
              className="text-muted/30"
            />
            <motion.circle
              cx="24"
              cy="24"
              r="20"
              stroke="url(#progressGradient)"
              strokeWidth="3"
              fill="none"
              strokeLinecap="round"
              style={{
                pathLength: scrollYProgress,
                strokeDasharray: "1 1",
              }}
            />
            <defs>
              <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="hsl(var(--primary))" />
                <stop offset="50%" stopColor="hsl(var(--accent))" />
                <stop offset="100%" stopColor="hsl(var(--primary))" />
              </linearGradient>
            </defs>
          </svg>
          
          {/* Percentage text */}
          <motion.div 
            className="absolute inset-0 flex items-center justify-center"
          >
            <motion.span 
              className="text-xs font-bold text-primary"
              style={{
                opacity: scrollYProgress,
              }}
            >
              <PercentageDisplay progress={scrollYProgress} />
            </motion.span>
          </motion.div>
        </div>
      </motion.div>
    </>
  );
};

// Helper component to display percentage
const PercentageDisplay = ({ progress }: { progress: any }) => {
  const [percentage, setPercentage] = useState(0);
  
  useEffect(() => {
    return progress.on("change", (latest: number) => {
      setPercentage(Math.round(latest * 100));
    });
  }, [progress]);
  
  return <>{percentage}%</>;
};

export default ScrollProgress;
