import { motion } from "framer-motion";

const experiences = [
  {
    title: "Project & Operations Management",
    company: "Proyojon",
    period: "Current",
    periodRange: "2020 - Present",
    description: "Ownership of project planning and execution. Managing cross-functional teams, overseeing operational workflows, and driving process improvement initiatives.",
    isCurrent: true,
  },
  {
    title: "Product & System Contribution",
    company: "Odotrmg",
    period: "2018 - 2021",
    description: "Provided strategic input on software direction, product logic, and system thinking for ERP, POS, and Payroll solutions.",
    isCurrent: false,
  },
  {
    title: "Business Development",
    company: "JMC Group",
    period: "3+ Years",
    description: "Led business growth initiatives, creative communication execution, and provided market-facing strategy support.",
    isCurrent: false,
  },
];

const ExperienceSection = () => {
  return (
    <section id="experience" className="py-24 bg-background border-t border-border">
      <div className="max-w-4xl mx-auto px-6">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl font-display font-bold text-foreground mb-12 text-center"
        >
          Professional Journey
        </motion.h2>

        <div className="space-y-12 relative border-l border-border ml-4 md:ml-0 md:pl-0">
          {experiences.map((exp, index) => (
            <motion.div
              key={exp.title}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative md:grid md:grid-cols-5 md:gap-8"
            >
              {/* Timeline Date - Desktop */}
              <div className="hidden md:block md:col-span-1 text-right pt-1">
                <div className={`font-bold text-sm ${exp.isCurrent ? "text-primary" : "text-muted-foreground"}`}>
                  {exp.isCurrent ? "Current" : exp.period}
                </div>
                {exp.periodRange && (
                  <div className="text-muted-foreground/60 text-xs">{exp.periodRange}</div>
                )}
              </div>

              {/* Timeline Dot */}
              <div
                className={`absolute -left-[5px] md:left-auto md:right-0 md:mr-[-5px] md:col-start-1 md:col-end-2 top-2 w-2.5 h-2.5 rounded-full ${
                  exp.isCurrent
                    ? "bg-primary shadow-[0_0_10px_hsl(var(--primary)/0.8)] animate-pulse"
                    : "bg-muted-foreground/50"
                }`}
              />

              {/* Content */}
              <div className="pl-8 md:pl-0 md:col-span-4">
                <h3 className="text-xl font-bold text-foreground">{exp.title}</h3>
                <div className="text-muted-foreground text-sm mb-2">{exp.company}</div>
                {/* Mobile Date */}
                <div className="md:hidden text-xs text-muted-foreground/60 mb-2">{exp.period}</div>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {exp.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;