import { motion } from "framer-motion";
import { Calendar } from "lucide-react";

const FloatingBookButton = () => {
  return (
    <motion.a
      href="#booking"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 2, duration: 0.5 }}
      className="fixed bottom-20 right-4 z-50 flex items-center gap-2 px-5 py-3 rounded-full bg-primary text-primary-foreground font-bold shadow-lg glow-primary hover:scale-105 active:scale-95 transition-all duration-300 group no-sound"
    >
      <Calendar className="w-5 h-5 group-hover:rotate-12 transition-transform" />
      <span className="hidden sm:inline">Book Session</span>
      <span className="sm:hidden">Book</span>
      
      {/* Pulse ring */}
      <motion.div
        className="absolute inset-0 rounded-full border-2 border-primary"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0, 0.5],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeOut",
        }}
      />
    </motion.a>
  );
};

export default FloatingBookButton;
