import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, PenTool, Share2, Target, Video, FileText, BarChart3 } from "lucide-react";
import CaseStudyModal from "./CaseStudyModal";

const categories = ["All", "Content Strategy", "Social Media", "Brand Development", "Performance Marketing"];

const projects = [
  {
    title: "Comprehensive Brand Storytelling Campaign",
    category: "Brand Development",
    description: "Developed a complete brand narrative and content ecosystem for a fintech startup, including brand guidelines, voice documentation, and multi-channel content strategy.",
    results: ["150% increase in brand awareness", "3x social engagement growth", "Featured in 10+ industry publications", "Consistent brand voice across all channels"],
    icon: PenTool,
    color: "from-violet-500 to-purple-600",
    tags: ["Brand Strategy", "Copywriting", "Content Marketing", "PR"],
    challenge: "The client, an emerging fintech startup, struggled with brand recognition in a crowded market. Their messaging was inconsistent across channels, and they lacked a compelling narrative that differentiated them from competitors. Customer research showed confusion about their value proposition.",
    approach: "I began with comprehensive stakeholder interviews and competitor analysis to understand the market landscape. Then, I developed detailed customer personas and journey maps. Using insights from these exercises, I crafted a brand story framework that connected the company's mission with customer aspirations.",
    solution: "Delivered a complete brand ecosystem including: a 50-page brand guidelines document, tone of voice playbook, messaging hierarchy for different audience segments, content pillars strategy, and a 6-month editorial calendar. Also created template systems for social media, email, and sales collateral to ensure consistency.",
    keyTakeaways: [
      "Brand consistency increased customer trust by 40% based on follow-up surveys",
      "Clear messaging frameworks reduced content creation time by 60%",
      "Employee brand advocacy improved with internal communication guidelines"
    ],
    timeline: "4 months",
    metrics: [{ label: "Brand Recall", value: "+150%" }, { label: "Engagement", value: "3x" }, { label: "PR Features", value: "10+" }]
  },
  {
    title: "Social Media Growth & Engagement",
    category: "Social Media",
    description: "Built and executed a data-driven social media strategy across LinkedIn, Instagram, and Twitter, growing organic reach and community engagement.",
    results: ["500K+ organic impressions monthly", "45% engagement rate increase", "20K new followers in 6 months", "3x increase in DM inquiries"],
    icon: Share2,
    color: "from-pink-500 to-rose-600",
    tags: ["LinkedIn", "Instagram", "Content Calendar", "Community Management"],
    challenge: "A B2B SaaS company had minimal social media presence with under 2,000 followers across platforms. Their posts received little engagement, and they weren't leveraging social channels for lead generation. The team posted sporadically without a cohesive strategy.",
    approach: "Conducted a thorough audit of existing content performance and competitor benchmarking. Identified optimal posting times, content formats, and platform-specific strategies. Developed a content mix formula balancing educational, entertaining, and promotional content.",
    solution: "Implemented a comprehensive social media playbook including: daily engagement routines, weekly content themes, monthly campaign calendars, and quarterly strategy reviews. Created a library of reusable content templates, established influencer collaboration workflows, and set up social listening for trend-jacking opportunities.",
    keyTakeaways: [
      "Consistency and engagement with followers drove 70% of growth",
      "LinkedIn thought leadership content generated highest quality leads",
      "User-generated content campaigns amplified reach by 200%"
    ],
    timeline: "6 months",
    metrics: [{ label: "Impressions", value: "500K+" }, { label: "Engagement", value: "+45%" }, { label: "Followers", value: "+20K" }]
  },
  {
    title: "Performance Marketing Overhaul",
    category: "Performance Marketing",
    description: "Restructured paid media strategy with optimized funnels, A/B tested creatives, and data-driven targeting to maximize ROAS.",
    results: ["320% improvement in ROAS", "55% lower customer acquisition cost", "$1.5M+ revenue attributed", "Quality lead score improved 40%"],
    icon: Target,
    color: "from-emerald-500 to-teal-600",
    tags: ["Google Ads", "Meta Ads", "Analytics", "Conversion Optimization"],
    challenge: "An e-commerce brand was spending $50K+ monthly on paid advertising with diminishing returns. Their CAC had increased 80% over 12 months, and campaigns lacked proper attribution tracking. The team struggled to identify which channels and creatives drove actual purchases.",
    approach: "Started with a comprehensive audit of existing campaigns, pixel implementations, and conversion tracking. Built a proper attribution model and created a testing framework for systematic creative and audience experimentation. Analyzed customer lifetime value to inform bidding strategies.",
    solution: "Rebuilt the entire paid media infrastructure including: proper conversion tracking with server-side events, custom audience segments based on purchase behavior, creative testing framework with statistical significance thresholds, and automated reporting dashboards. Implemented full-funnel campaigns with retargeting sequences.",
    keyTakeaways: [
      "Proper attribution revealed 40% of conversions were misattributed",
      "Creative fatigue was the primary cause of rising CPAs",
      "Lookalike audiences based on high-LTV customers outperformed interest targeting by 3x"
    ],
    timeline: "3 months",
    metrics: [{ label: "ROAS", value: "+320%" }, { label: "CAC", value: "-55%" }, { label: "Revenue", value: "$1.5M+" }]
  },
  {
    title: "Video Content Production Series",
    category: "Content Strategy",
    description: "Created a 12-part educational video series for thought leadership, including scripting, production oversight, and distribution strategy.",
    results: ["250K+ total views", "15% lead conversion rate", "Industry award nomination", "Repurposed into 50+ content pieces"],
    icon: Video,
    color: "from-cyan-500 to-blue-600",
    tags: ["Video Marketing", "Scriptwriting", "YouTube", "Content Distribution"],
    challenge: "A consulting firm wanted to establish thought leadership but their written content wasn't generating traction. They had subject matter experts with valuable insights but no video content strategy or production experience. Competition in their niche was increasingly using video.",
    approach: "Developed a content strategy that mapped video topics to the buyer's journey stages. Created a production workflow that minimized expert time while maximizing content output. Planned for content atomization from the start, ensuring each video could generate multiple derivative pieces.",
    solution: "Produced a 12-episode masterclass series covering industry fundamentals to advanced strategies. Each 15-20 minute episode was professionally scripted, filmed, and edited. Built a distribution strategy across YouTube, LinkedIn, and email. Created a content repurposing system generating blog posts, social clips, podcast episodes, and infographics from each video.",
    keyTakeaways: [
      "Educational content with clear takeaways drove highest watch time",
      "Short social clips drove 60% of full video traffic",
      "Email series around video launches had 45% open rates"
    ],
    timeline: "5 months",
    metrics: [{ label: "Views", value: "250K+" }, { label: "Lead Conv.", value: "15%" }, { label: "Content Pieces", value: "50+" }]
  },
  {
    title: "B2B Content Marketing Engine",
    category: "Content Strategy",
    description: "Designed and implemented a content marketing system with SEO-optimized blogs, whitepapers, case studies, and email nurture sequences.",
    results: ["400% increase in organic traffic", "50+ qualified leads monthly", "Domain authority +25 points", "10 featured snippets captured"],
    icon: FileText,
    color: "from-amber-500 to-orange-600",
    tags: ["SEO", "Blog Writing", "Lead Magnets", "Email Marketing"],
    challenge: "A B2B software company relied entirely on outbound sales with no inbound pipeline. Their website had minimal content, poor SEO, and no lead generation mechanisms. Sales team wanted qualified leads who already understood the product value.",
    approach: "Conducted extensive keyword research to identify high-intent search terms with reasonable competition. Mapped content to buyer personas and journey stages. Created a content production workflow with SEO optimization built into every stage from outline to publication.",
    solution: "Built a complete content marketing infrastructure including: 50+ SEO-optimized blog posts targeting strategic keywords, 5 comprehensive whitepapers as lead magnets, 8 detailed case studies with measurable outcomes, automated email nurture sequences for each lead magnet, and a monthly newsletter. Implemented proper CTA and conversion tracking throughout.",
    keyTakeaways: [
      "Long-form, comprehensive guides outperformed short posts by 5x in traffic",
      "Case studies were the highest-converting content type for bottom-funnel",
      "Email nurture sequences accelerated sales cycle by 30%"
    ],
    timeline: "8 months",
    metrics: [{ label: "Traffic", value: "+400%" }, { label: "Leads/mo", value: "50+" }, { label: "DA", value: "+25" }]
  },
  {
    title: "Integrated Campaign Launch",
    category: "Performance Marketing",
    description: "Led end-to-end campaign for product launch including messaging, creative direction, influencer partnerships, and multi-channel execution.",
    results: ["$500K in launch week sales", "2M+ campaign reach", "Featured on Product Hunt #1", "1,500+ social mentions"],
    icon: BarChart3,
    color: "from-indigo-500 to-blue-600",
    tags: ["Campaign Strategy", "Influencer Marketing", "Launch Planning", "Analytics"],
    challenge: "A startup launching a new product needed to make a significant market impact with a limited budget. Previous launches had underperformed, generating minimal buzz. They needed a coordinated campaign that would create momentum across multiple channels simultaneously.",
    approach: "Developed a launch playbook with phased approach: pre-launch buzz building, launch week maximum impact, and post-launch sustained momentum. Coordinated messaging across owned, earned, and paid channels. Built an influencer partnership strategy focused on authentic advocacy rather than paid promotions.",
    solution: "Executed a 6-week campaign spanning: teaser content series building anticipation, influencer seeding with exclusive early access, coordinated Product Hunt launch with community mobilization, paid media amplification of top-performing organic content, PR outreach securing coverage in 15+ publications, and email launch sequence to waitlist of 5,000+ subscribers.",
    keyTakeaways: [
      "Coordinated timing across channels created perception of larger campaign",
      "Micro-influencers delivered 5x better engagement than macro-influencers",
      "User-generated content from early customers became highest-performing ads"
    ],
    timeline: "6 weeks",
    metrics: [{ label: "Sales", value: "$500K" }, { label: "Reach", value: "2M+" }, { label: "Mentions", value: "1,500+" }]
  }
];

const ProjectsSection = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(p => p.category === activeCategory);

  const handleOpenCaseStudy = (project: typeof projects[0]) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  return (
    <>
      <section id="projects" className="py-24 bg-card/30 border-y border-border relative">
        <div className="absolute inset-0 bg-grid opacity-[0.02]" />

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
              Featured <span className="text-gradient">Projects</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Case studies showcasing impactful marketing & content solutions
            </p>
          </motion.div>

          {/* Category Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex flex-wrap justify-center gap-3 mb-12"
          >
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                    : "bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground"
                }`}
              >
                {category}
              </button>
            ))}
          </motion.div>

          {/* Projects Grid */}
          <motion.div 
            layout
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.title}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  onClick={() => handleOpenCaseStudy(project)}
                  className="group glass rounded-2xl overflow-hidden border border-border hover:border-primary/50 transition-all duration-500 cursor-pointer"
                >
                  {/* Header with Gradient */}
                  <div className={`h-32 bg-gradient-to-br ${project.color} p-6 relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-black/20" />
                    <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
                    <div className="relative z-10 flex items-start justify-between">
                      <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <project.icon className="w-6 h-6 text-white" />
                      </div>
                      <span className="text-xs font-medium text-white/80 bg-white/20 px-3 py-1 rounded-full">
                        {project.category}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {project.description}
                    </p>

                    {/* Results Preview */}
                    <div className="space-y-2 mb-4">
                      {project.results.slice(0, 3).map((result, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-foreground/80">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                          {result}
                        </div>
                      ))}
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.slice(0, 3).map((tag) => (
                        <span 
                          key={tag} 
                          className="text-xs px-2 py-1 bg-secondary rounded-md text-muted-foreground"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* CTA */}
                    <div className="flex items-center gap-2 text-sm font-medium text-primary group-hover:gap-3 transition-all">
                      Read Case Study
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      <CaseStudyModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        caseStudy={selectedProject}
      />
    </>
  );
};

export default ProjectsSection;
