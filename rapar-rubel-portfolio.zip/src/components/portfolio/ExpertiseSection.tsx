import { motion } from "framer-motion";
import { TrendingUp, Bot, Code2, Megaphone, Palette, Lightbulb, Sparkles } from "lucide-react";

const ExpertiseSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1 },
  };

  const expertiseAreas = [
    {
      title: "AI Automation",
      subtitle: "Transforming workflows with intelligent systems",
      icon: Bot,
      color: "primary",
      bgGlow: "bg-primary/10",
      featured: true,
      items: ["LLM & ChatGPT Integration", "Workflow Automation", "AI-Powered Analytics", "Custom AI Agents & Bots"],
    },
    {
      title: "Digital Marketing",
      subtitle: "Data-driven strategies that convert",
      icon: Megaphone,
      color: "pink-400",
      bgGlow: "bg-pink-400/10",
      featured: true,
      items: ["SEO & Content Strategy", "Paid Ads (Google, Meta, TikTok)", "Conversion Optimization", "Marketing Automation"],
    },
    {
      title: "Creative Thinking",
      subtitle: "Innovation meets execution",
      icon: Lightbulb,
      color: "amber-400",
      bgGlow: "bg-amber-400/10",
      featured: true,
      items: ["Problem-Solving Frameworks", "Design Thinking", "Innovation Strategy", "Out-of-Box Solutions"],
    },
    {
      title: "Brand Building",
      subtitle: "Crafting memorable brand experiences",
      icon: Palette,
      color: "violet-400",
      bgGlow: "bg-violet-400/10",
      featured: true,
      items: ["Brand Identity Systems", "Visual Storytelling", "Brand Positioning", "Multi-Platform Presence"],
    },
    {
      title: "Business Strategy",
      subtitle: "Scaling businesses with data",
      icon: TrendingUp,
      color: "emerald-400",
      bgGlow: "bg-emerald-400/10",
      featured: false,
      items: ["Business Model Design", "Growth Strategy", "Market Analysis", "Revenue Optimization"],
    },
    {
      title: "Software & Product",
      subtitle: "Building digital products that scale",
      icon: Code2,
      color: "accent",
      bgGlow: "bg-accent/10",
      featured: false,
      items: ["Full-Stack Development", "SaaS Architecture", "Mobile & Web Apps", "API Integrations"],
    },
  ];

  return (
    <section id="expertise" className="py-24 bg-card/30 border-y border-border relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-[0.02]" />
      
      {/* Animated background elements */}
      <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute top-20 right-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl"
      />
      <motion.div
        animate={{ 
          scale: [1.2, 1, 1.2],
          opacity: [0.15, 0.1, 0.15],
        }}
        transition={{ duration: 10, repeat: Infinity }}
        className="absolute bottom-20 left-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl"
      />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-primary/30 mb-6"
          >
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Expert Skills</span>
          </motion.div>
          <h2 className="text-3xl lg:text-5xl font-display font-bold text-foreground mb-4">
            Core <span className="text-gradient">Competencies</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Combining technical depth with creative strategy to build and scale digital businesses
          </p>
        </motion.div>

        {/* Featured skills - larger cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6"
        >
          {expertiseAreas.filter(area => area.featured).map((area) => {
            const Icon = area.icon;
            const colorClass = area.color === 'primary' ? 'text-primary' : 
                              area.color === 'accent' ? 'text-accent' :
                              `text-${area.color}`;
            const bgClass = area.color === 'primary' ? 'bg-primary' : 
                           area.color === 'accent' ? 'bg-accent' :
                           `bg-${area.color}`;
            
            return (
              <motion.div
                key={area.title}
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.02,
                  transition: { duration: 0.2 }
                }}
                className={`glass p-8 rounded-3xl border border-border hover:border-primary/50 transition-all duration-500 relative overflow-hidden group`}
              >
                {/* Background glow on hover */}
                <div className={`absolute inset-0 ${area.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <motion.div
                        whileHover={{ rotate: [0, -10, 10, 0] }}
                        transition={{ duration: 0.5 }}
                        className={`inline-flex p-3 rounded-2xl ${area.bgGlow} mb-4`}
                      >
                        <Icon className={`${colorClass} w-8 h-8`} />
                      </motion.div>
                      <h3 className="text-2xl font-bold text-foreground">{area.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{area.subtitle}</p>
                    </div>
                  </div>
                  
                  <ul className="space-y-3 text-muted-foreground">
                    {area.items.map((item, i) => (
                      <motion.li 
                        key={item} 
                        className="flex items-center gap-3 group/item"
                        whileHover={{ x: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <motion.div 
                          className={`w-2 h-2 ${bgClass} rounded-full`}
                          animate={{ scale: [1, 1.3, 1] }}
                          transition={{ duration: 2, delay: i * 0.2, repeat: Infinity }}
                        />
                        <span className="group-hover/item:text-foreground transition-colors">{item}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Secondary skills - smaller cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {expertiseAreas.filter(area => !area.featured).map((area) => {
            const Icon = area.icon;
            const colorClass = area.color === 'primary' ? 'text-primary' : 
                              area.color === 'accent' ? 'text-accent' :
                              `text-${area.color}`;
            const bgClass = area.color === 'primary' ? 'bg-primary' : 
                           area.color === 'accent' ? 'bg-accent' :
                           `bg-${area.color}`;
            
            return (
              <motion.div
                key={area.title}
                variants={itemVariants}
                whileHover={{ scale: 1.02 }}
                className={`glass p-6 rounded-2xl border border-border hover:border-primary/30 transition-all duration-300 relative overflow-hidden group`}
              >
                <div className={`absolute inset-0 ${area.bgGlow} opacity-0 group-hover:opacity-50 transition-opacity duration-500`} />
                
                <div className="relative z-10 flex gap-4">
                  <motion.div
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.5 }}
                    className={`flex-shrink-0 inline-flex p-2.5 rounded-xl ${area.bgGlow} self-start`}
                  >
                    <Icon className={`${colorClass} w-6 h-6`} />
                  </motion.div>
                  
                  <div>
                    <h3 className="text-lg font-bold text-foreground mb-1">{area.title}</h3>
                    <p className="text-xs text-muted-foreground mb-3">{area.subtitle}</p>
                    <div className="flex flex-wrap gap-2">
                      {area.items.map((item) => (
                        <span 
                          key={item}
                          className="text-xs px-2 py-1 rounded-full bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default ExpertiseSection;