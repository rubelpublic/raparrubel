import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cpu, Coffee, Leaf, ArrowRight, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const blogPosts = [
  {
    id: "automation",
    title: "How AI Saved Us 20 Hrs/Week",
    excerpt: "A breakdown of how we implemented simple LLM agents to handle customer support and internal data entry...",
    category: "Automation",
    icon: Cpu,
    gradient: "from-primary/20",
    content: {
      sections: [
        {
          title: "The Challenge",
          text: "In scaling our operations, we found that 30% of our team's time was spent on repetitive data entry and basic customer queries. We needed a solution that was robust yet easy to implement.",
        },
        {
          title: "The AI Solution",
          text: "We integrated a custom LLM agent using the Gemini API. This agent now handles 80% of initial customer inquiries and automates data synchronization between our POS and CRM.",
        },
        {
          title: "The Result",
          text: "We reclaimed approximately 20 hours per week, allowing our human team to focus on strategic growth and complex problem-solving. This is the power of practical AI.",
        },
      ],
    },
  },
  {
    id: "brand",
    title: "Building a Brand in Dhaka",
    excerpt: "The story behind Cha Khaben? and how we positioned tea not just as a drink, but as a lifestyle experience...",
    category: "Branding",
    icon: Coffee,
    gradient: "from-amber-500/20",
    content: {
      sections: [
        {
          title: "Cha Khaben? - More Than Tea",
          text: "The tea market in Dhaka is saturated. To stand out, we couldn't just sell tea; we had to sell a lifestyle. We focused on the emotional connection of 'Adda' (social gathering).",
        },
        {
          title: "Visual Identity",
          text: "We chose organic, earthy tones mixed with modern typography to appeal to the youth demographic while respecting tradition. Our digital marketing focused heavily on visual storytelling on Instagram.",
        },
      ],
    },
  },
  {
    id: "sustainability",
    title: "Profitable Sustainability",
    excerpt: "Why E-waste management is the next big frontier for tech entrepreneurs in developing markets...",
    category: "CleanTech",
    icon: Leaf,
    gradient: "from-emerald-500/20",
    content: {
      sections: [
        {
          title: "The E-Waste Problem",
          text: "Dhaka generates massive amounts of electronic waste. Bhangariwala was born from the idea that waste management could be formalized and profitable.",
        },
        {
          title: "Tech-Enabled Logistics",
          text: "By using a simple app interface for collection scheduling, we optimized our logistics routes, reducing fuel costs and increasing collection rates by 40% in the first quarter.",
        },
      ],
    },
  },
];

const BlogSection = () => {
  const [selectedPost, setSelectedPost] = useState<typeof blogPosts[0] | null>(null);

  return (
    <>
      <section id="blog" className="py-24 bg-background relative border-t border-border">
        <div className="absolute inset-0 bg-grid opacity-[0.02]" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex flex-col md:flex-row justify-between items-end mb-12"
          >
            <div>
              <h2 className="text-3xl lg:text-4xl font-display font-bold text-foreground mb-4">
                Latest Insights
              </h2>
              <p className="text-muted-foreground max-w-lg">
                Thoughts on AI automation, business scaling, and market trends.
              </p>
            </div>
            <button className="hidden md:flex items-center gap-2 text-primary font-bold hover:text-foreground transition-colors mt-4 md:mt-0">
              View All Articles <ArrowRight className="w-4 h-4" />
            </button>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedPost(post)}
                className="glass p-6 rounded-3xl border border-border hover-card-effect group cursor-pointer"
              >
                <div className="h-48 bg-secondary rounded-2xl mb-6 overflow-hidden relative">
                  <div className={`absolute inset-0 bg-gradient-to-tr ${post.gradient} to-transparent`} />
                  <div className="absolute bottom-4 left-4 bg-card/80 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-foreground">
                    {post.category}
                  </div>
                  <post.icon className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 text-muted-foreground/50 group-hover:scale-110 transition-transform" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                  {post.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                <span className="text-primary text-sm font-bold flex items-center gap-1 group-hover:gap-2 transition-all">
                  Read Article <ArrowRight className="w-4 h-4" />
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Modal */}
      <AnimatePresence>
        {selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedPost(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass border border-border rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto relative p-8"
              onClick={(e) => e.stopPropagation()}
            >
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedPost(null)}
                className="absolute top-4 right-4 rounded-full bg-secondary hover:bg-secondary/80"
              >
                <X className="w-4 h-4" />
              </Button>

              <h1 className="text-3xl font-display font-bold text-primary mb-6">
                {selectedPost.title}
              </h1>

              {selectedPost.content.sections.map((section, index) => (
                <div key={index} className="mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-4">{section.title}</h2>
                  <p className="text-muted-foreground">{section.text}</p>
                </div>
              ))}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default BlogSection;