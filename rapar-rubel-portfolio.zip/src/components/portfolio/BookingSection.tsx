import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  CalendarIcon, 
  Clock, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles,
  Zap,
  Users,
  MessageCircle,
  Star,
  Timer,
  BadgeCheck,
  User,
  Mail,
  Phone
} from 'lucide-react';
import { format, addDays, isBefore, startOfToday, getDay } from 'date-fns';
import { cn } from '@/lib/utils';
import AnimatedSection from './AnimatedSection';

interface Service {
  id: string;
  name: string;
  description: string | null;
  duration: string | null;
  price_range: string | null;
}

interface AvailableSlot {
  id: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
}

const BookingSection = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [availableSlots, setAvailableSlots] = useState<AvailableSlot[]>([]);
  const [step, setStep] = useState(0); // 0 = intro, 1 = date+time, 2 = contact, 3 = confirm
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    notes: '',
  });

  useEffect(() => {
    const fetchData = async () => {
      const [servicesRes, slotsRes] = await Promise.all([
        supabase.from('services').select('*').eq('active', true).order('display_order'),
        supabase.from('available_slots').select('*').eq('is_active', true),
      ]);

      if (servicesRes.data) {
        setServices(servicesRes.data);
        // Auto-select first service
        if (servicesRes.data.length > 0) {
          setSelectedService(servicesRes.data[0]);
        }
      }
      if (slotsRes.data) setAvailableSlots(slotsRes.data);
    };

    fetchData();
  }, []);

  const getTimeSlotsForDate = (date: Date) => {
    const dayOfWeek = getDay(date);
    return availableSlots
      .filter((slot) => slot.day_of_week === dayOfWeek)
      .sort((a, b) => a.start_time.localeCompare(b.start_time));
  };

  const isDateAvailable = (date: Date) => {
    if (isBefore(date, startOfToday())) return false;
    const dayOfWeek = getDay(date);
    return availableSlots.some((slot) => slot.day_of_week === dayOfWeek);
  };

  const handleSubmit = async () => {
    if (!selectedService || !selectedDate || !selectedTime) return;

    setIsSubmitting(true);

    const slot = availableSlots.find(
      (s) => s.day_of_week === getDay(selectedDate) && s.start_time === selectedTime
    );

    const { error } = await supabase.from('bookings').insert({
      client_name: formData.name.trim(),
      client_email: formData.email.trim(),
      client_phone: formData.phone.trim() || null,
      notes: formData.notes.trim() || null,
      service_id: selectedService.id,
      booking_date: format(selectedDate, 'yyyy-MM-dd'),
      start_time: selectedTime,
      end_time: slot?.end_time || selectedTime,
      status: 'pending',
    });

    setIsSubmitting(false);

    if (error) {
      toast({
        title: 'Booking failed',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      setIsSuccess(true);
      toast({
        title: 'Booking submitted!',
        description: "I'll confirm your appointment shortly via email.",
      });
    }
  };

  const resetBooking = () => {
    setStep(0);
    setSelectedDate(undefined);
    setSelectedTime(null);
    setFormData({ name: '', email: '', phone: '', notes: '' });
    setIsSuccess(false);
  };

  const benefits = [
    { icon: Zap, text: "Get actionable insights" },
    { icon: Users, text: "1-on-1 personalized session" },
    { icon: MessageCircle, text: "Discuss your unique challenges" },
  ];

  const stats = [
    { value: "50+", label: "Sessions completed" },
    { value: "4.9", label: "Average rating" },
    { value: "24h", label: "Response time" },
  ];

  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  // Success State
  if (isSuccess) {
    return (
      <section id="booking" className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="max-w-2xl mx-auto text-center relative z-10">
          <AnimatedSection>
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="w-24 h-24 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-8 glow-primary"
            >
              <CheckCircle className="h-12 w-12 text-primary-foreground" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h2 className="text-4xl font-display font-bold mb-4 text-gradient">
                You're All Set!
              </h2>
              <p className="text-xl text-foreground mb-2">
                Thank you, {formData.name}! 🎉
              </p>
              <Card className="border-primary/30 bg-card/50 backdrop-blur-sm mt-8 mb-8">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center gap-4 flex-wrap">
                    <Badge variant="secondary" className="text-sm px-4 py-2">
                      <CalendarIcon className="h-4 w-4 mr-2" />
                      {selectedDate && format(selectedDate, 'MMM d, yyyy')}
                    </Badge>
                    <Badge variant="secondary" className="text-sm px-4 py-2">
                      <Clock className="h-4 w-4 mr-2" />
                      {selectedTime?.slice(0, 5)}
                    </Badge>
                    <Badge className="text-sm px-4 py-2 bg-primary/20 text-primary border-primary/30">
                      {selectedService?.name}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              <p className="text-muted-foreground mb-8">
                A confirmation email will be sent to <span className="text-primary font-medium">{formData.email}</span>
              </p>
              <Button onClick={resetBooking} variant="outline" size="lg" className="gap-2">
                <Sparkles className="h-4 w-4" />
                Book Another Session
              </Button>
            </motion.div>
          </AnimatedSection>
        </div>
      </section>
    );
  }

  // Intro State (Step 0)
  if (step === 0) {
    return (
      <section id="booking" className="py-24 px-6 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute top-1/4 -left-32 w-64 h-64 bg-primary/20 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-accent/20 rounded-full blur-3xl animate-pulse-glow animation-delay-2000" />
        
        <div className="max-w-6xl mx-auto relative z-10">
          <AnimatedSection className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-2 mb-6"
            >
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">Limited Availability</span>
            </motion.div>
            
            <h2 className="text-4xl md:text-6xl font-display font-bold mb-6">
              Ready to <span className="text-gradient">Transform</span>
              <br />Your Ideas?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Book a personalized session and get expert guidance on your project, 
              strategy, or technical challenges.
            </p>

            {/* Stats */}
            <div className="flex justify-center gap-8 md:gap-16 mb-12">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold text-gradient">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </AnimatedSection>

          {/* Main CTA Card */}
          <AnimatedSection delay={0.2}>
            <Card className="border-primary/20 bg-gradient-to-br from-card via-card to-primary/5 overflow-hidden max-w-4xl mx-auto">
              <CardContent className="p-0">
                <div className="grid md:grid-cols-2">
                  {/* Left Side - Benefits */}
                  <div className="p-8 md:p-10 border-b md:border-b-0 md:border-r border-primary/10">
                    <h3 className="text-2xl font-display font-bold mb-6">
                      What You'll Get
                    </h3>
                    <div className="space-y-4 mb-8">
                      {benefits.map((benefit, index) => (
                        <motion.div
                          key={benefit.text}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.4 + index * 0.1 }}
                          className="flex items-center gap-3"
                        >
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <benefit.icon className="h-5 w-5 text-primary" />
                          </div>
                          <span className="text-foreground">{benefit.text}</span>
                        </motion.div>
                      ))}
                    </div>

                    {/* Testimonial Preview */}
                    <div className="bg-secondary/30 rounded-xl p-4 border border-secondary">
                      <div className="flex gap-1 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                        ))}
                      </div>
                      <p className="text-sm text-muted-foreground italic">
                        "The session was incredibly valuable. Got actionable insights that helped shape our product roadmap."
                      </p>
                      <p className="text-xs text-primary mt-2">— Recent Client</p>
                    </div>
                  </div>

                  {/* Right Side - CTA */}
                  <div className="p-8 md:p-10 flex flex-col justify-center items-center text-center bg-gradient-to-br from-transparent to-primary/5">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6 glow-primary">
                      <CalendarIcon className="h-10 w-10 text-primary-foreground" />
                    </div>
                    <h3 className="text-2xl font-display font-bold mb-2">
                      Book Your Session
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Just 3 quick steps
                    </p>
                    
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button 
                        size="lg" 
                        onClick={() => setStep(1)}
                        className="text-lg px-8 py-6 bg-gradient-to-r from-primary to-accent hover:opacity-90 glow-primary gap-2 group"
                      >
                        Get Started
                        <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </motion.div>

                    <div className="flex items-center gap-2 mt-6 text-sm text-muted-foreground">
                      <BadgeCheck className="h-4 w-4 text-primary" />
                      <span>Free cancellation anytime</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </AnimatedSection>

          {/* Service Preview Cards */}
          <AnimatedSection delay={0.4} className="mt-12">
            <p className="text-center text-muted-foreground mb-6">Available Sessions</p>
            <div className="flex flex-wrap justify-center gap-3">
              {services.slice(0, 4).map((service, index) => (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  <Badge 
                    variant="outline" 
                    className={cn(
                      "px-4 py-2 text-sm cursor-pointer hover:bg-primary/10 hover:border-primary/50 transition-all",
                      selectedService?.id === service.id && "bg-primary/10 border-primary/50"
                    )}
                    onClick={() => {
                      setSelectedService(service);
                      setStep(1);
                    }}
                  >
                    <Timer className="h-3 w-3 mr-2" />
                    {service.name}
                    {service.price_range && (
                      <span className="ml-2 text-primary">{service.price_range}</span>
                    )}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </AnimatedSection>
        </div>
      </section>
    );
  }

  // Booking Steps (1-3)
  return (
    <section id="booking" className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <AnimatedSection className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-2">
            {step === 1 && "Pick Date & Time"}
            {step === 2 && "Your Details"}
            {step === 3 && "Confirm Booking"}
          </h2>
          <p className="text-muted-foreground">
            {step === 1 && "Choose when works best for you"}
            {step === 2 && "Tell us how to reach you"}
            {step === 3 && "Review and confirm your booking"}
          </p>
        </AnimatedSection>

        {/* Progress Steps */}
        <div className="flex justify-center mb-12">
          <div className="flex items-center gap-2">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <motion.div
                  initial={false}
                  animate={{
                    scale: step === s ? 1.1 : 1,
                    backgroundColor: step >= s ? 'hsl(var(--primary))' : 'hsl(var(--secondary))',
                  }}
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors',
                    step >= s ? 'text-primary-foreground' : 'text-muted-foreground'
                  )}
                >
                  {step > s ? <CheckCircle className="h-5 w-5" /> : s}
                </motion.div>
                {s < 3 && (
                  <motion.div
                    initial={false}
                    animate={{
                      backgroundColor: step > s ? 'hsl(var(--primary))' : 'hsl(var(--secondary))',
                    }}
                    className="w-8 md:w-16 h-1 rounded-full"
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <AnimatePresence mode="wait">
          {/* Step 1: Date + Time */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              {/* Service Selector */}
              {services.length > 1 && (
                <div className="flex flex-wrap justify-center gap-2 mb-8">
                  {services.map((service) => (
                    <Badge
                      key={service.id}
                      variant="outline"
                      className={cn(
                        "px-4 py-2 cursor-pointer transition-all",
                        selectedService?.id === service.id 
                          ? "bg-primary text-primary-foreground border-primary" 
                          : "hover:bg-primary/10"
                      )}
                      onClick={() => setSelectedService(service)}
                    >
                      {service.name}
                      {service.duration && <span className="ml-2 opacity-70">• {service.duration}</span>}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6">
                {/* Calendar */}
                <Card className="border-secondary bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-4 md:p-6">
                    <div className="text-center mb-4">
                      <h4 className="font-semibold flex items-center justify-center gap-2">
                        <CalendarIcon className="h-4 w-4 text-primary" />
                        Select Date
                      </h4>
                    </div>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => {
                        setSelectedDate(date);
                        setSelectedTime(null);
                      }}
                      disabled={(date) => !isDateAvailable(date)}
                      fromDate={startOfToday()}
                      toDate={addDays(startOfToday(), 60)}
                      className="pointer-events-auto mx-auto"
                    />
                  </CardContent>
                </Card>

                {/* Time Slots */}
                <Card className="border-secondary bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-4 md:p-6">
                    <div className="text-center mb-4">
                      <h4 className="font-semibold flex items-center justify-center gap-2">
                        <Clock className="h-4 w-4 text-primary" />
                        Select Time
                      </h4>
                      {selectedDate && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {format(selectedDate, 'EEEE, MMMM d')}
                        </p>
                      )}
                    </div>
                    
                    {!selectedDate ? (
                      <div className="flex items-center justify-center h-48 text-muted-foreground">
                        <p className="text-center">Select a date first</p>
                      </div>
                    ) : getTimeSlotsForDate(selectedDate).length === 0 ? (
                      <div className="flex items-center justify-center h-48 text-muted-foreground">
                        <p className="text-center">No slots available for this date</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-3">
                        {getTimeSlotsForDate(selectedDate).map((slot) => (
                          <Button
                            key={slot.id}
                            variant={selectedTime === slot.start_time ? 'default' : 'outline'}
                            onClick={() => setSelectedTime(slot.start_time)}
                            className={cn(
                              "h-12",
                              selectedTime === slot.start_time && "glow-primary"
                            )}
                          >
                            {slot.start_time.slice(0, 5)}
                          </Button>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="flex justify-center gap-4 mt-8">
                <Button variant="ghost" onClick={() => setStep(0)} className="gap-2">
                  <ArrowLeft className="h-4 w-4" /> Back
                </Button>
                {selectedDate && selectedTime && (
                  <Button onClick={() => setStep(2)} className="gap-2 px-8">
                    Continue <ArrowRight className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </motion.div>
          )}

          {/* Step 2: Contact Details */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-secondary bg-card/50 backdrop-blur-sm max-w-lg mx-auto">
                <CardContent className="p-6 space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="flex items-center gap-2">
                      <User className="h-4 w-4 text-primary" />
                      Full Name *
                    </Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Your name"
                      maxLength={100}
                      className="bg-secondary/30 border-secondary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-primary" />
                      Phone Number *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+880 1XXX-XXXXXX"
                      maxLength={20}
                      className="bg-secondary/30 border-secondary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-primary" />
                      Email *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="you@example.com"
                      maxLength={255}
                      className="bg-secondary/30 border-secondary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">What would you like to discuss? (optional)</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Brief description of your project or questions..."
                      rows={3}
                      maxLength={500}
                      className="bg-secondary/30 border-secondary resize-none"
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-center gap-4 mt-8">
                <Button variant="ghost" onClick={() => setStep(1)} className="gap-2">
                  <ArrowLeft className="h-4 w-4" /> Back
                </Button>
                <Button 
                  onClick={() => setStep(3)} 
                  disabled={!formData.name.trim() || !formData.phone.trim() || !formData.email.trim() || !isValidEmail(formData.email)}
                  className="gap-2 px-8"
                >
                  Continue <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Confirm */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-primary/30 bg-card/50 backdrop-blur-sm max-w-lg mx-auto">
                <CardContent className="p-6 space-y-6">
                  {/* Session Info */}
                  <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-5 rounded-xl border border-primary/20">
                    <h4 className="font-semibold mb-4 text-center">Session Details</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Service</span>
                        <Badge className="bg-primary/20 text-primary border-primary/30">
                          {selectedService?.name}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Date</span>
                        <span className="flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4 text-primary" />
                          {selectedDate && format(selectedDate, 'EEEE, MMM d, yyyy')}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Time</span>
                        <span className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-primary" />
                          {selectedTime?.slice(0, 5)}
                        </span>
                      </div>
                      {selectedService?.duration && (
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Duration</span>
                          <span>{selectedService.duration}</span>
                        </div>
                      )}
                      {selectedService?.price_range && (
                        <div className="flex items-center justify-between border-t border-primary/20 pt-3 mt-3">
                          <span className="text-muted-foreground">Price</span>
                          <span className="text-lg font-bold text-primary">{selectedService.price_range}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="bg-secondary/30 p-5 rounded-xl border border-secondary">
                    <h4 className="font-semibold mb-4 text-center">Your Information</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.email}</span>
                      </div>
                      {formData.notes && (
                        <div className="pt-2 border-t border-secondary mt-2">
                          <p className="text-muted-foreground italic">"{formData.notes}"</p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-center gap-4 mt-8">
                <Button variant="ghost" onClick={() => setStep(2)} className="gap-2">
                  <ArrowLeft className="h-4 w-4" /> Back
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="gap-2 px-8 bg-gradient-to-r from-primary to-accent hover:opacity-90"
                >
                  {isSubmitting ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <Clock className="h-4 w-4" />
                      </motion.div>
                      Booking...
                    </>
                  ) : (
                    <>
                      Confirm Booking <CheckCircle className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default BookingSection;
