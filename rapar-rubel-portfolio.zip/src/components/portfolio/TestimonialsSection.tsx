import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote, Star, ChevronLeft, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import ReviewForm from "./ReviewForm";

interface Testimonial {
  id: string;
  client_name: string;
  client_title?: string | null;
  client_company?: string | null;
  content: string;
  rating: number | null;
  client_avatar?: string | null;
}

const defaultTestimonials = [
  {
    id: "1",
    client_name: "Farhan Rahman",
    client_title: "Marketing Director",
    client_company: "Rokomari.com",
    content: "Rubel's content marketing strategy completely transformed our brand presence. His storytelling approach increased our organic traffic by 180% and customer engagement went through the roof. Truly exceptional work!",
    rating: 5,
    client_avatar: null
  },
  {
    id: "2",
    client_name: "Tasnia Ahmed",
    client_title: "CEO",
    client_company: "Dhaka Digital Agency",
    content: "The social media campaigns Rubel crafted for us were nothing short of brilliant. Our follower count tripled in 4 months, and more importantly, we saw real conversions. His creative vision is unmatched.",
    rating: 5,
    client_avatar: null
  },
  {
    id: "3",
    client_name: "Mahbub Alam",
    client_title: "Founder",
    client_company: "Bengal Brands Co.",
    content: "Rubel understood our brand identity like no one else. His product photography and visual content elevated our e-commerce presence, resulting in a 65% increase in sales. Highly recommended!",
    rating: 5,
    client_avatar: null
  },
];

const TestimonialsSection = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>(defaultTestimonials);
  const [current, setCurrent] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const fetchTestimonials = async () => {
    const { data, error } = await supabase
      .from("testimonials")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data && data.length > 0) {
      setTestimonials(data);
    }
  };

  useEffect(() => {
    fetchTestimonials();
  }, []);

  useEffect(() => {
    if (!isAutoPlaying || testimonials.length === 0) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [isAutoPlaying, testimonials.length]);

  const next = () => {
    setIsAutoPlaying(false);
    setCurrent((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setIsAutoPlaying(false);
    setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getRole = (testimonial: Testimonial) => {
    if (testimonial.client_title && testimonial.client_company) {
      return `${testimonial.client_title}, ${testimonial.client_company}`;
    }
    return testimonial.client_title || testimonial.client_company || "Valued Client";
  };

  return (
    <section id="testimonials" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-grid opacity-5" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
            Client <span className="text-gradient">Testimonials</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            What industry leaders say about working together
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start max-w-6xl mx-auto">
          {/* Testimonials Carousel */}
          <div className="order-2 lg:order-1">
            <div className="relative">
              {/* Quote Icon */}
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 z-10">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Quote className="w-6 h-6 text-primary" />
                </div>
              </div>

              {/* Testimonial Card */}
              <div className="glass rounded-3xl p-8 md:p-10 min-h-[320px] flex items-center">
                <AnimatePresence mode="wait">
                  {testimonials.length > 0 && (
                    <motion.div
                      key={current}
                      initial={{ opacity: 0, x: 50 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -50 }}
                      transition={{ duration: 0.5 }}
                      className="w-full text-center"
                    >
                      {/* Rating */}
                      <div className="flex justify-center gap-1 mb-6">
                        {[...Array(testimonials[current]?.rating || 5)].map((_, i) => (
                          <motion.div
                            key={i}
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: i * 0.1 }}
                          >
                            <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                          </motion.div>
                        ))}
                      </div>

                      {/* Quote */}
                      <p className="text-lg md:text-xl text-foreground/90 leading-relaxed mb-8 italic">
                        "{testimonials[current]?.content}"
                      </p>

                      {/* Author */}
                      <div className="flex items-center justify-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">
                          {testimonials[current]?.client_avatar || getInitials(testimonials[current]?.client_name || "")}
                        </div>
                        <div className="text-left">
                          <div className="font-semibold text-foreground">
                            {testimonials[current]?.client_name}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {getRole(testimonials[current])}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Navigation Arrows */}
              <button
                onClick={prev}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary/10 hover:border-primary/50 transition-colors no-sound"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={next}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary/10 hover:border-primary/50 transition-colors no-sound"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Dots */}
            <div className="flex justify-center gap-2 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setIsAutoPlaying(false);
                    setCurrent(index);
                  }}
                  className={`w-2 h-2 rounded-full transition-all duration-300 no-sound ${
                    index === current
                      ? "w-8 bg-primary"
                      : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Review Form */}
          <div className="order-1 lg:order-2">
            <ReviewForm onReviewSubmitted={fetchTestimonials} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
