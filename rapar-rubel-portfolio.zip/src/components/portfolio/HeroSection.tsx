import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { MessageSquare, FileText, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import profileImage from "@/assets/rubel-profile.jpeg";

interface HeroSectionProps {
  onChatToggle: () => void;
  onDownloadCV: () => void;
}

const HeroSection = ({ onChatToggle, onDownloadCV }: HeroSectionProps) => {
  const [currentWord, setCurrentWord] = useState(0);
  const words = ["Strategy.", "Systems.", "Scale."];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWord((prev) => (prev + 1) % words.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 min-h-[90vh] flex items-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid opacity-[0.03] pointer-events-none" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] -z-10 animate-blob" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-[120px] -z-10 animate-blob animation-delay-2000" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
        {/* Left Content */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="z-10"
        >
          {/* Status Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-card border border-border mb-8 hover:border-primary/50 transition-colors cursor-default"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
            </span>
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Dhaka, Bangladesh
            </span>
          </motion.div>

          {/* Main Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-5xl lg:text-7xl font-display font-extrabold text-foreground leading-[1.1] mb-6"
          >
            <span className="typing-cursor">{words[currentWord]}</span>
            <br />
            <span className="text-gradient">Your Business.</span>
          </motion.h1>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-xl text-muted-foreground leading-relaxed max-w-lg mb-10"
          >
            Bangladesh's leading <strong className="text-foreground">AI Expert</strong> &{" "}
            <strong className="text-foreground">Business Strategist</strong>. I bridge the gap between vision
            and execution through{" "}
            <strong className="text-foreground">AI Automation</strong>,{" "}
            <strong className="text-foreground">Digital Transformation</strong>, and{" "}
            <strong className="text-foreground">Growth Systems</strong>.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Button
              onClick={onChatToggle}
              size="lg"
              className="bg-foreground text-background hover:bg-foreground/90 rounded-xl font-bold text-lg px-8 py-6 hover:scale-105 transform active:scale-95 transition-all duration-200"
            >
              <MessageSquare className="w-5 h-5 mr-2 text-primary" />
              Start Conversation
            </Button>
            <Button
              onClick={onDownloadCV}
              variant="outline"
              size="lg"
              className="border-border hover:border-primary bg-card text-foreground rounded-xl font-bold text-lg px-8 py-6 hover:scale-105 transform active:scale-95 transition-all duration-200"
            >
              <FileText className="w-5 h-5 mr-2" />
              Download Portfolio
            </Button>
          </motion.div>
        </motion.div>

        {/* Right - Profile Image */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.4 }}
          className="relative hidden lg:block"
        >
          {/* Glow Background */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[500px] bg-gradient-to-tr from-primary/20 to-accent/20 rounded-full blur-[80px] animate-pulse-glow" />

          <div className="relative w-[400px] mx-auto animate-float">
            {/* Rotating Ring */}
            <div className="absolute inset-0 rounded-[2.5rem] border border-dashed border-foreground/10 animate-spin-slow scale-110" />

            {/* Image Frame */}
            <div className="relative rounded-[2.5rem] overflow-hidden border border-border shadow-2xl bg-card z-10 aspect-[4/5] group hover:border-primary/50 transition-colors duration-500">
              <img
                src={profileImage}
                alt="Rubel Miah"
                className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-110 profile-image"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-60" />
            </div>

            {/* Floating Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1, duration: 0.5 }}
              className="absolute -bottom-8 -right-8 glass p-5 rounded-2xl shadow-2xl z-20 flex items-center gap-4 hover:border-green-500/50 transition-colors border border-border"
            >
              <div className="bg-green-500/20 p-3 rounded-full">
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <div className="text-foreground font-bold text-base">Open for Projects</div>
                <div className="text-muted-foreground text-xs">Strategy & Automation</div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;