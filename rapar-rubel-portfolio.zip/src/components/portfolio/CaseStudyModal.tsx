import { motion, AnimatePresence } from "framer-motion";
import { X, ArrowLeft, Clock, Target, TrendingUp, CheckCircle, Lightbulb, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CaseStudy {
  title: string;
  category: string;
  description: string;
  results: string[];
  color: string;
  tags: string[];
  challenge: string;
  approach: string;
  solution: string;
  keyTakeaways: string[];
  timeline: string;
  metrics: { label: string; value: string }[];
}

interface CaseStudyModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseStudy: CaseStudy | null;
}

const CaseStudyModal = ({ isOpen, onClose, caseStudy }: CaseStudyModalProps) => {
  if (!caseStudy) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-sm overflow-y-auto"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="min-h-screen"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className={`bg-gradient-to-br ${caseStudy.color} py-16 px-6 relative overflow-hidden`}>
              <div className="absolute inset-0 bg-black/30" />
              <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
              <div className="absolute -top-20 -left-20 w-48 h-48 bg-white/10 rounded-full blur-3xl" />
              
              <div className="max-w-4xl mx-auto relative z-10">
                <Button
                  variant="ghost"
                  onClick={onClose}
                  className="text-white hover:bg-white/20 mb-6"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Projects
                </Button>
                
                <span className="text-sm font-medium text-white/80 bg-white/20 px-4 py-1.5 rounded-full inline-block mb-4">
                  {caseStudy.category}
                </span>
                
                <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
                  {caseStudy.title}
                </h1>
                
                <p className="text-lg text-white/90 max-w-2xl">
                  {caseStudy.description}
                </p>

                <div className="flex flex-wrap gap-2 mt-6">
                  {caseStudy.tags.map((tag) => (
                    <span key={tag} className="text-xs px-3 py-1 bg-white/20 rounded-full text-white">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="max-w-4xl mx-auto px-6 py-12">
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
                <div className="glass p-4 rounded-xl text-center">
                  <Clock className="w-5 h-5 text-primary mx-auto mb-2" />
                  <div className="text-xs text-muted-foreground">Timeline</div>
                  <div className="text-sm font-bold text-foreground">{caseStudy.timeline}</div>
                </div>
                {caseStudy.metrics.slice(0, 3).map((metric, i) => (
                  <div key={i} className="glass p-4 rounded-xl text-center">
                    <BarChart3 className="w-5 h-5 text-primary mx-auto mb-2" />
                    <div className="text-xs text-muted-foreground">{metric.label}</div>
                    <div className="text-sm font-bold text-foreground">{metric.value}</div>
                  </div>
                ))}
              </div>

              {/* Challenge Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="mb-10"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                    <Target className="w-5 h-5 text-red-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-foreground">The Challenge</h2>
                </div>
                <p className="text-muted-foreground leading-relaxed pl-13">
                  {caseStudy.challenge}
                </p>
              </motion.div>

              {/* Approach Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mb-10"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <Lightbulb className="w-5 h-5 text-amber-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-foreground">The Approach</h2>
                </div>
                <p className="text-muted-foreground leading-relaxed pl-13">
                  {caseStudy.approach}
                </p>
              </motion.div>

              {/* Solution Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mb-10"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-emerald-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-foreground">The Solution</h2>
                </div>
                <p className="text-muted-foreground leading-relaxed pl-13">
                  {caseStudy.solution}
                </p>
              </motion.div>

              {/* Results Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mb-10"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                  <h2 className="text-2xl font-bold text-foreground">Results & Impact</h2>
                </div>
                <div className="grid sm:grid-cols-2 gap-3 pl-13">
                  {caseStudy.results.map((result, i) => (
                    <div key={i} className="flex items-center gap-3 glass p-4 rounded-xl">
                      <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                      <span className="text-sm text-foreground">{result}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Key Takeaways */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="glass p-6 rounded-2xl border border-primary/20"
              >
                <h3 className="text-lg font-bold text-foreground mb-4">💡 Key Takeaways</h3>
                <ul className="space-y-3">
                  {caseStudy.keyTakeaways.map((takeaway, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <span className="text-primary font-bold">{i + 1}.</span>
                      {takeaway}
                    </li>
                  ))}
                </ul>
              </motion.div>

              {/* Close Button */}
              <div className="text-center mt-12">
                <Button onClick={onClose} variant="outline" size="lg">
                  <X className="w-4 h-4 mr-2" />
                  Close Case Study
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CaseStudyModal;
