import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import Index from "./pages/Index";
import AIExpertise from "./pages/AIExpertise";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/admin/Dashboard";
import ProjectsAdmin from "./pages/admin/Projects";
import BlogAdmin from "./pages/admin/Blog";
import TestimonialsAdmin from "./pages/admin/Testimonials";
import ContactsAdmin from "./pages/admin/Contacts";
import SubscribersAdmin from "./pages/admin/Subscribers";
import ServicesAdmin from "./pages/admin/Services";
import BookingsAdmin from "./pages/admin/Bookings";
import AvailabilityAdmin from "./pages/admin/Availability";
import AnalyticsAdmin from "./pages/admin/Analytics";
import SettingsAdmin from "./pages/admin/Settings";
import ResumeAdmin from "./pages/admin/Resume";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/ai-expertise" element={<AIExpertise />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/admin" element={<Dashboard />} />
              <Route path="/admin/projects" element={<ProjectsAdmin />} />
              <Route path="/admin/blog" element={<BlogAdmin />} />
              <Route path="/admin/testimonials" element={<TestimonialsAdmin />} />
              <Route path="/admin/contacts" element={<ContactsAdmin />} />
              <Route path="/admin/subscribers" element={<SubscribersAdmin />} />
              <Route path="/admin/services" element={<ServicesAdmin />} />
              <Route path="/admin/resume" element={<ResumeAdmin />} />
              <Route path="/admin/bookings" element={<BookingsAdmin />} />
              <Route path="/admin/availability" element={<AvailabilityAdmin />} />
              <Route path="/admin/analytics" element={<AnalyticsAdmin />} />
              <Route path="/admin/settings" element={<SettingsAdmin />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
