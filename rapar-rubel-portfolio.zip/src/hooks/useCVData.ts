import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface CVData {
  id: string;
  full_name: string;
  title: string;
  email: string | null;
  phone: string | null;
  location: string | null;
  linkedin_url: string | null;
  website_url: string | null;
  photo_url: string | null;
  summary: string | null;
}

export interface CVExperience {
  id: string;
  job_title: string;
  company: string;
  start_date: string;
  end_date: string | null;
  is_current: boolean | null;
  achievements: string[] | null;
  display_order: number | null;
}

export interface CVEducation {
  id: string;
  degree: string;
  institution: string;
  year: string | null;
  display_order: number | null;
}

export interface CVCertification {
  id: string;
  name: string;
  issuer: string | null;
  year: string | null;
  display_order: number | null;
}

export interface CVSkill {
  id: string;
  name: string;
  category: string | null;
  display_order: number | null;
}

export interface CVCompetency {
  id: string;
  title: string;
  subtitle: string | null;
  color: string | null;
  display_order: number | null;
}

export interface CVVenture {
  id: string;
  name: string;
  description: string | null;
  display_order: number | null;
}

export interface CVLanguage {
  id: string;
  language: string;
  proficiency: string;
  display_order: number | null;
}

export const useCVData = () => {
  const cvDataQuery = useQuery({
    queryKey: ["cv-data"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_data")
        .select("*")
        .limit(1)
        .single();
      if (error) throw error;
      return data as CVData;
    },
  });

  const experienceQuery = useQuery({
    queryKey: ["cv-experience"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_experience")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVExperience[];
    },
  });

  const educationQuery = useQuery({
    queryKey: ["cv-education"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_education")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVEducation[];
    },
  });

  const certificationsQuery = useQuery({
    queryKey: ["cv-certifications"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_certifications")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVCertification[];
    },
  });

  const skillsQuery = useQuery({
    queryKey: ["cv-skills"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_skills")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVSkill[];
    },
  });

  const competenciesQuery = useQuery({
    queryKey: ["cv-competencies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_competencies")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVCompetency[];
    },
  });

  const venturesQuery = useQuery({
    queryKey: ["cv-ventures"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_ventures")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVVenture[];
    },
  });

  const languagesQuery = useQuery({
    queryKey: ["cv-languages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("cv_languages")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as CVLanguage[];
    },
  });

  const isLoading =
    cvDataQuery.isLoading ||
    experienceQuery.isLoading ||
    educationQuery.isLoading ||
    certificationsQuery.isLoading ||
    skillsQuery.isLoading ||
    competenciesQuery.isLoading ||
    venturesQuery.isLoading ||
    languagesQuery.isLoading;

  return {
    cvData: cvDataQuery.data,
    experience: experienceQuery.data || [],
    education: educationQuery.data || [],
    certifications: certificationsQuery.data || [],
    skills: skillsQuery.data || [],
    competencies: competenciesQuery.data || [],
    ventures: venturesQuery.data || [],
    languages: languagesQuery.data || [],
    isLoading,
  };
};
