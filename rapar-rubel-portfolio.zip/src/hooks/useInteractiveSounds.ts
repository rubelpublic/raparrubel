import { useCallback, useRef, useEffect } from 'react';

// Sound themes with unique frequencies
export const SOUND_THEMES = {
  space: {
    name: 'Space',
    icon: '🚀',
    frequencies: [110, 146.83, 174.61, 220, 261.63, 293.66, 329.63, 392, 440, 493.88, 523.25, 587.33],
    oscillatorType: 'sine' as OscillatorType,
    filterFreq: 2000,
    reverbTime: 0.4,
    attackTime: 0.02,
    releaseTime: 0.8,
  },
  ocean: {
    name: 'Ocean',
    icon: '🌊',
    frequencies: [65.41, 82.41, 98, 130.81, 164.81, 196, 220, 261.63, 293.66, 329.63, 349.23, 392],
    oscillatorType: 'triangle' as OscillatorType,
    filterFreq: 1200,
    reverbTime: 0.6,
    attackTime: 0.05,
    releaseTime: 1.2,
  },
  forest: {
    name: 'Forest',
    icon: '🌲',
    frequencies: [196, 220, 246.94, 261.63, 293.66, 329.63, 349.23, 392, 440, 493.88, 523.25, 587.33],
    oscillatorType: 'sine' as OscillatorType,
    filterFreq: 3000,
    reverbTime: 0.3,
    attackTime: 0.01,
    releaseTime: 0.5,
  },
  crystal: {
    name: 'Crystal',
    icon: '💎',
    frequencies: [523.25, 587.33, 659.25, 698.46, 783.99, 880, 987.77, 1046.5, 1174.66, 1318.51, 1396.91, 1567.98],
    oscillatorType: 'sine' as OscillatorType,
    filterFreq: 4000,
    reverbTime: 0.5,
    attackTime: 0.005,
    releaseTime: 1.0,
  },
  rain: {
    name: 'Rain',
    icon: '🌧️',
    frequencies: [174.61, 196, 220, 246.94, 261.63, 293.66, 329.63, 349.23, 392, 440, 466.16, 493.88],
    oscillatorType: 'triangle' as OscillatorType,
    filterFreq: 1500,
    reverbTime: 0.7,
    attackTime: 0.03,
    releaseTime: 0.9,
  },
};

export type SoundTheme = keyof typeof SOUND_THEMES;

interface UseInteractiveSoundsOptions {
  enabled?: boolean;
  volume?: number;
  theme?: SoundTheme;
}

// Grid-based position memory - divides screen into cells
const GRID_SIZE = 12; // 12x12 grid = 144 unique sound positions

export const useInteractiveSounds = (options: UseInteractiveSoundsOptions = {}) => {
  const { enabled = true, volume = 0.2, theme = 'space' } = options;
  const audioContextRef = useRef<AudioContext | null>(null);
  const positionSoundMapRef = useRef<Map<string, number>>(new Map());
  const lastPlayTimeRef = useRef(0);

  const initAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContextRef.current;
  }, []);

  // Get consistent sound index for a position
  const getSoundIndexForPosition = useCallback((x: number, y: number) => {
    const gridX = Math.floor((x / window.innerWidth) * GRID_SIZE);
    const gridY = Math.floor((y / window.innerHeight) * GRID_SIZE);
    const key = `${gridX}-${gridY}`;
    
    const themeConfig = SOUND_THEMES[theme];
    
    if (!positionSoundMapRef.current.has(key)) {
      // Assign a random but consistent note for this position
      const noteIndex = Math.floor(Math.random() * themeConfig.frequencies.length);
      positionSoundMapRef.current.set(key, noteIndex);
    }
    
    return positionSoundMapRef.current.get(key)!;
  }, [theme]);

  const playNote = useCallback((x: number, y: number) => {
    if (!enabled) return;
    
    // Faster throttle - 50ms for more responsive sounds
    const now = Date.now();
    if (now - lastPlayTimeRef.current < 50) return;
    lastPlayTimeRef.current = now;

    try {
      const ctx = initAudioContext();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const themeConfig = SOUND_THEMES[theme];
      const noteIndex = getSoundIndexForPosition(x, y);
      const frequency = themeConfig.frequencies[noteIndex];
      
      const currentTime = ctx.currentTime;

      // Master gain with fast attack
      const masterGain = ctx.createGain();
      masterGain.connect(ctx.destination);
      masterGain.gain.setValueAtTime(0, currentTime);
      masterGain.gain.linearRampToValueAtTime(volume, currentTime + themeConfig.attackTime);
      masterGain.gain.exponentialRampToValueAtTime(0.001, currentTime + themeConfig.releaseTime);

      // Main oscillator
      const osc = ctx.createOscillator();
      osc.type = themeConfig.oscillatorType;
      osc.frequency.setValueAtTime(frequency, currentTime);
      
      // Filter for tone shaping
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(themeConfig.filterFreq, currentTime);
      filter.frequency.exponentialRampToValueAtTime(themeConfig.filterFreq * 0.3, currentTime + themeConfig.releaseTime);
      filter.Q.value = 1;
      
      osc.connect(filter);
      filter.connect(masterGain);
      osc.start(currentTime);
      osc.stop(currentTime + themeConfig.releaseTime + 0.1);

      // Harmonic layer for richness
      const harmonicOsc = ctx.createOscillator();
      harmonicOsc.type = 'sine';
      harmonicOsc.frequency.setValueAtTime(frequency * 2, currentTime);
      const harmonicGain = ctx.createGain();
      harmonicGain.gain.setValueAtTime(0, currentTime);
      harmonicGain.gain.linearRampToValueAtTime(volume * 0.15, currentTime + themeConfig.attackTime);
      harmonicGain.gain.exponentialRampToValueAtTime(0.001, currentTime + themeConfig.releaseTime * 0.7);
      harmonicOsc.connect(harmonicGain);
      harmonicGain.connect(ctx.destination);
      harmonicOsc.start(currentTime);
      harmonicOsc.stop(currentTime + themeConfig.releaseTime);

      // Subtle delay for atmosphere
      const delayNode = ctx.createDelay(0.5);
      delayNode.delayTime.value = themeConfig.reverbTime;
      const feedbackGain = ctx.createGain();
      feedbackGain.gain.value = 0.2;
      const delayGain = ctx.createGain();
      delayGain.gain.value = 0.15;
      
      masterGain.connect(delayNode);
      delayNode.connect(feedbackGain);
      feedbackGain.connect(delayNode);
      delayNode.connect(delayGain);
      delayGain.connect(ctx.destination);

    } catch (error) {
      console.warn('Audio playback error:', error);
    }
  }, [enabled, volume, theme, initAudioContext, getSoundIndexForPosition]);

  // Reset position memory when theme changes
  useEffect(() => {
    positionSoundMapRef.current.clear();
  }, [theme]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  return { playNote, initAudioContext };
};
