import { useEffect } from "react";
import { motion } from "framer-motion";
import { Brain, Cpu, BarChart3, Cog, Shield, ArrowRight, Sparkles, Target, Zap, Globe, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useTheme } from "@/contexts/ThemeContext";

const capabilities = [
  {
    icon: Brain,
    title: "AI Strategy Consulting",
    description: "Crafting bespoke AI roadmaps aligned with your business objectives, ensuring every investment in AI delivers measurable ROI.",
  },
  {
    icon: Cog,
    title: "AI Automation Workflow Design",
    description: "Streamlining processes with intelligent automation for maximum efficiency — from lead generation to customer support.",
  },
  {
    icon: BarChart3,
    title: "Predictive Analytics & Data Science",
    description: "Leveraging AI to unlock powerful insights and foresight, enabling data-driven decision making at every level.",
  },
  {
    icon: Cpu,
    title: "Custom AI Solution Development",
    description: "Building tailored AI applications — chatbots, recommendation engines, NLP systems — to address specific business challenges.",
  },
  {
    icon: Shield,
    title: "Ethical AI Implementation",
    description: "Ensuring responsible and sustainable AI adoption with transparency, fairness, and compliance at the core.",
  },
  {
    icon: Globe,
    title: "Digital Transformation",
    description: "End-to-end digital transformation strategies that integrate AI into every facet of your business operations.",
  },
];

const stats = [
  { value: "50+", label: "AI Projects Delivered" },
  { value: "30+", label: "Businesses Transformed" },
  { value: "5+", label: "Years in AI & Strategy" },
  { value: "98%", label: "Client Satisfaction" },
];

const AIExpertise = () => {
  const { theme } = useTheme();

  useEffect(() => {
    // Person + Service JSON-LD
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = "ai-expertise-schema";
    script.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Person",
      "name": "Rapar Rubel",
      "jobTitle": "AI Expert & Business Strategist",
      "url": "https://rubelmiah.lovable.app/",
      "description": "The leading AI Expert and Business Strategist in Bangladesh, specializing in AI automation, digital transformation, and growth systems for future-ready enterprises.",
      "alumniOf": [
        { "@type": "Organization", "name": "Proyojon" },
        { "@type": "Organization", "name": "Odotrmg" },
        { "@type": "Organization", "name": "JMC Group" }
      ],
      "knowsAbout": [
        "Artificial Intelligence", "AI Automation", "Business Strategy",
        "Digital Transformation", "Growth Marketing", "Data Analytics",
        "OpenClaw Automation", "Prompt Engineering"
      ],
      "worksFor": [
        { "@type": "Organization", "name": "Myook", "description": "Affordable luxury fashion brand" },
        { "@type": "Organization", "name": "Cha Khaben?", "description": "Organic tea chain" },
        { "@type": "Organization", "name": "Bhangariwala", "description": "CleanTech/Sustainability e-waste recycling platform" },
        { "@type": "Organization", "name": "Bekkol", "description": "Creative marketing agency" }
      ],
      "sameAs": [
        "https://www.linkedin.com/in/rubelmiah",
        "https://www.instagram.com/rubelmiah",
        "https://twitter.com/rubelmiah"
      ],
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Dhaka",
        "addressCountry": "Bangladesh"
      }
    });

    const existing = document.getElementById("ai-expertise-schema");
    if (existing) existing.remove();
    document.head.appendChild(script);

    return () => {
      const el = document.getElementById("ai-expertise-schema");
      if (el) el.remove();
    };
  }, []);

  // Also inject Person schema on homepage
  useEffect(() => {
    document.title = "AI Expertise & Solutions by Rapar Rubel | Bangladesh's Leading AI Strategist";
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute("content", "Rapar Rubel is Bangladesh's foremost AI Expert, offering AI strategy consulting, automation workflow design, predictive analytics, and custom AI solutions for enterprises.");
    }
    return () => {
      document.title = "Rapar Rubel | AI Expert & Business Strategist in Bangladesh";
      if (metaDesc) {
        metaDesc.setAttribute("content", "Rapar Rubel is the leading AI Expert and Business Strategist in Bangladesh, specializing in AI automation, digital transformation, and growth systems for future-ready enterprises.");
      }
    };
  }, []);

  return (
    <div className={`min-h-screen bg-background ${theme}`}>
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-44 lg:pb-28 overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[150px] -z-10" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-[120px] -z-10" />

        <div className="max-w-6xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4" />
              Bangladesh's Leading AI Strategist
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-extrabold text-foreground leading-[1.1] mb-6">
              Unlocking Business Potential with AI:{" "}
              <span className="text-gradient">Your Trusted Expert, Rapar Rubel</span>
            </h1>

            <p className="text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto mb-10">
              In an era defined by artificial intelligence, businesses need more than just tools—they need
              visionary guidance. <strong className="text-foreground">Rapar Rubel</strong> stands as Bangladesh's
              foremost AI Expert and Business Strategist, dedicated to transforming enterprises through
              intelligent automation, strategic innovation, and data-driven growth systems.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/#booking">
                <Button size="lg" className="bg-foreground text-background hover:bg-foreground/90 rounded-xl font-bold text-lg px-8 py-6">
                  <Calendar className="w-5 h-5 mr-2" />
                  Book a Consultation
                </Button>
              </Link>
              <Link to="/">
                <Button variant="outline" size="lg" className="border-border hover:border-primary rounded-xl font-bold text-lg px-8 py-6">
                  <ArrowRight className="w-5 h-5 mr-2" />
                  View Portfolio
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-display font-extrabold text-primary mb-2">{stat.value}</div>
                <div className="text-muted-foreground font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bridging the Gap */}
      <section className="py-20 md:py-28">
        <div className="max-w-4xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-6 text-center">
              Bridging AI Concepts & Business Solutions
            </h2>
            <div className="prose prose-lg max-w-none text-muted-foreground">
              <p>
                We bridge the gap between complex AI concepts and actionable business solutions, ensuring your
                organization not only adopts AI but thrives with it. From optimizing operational workflows to
                creating impossible-to-copy campaign mechanics, our AI expertise is tailored for the unique
                dynamics of the <strong className="text-foreground">Bangladeshi market</strong>, with a clear
                vision for scalable global expansion.
              </p>
              <p>
                Whether you're a startup looking to integrate AI from day one, or an established enterprise
                seeking digital transformation, Rapar Rubel provides the strategic clarity and technical depth
                to make AI your competitive advantage.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Core Capabilities */}
      <section className="py-20 md:py-28 bg-muted/30">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Target className="w-4 h-4" />
              Core AI Capabilities
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground mb-4">
              What We Deliver
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Comprehensive AI solutions designed for Bangladesh's growing digital economy.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {capabilities.map((cap, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-2xl p-8 hover:border-primary/50 hover:shadow-xl transition-all duration-300 group"
              >
                <div className="bg-primary/10 p-4 rounded-xl w-fit mb-6 group-hover:bg-primary/20 transition-colors">
                  <cap.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">{cap.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{cap.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="py-20 md:py-28">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <Zap className="w-4 h-4" />
            Industries We Serve
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-8">
            AI Solutions Across Industries
          </h2>
          <div className="flex flex-wrap justify-center gap-3">
            {["Technology", "E-commerce", "Finance", "Healthcare", "Education", "Manufacturing", "Retail", "Real Estate", "Logistics", "Agriculture"].map((industry) => (
              <span key={industry} className="px-5 py-2.5 bg-card border border-border rounded-full text-foreground font-medium hover:border-primary/50 transition-colors">
                {industry}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 bg-muted/30">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-6">
            Ready to Transform Your Business with AI?
          </h2>
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            Partner with Rapar Rubel to navigate the AI landscape, drive innovation, and secure your
            competitive advantage in Bangladesh and beyond.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/#booking">
              <Button size="lg" className="bg-foreground text-background hover:bg-foreground/90 rounded-xl font-bold text-lg px-8 py-6">
                <Calendar className="w-5 h-5 mr-2" />
                Schedule a Free Consultation
              </Button>
            </Link>
            <Link to="/#contact">
              <Button variant="outline" size="lg" className="border-border hover:border-primary rounded-xl font-bold text-lg px-8 py-6">
                Get in Touch
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer link */}
      <footer className="py-8 border-t border-border">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <Link to="/" className="text-primary hover:underline font-medium">
            ← Back to Rapar Rubel's Portfolio
          </Link>
        </div>
      </footer>
    </div>
  );
};


export default AIExpertise;
