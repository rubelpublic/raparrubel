import { useState, useEffect } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trash2, Clock } from 'lucide-react';

interface AvailableSlot {
  id: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  is_active: boolean | null;
}

const DAYS_OF_WEEK = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

const AvailabilityAdmin = () => {
  const [slots, setSlots] = useState<AvailableSlot[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [newSlot, setNewSlot] = useState({
    day_of_week: 1,
    start_time: '09:00',
    end_time: '10:00',
  });
  const { toast } = useToast();

  const fetchSlots = async () => {
    const { data, error } = await supabase
      .from('available_slots')
      .select('*')
      .order('day_of_week', { ascending: true })
      .order('start_time', { ascending: true });

    if (error) {
      toast({ title: 'Error loading slots', description: error.message, variant: 'destructive' });
    } else {
      setSlots(data || []);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchSlots();
  }, []);

  const addSlot = async () => {
    if (newSlot.start_time >= newSlot.end_time) {
      toast({ title: 'Invalid time range', description: 'End time must be after start time', variant: 'destructive' });
      return;
    }

    const { error } = await supabase.from('available_slots').insert({
      day_of_week: newSlot.day_of_week,
      start_time: newSlot.start_time,
      end_time: newSlot.end_time,
      is_active: true,
    });

    if (error) {
      toast({ title: 'Error adding slot', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Slot added successfully' });
      fetchSlots();
    }
  };

  const toggleSlot = async (id: string, isActive: boolean) => {
    const { error } = await supabase
      .from('available_slots')
      .update({ is_active: isActive })
      .eq('id', id);

    if (error) {
      toast({ title: 'Error updating slot', description: error.message, variant: 'destructive' });
    } else {
      fetchSlots();
    }
  };

  const deleteSlot = async (id: string) => {
    if (!confirm('Delete this time slot?')) return;

    const { error } = await supabase.from('available_slots').delete().eq('id', id);

    if (error) {
      toast({ title: 'Error deleting slot', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Slot deleted' });
      fetchSlots();
    }
  };

  const groupedSlots = DAYS_OF_WEEK.map((day, index) => ({
    day,
    dayIndex: index,
    slots: slots.filter((slot) => slot.day_of_week === index),
  }));

  return (
    <AdminLayout title="Availability" description="Set your available time slots for bookings">
      {/* Add New Slot */}
      <Card className="glass border-secondary/50 mb-6">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Plus className="h-5 w-5" /> Add New Time Slot
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 items-end">
            <div className="space-y-2">
              <Label>Day of Week</Label>
              <select
                value={newSlot.day_of_week}
                onChange={(e) => setNewSlot({ ...newSlot, day_of_week: parseInt(e.target.value) })}
                className="h-10 px-3 rounded-md bg-secondary/50 border border-secondary text-foreground"
              >
                {DAYS_OF_WEEK.map((day, index) => (
                  <option key={day} value={index}>
                    {day}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label>Start Time</Label>
              <Input
                type="time"
                value={newSlot.start_time}
                onChange={(e) => setNewSlot({ ...newSlot, start_time: e.target.value })}
                className="bg-secondary/50 border-secondary w-32"
              />
            </div>
            <div className="space-y-2">
              <Label>End Time</Label>
              <Input
                type="time"
                value={newSlot.end_time}
                onChange={(e) => setNewSlot({ ...newSlot, end_time: e.target.value })}
                className="bg-secondary/50 border-secondary w-32"
              />
            </div>
            <Button onClick={addSlot} className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" /> Add Slot
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Schedule */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {groupedSlots.map(({ day, dayIndex, slots: daySlots }) => (
          <Card key={day} className="glass border-secondary/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                {day}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {daySlots.length === 0 ? (
                <p className="text-sm text-muted-foreground">No slots set</p>
              ) : (
                <div className="space-y-2">
                  {daySlots.map((slot) => (
                    <div
                      key={slot.id}
                      className={`flex items-center justify-between p-2 rounded-md ${
                        slot.is_active ? 'bg-primary/10 border border-primary/20' : 'bg-secondary/30 border border-secondary/50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={slot.is_active ?? true}
                          onCheckedChange={(checked) => toggleSlot(slot.id, checked)}
                        />
                        <span className={`text-sm ${slot.is_active ? 'text-foreground' : 'text-muted-foreground line-through'}`}>
                          {slot.start_time.slice(0, 5)} - {slot.end_time.slice(0, 5)}
                        </span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteSlot(slot.id)}
                        className="h-6 w-6 p-0 text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {isLoading && (
        <div className="text-center py-8 text-muted-foreground">Loading availability...</div>
      )}
    </AdminLayout>
  );
};

export default AvailabilityAdmin;
