import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Loader2, Save, Plus, Trash2, GripVertical, X } from "lucide-react";
import { Label } from "@/components/ui/label";

const Resume = () => {
  const queryClient = useQueryClient();

  // Fetch CV data
  const { data: cvData, isLoading: cvLoading } = useQuery({
    queryKey: ["admin-cv-data"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_data").select("*").limit(1).single();
      if (error) throw error;
      return data;
    },
  });

  const { data: experience = [] } = useQuery({
    queryKey: ["admin-cv-experience"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_experience").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: education = [] } = useQuery({
    queryKey: ["admin-cv-education"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_education").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: certifications = [] } = useQuery({
    queryKey: ["admin-cv-certifications"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_certifications").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: skills = [] } = useQuery({
    queryKey: ["admin-cv-skills"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_skills").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: competencies = [] } = useQuery({
    queryKey: ["admin-cv-competencies"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_competencies").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: ventures = [] } = useQuery({
    queryKey: ["admin-cv-ventures"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_ventures").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: languages = [] } = useQuery({
    queryKey: ["admin-cv-languages"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cv_languages").select("*").order("display_order");
      if (error) throw error;
      return data;
    },
  });

  // Form states
  const [profileForm, setProfileForm] = useState({
    full_name: "",
    title: "",
    email: "",
    phone: "",
    location: "",
    linkedin_url: "",
    website_url: "",
    photo_url: "",
    summary: "",
  });

  // Update form when data loads
  useState(() => {
    if (cvData) {
      setProfileForm({
        full_name: cvData.full_name || "",
        title: cvData.title || "",
        email: cvData.email || "",
        phone: cvData.phone || "",
        location: cvData.location || "",
        linkedin_url: cvData.linkedin_url || "",
        website_url: cvData.website_url || "",
        photo_url: cvData.photo_url || "",
        summary: cvData.summary || "",
      });
    }
  });

  // Mutations
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileForm) => {
      if (!cvData?.id) throw new Error("No CV data found");
      const { error } = await supabase.from("cv_data").update(data).eq("id", cvData.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-data"] });
      queryClient.invalidateQueries({ queryKey: ["cv-data"] });
      toast.success("Profile updated successfully");
    },
    onError: () => toast.error("Failed to update profile"),
  });

  const addExperienceMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_experience").insert({
        job_title: "New Position",
        company: "Company Name",
        start_date: new Date().getFullYear().toString(),
        display_order: experience.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-experience"] });
      toast.success("Experience added");
    },
  });

  const deleteExperienceMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_experience").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-experience"] });
      queryClient.invalidateQueries({ queryKey: ["cv-experience"] });
      toast.success("Experience deleted");
    },
  });

  const updateExperienceMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; [key: string]: any }) => {
      const { error } = await supabase.from("cv_experience").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-experience"] });
      queryClient.invalidateQueries({ queryKey: ["cv-experience"] });
    },
  });

  const addSkillMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_skills").insert({
        name: "New Skill",
        display_order: skills.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-skills"] });
      toast.success("Skill added");
    },
  });

  const deleteSkillMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_skills").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-skills"] });
      queryClient.invalidateQueries({ queryKey: ["cv-skills"] });
      toast.success("Skill deleted");
    },
  });

  const updateSkillMutation = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const { error } = await supabase.from("cv_skills").update({ name }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-skills"] });
      queryClient.invalidateQueries({ queryKey: ["cv-skills"] });
    },
  });

  // Education mutations
  const addEducationMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_education").insert({
        degree: "New Degree",
        institution: "Institution Name",
        display_order: education.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-education"] });
      toast.success("Education added");
    },
  });

  const deleteEducationMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_education").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-education"] });
      queryClient.invalidateQueries({ queryKey: ["cv-education"] });
      toast.success("Education deleted");
    },
  });

  const updateEducationMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; [key: string]: any }) => {
      const { error } = await supabase.from("cv_education").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-education"] });
      queryClient.invalidateQueries({ queryKey: ["cv-education"] });
    },
  });

  // Certifications mutations
  const addCertificationMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_certifications").insert({
        name: "New Certification",
        display_order: certifications.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-certifications"] });
      toast.success("Certification added");
    },
  });

  const deleteCertificationMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_certifications").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-certifications"] });
      queryClient.invalidateQueries({ queryKey: ["cv-certifications"] });
      toast.success("Certification deleted");
    },
  });

  const updateCertificationMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; [key: string]: any }) => {
      const { error } = await supabase.from("cv_certifications").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-certifications"] });
      queryClient.invalidateQueries({ queryKey: ["cv-certifications"] });
    },
  });

  // Languages mutations
  const addLanguageMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_languages").insert({
        language: "New Language",
        proficiency: "Fluent",
        display_order: languages.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-languages"] });
      toast.success("Language added");
    },
  });

  const deleteLanguageMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_languages").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-languages"] });
      queryClient.invalidateQueries({ queryKey: ["cv-languages"] });
      toast.success("Language deleted");
    },
  });

  const updateLanguageMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; [key: string]: any }) => {
      const { error } = await supabase.from("cv_languages").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-languages"] });
      queryClient.invalidateQueries({ queryKey: ["cv-languages"] });
    },
  });

  // Competencies mutations
  const addCompetencyMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_competencies").insert({
        title: "New Competency",
        display_order: competencies.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-competencies"] });
      toast.success("Competency added");
    },
  });

  const deleteCompetencyMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_competencies").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-competencies"] });
      queryClient.invalidateQueries({ queryKey: ["cv-competencies"] });
      toast.success("Competency deleted");
    },
  });

  const updateCompetencyMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; [key: string]: any }) => {
      const { error } = await supabase.from("cv_competencies").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-competencies"] });
      queryClient.invalidateQueries({ queryKey: ["cv-competencies"] });
    },
  });

  // Ventures mutations
  const addVentureMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("cv_ventures").insert({
        name: "New Venture",
        display_order: ventures.length + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-ventures"] });
      toast.success("Venture added");
    },
  });

  const deleteVentureMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cv_ventures").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-ventures"] });
      queryClient.invalidateQueries({ queryKey: ["cv-ventures"] });
      toast.success("Venture deleted");
    },
  });

  const updateVentureMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; [key: string]: any }) => {
      const { error } = await supabase.from("cv_ventures").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-cv-ventures"] });
      queryClient.invalidateQueries({ queryKey: ["cv-ventures"] });
    },
  });

  if (cvLoading) {
    return (
      <AdminLayout title="Resume / CV Manager">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Resume / CV Manager" description="Update your CV content that appears in the downloadable resume">
      <Tabs defaultValue="profile" className="space-y-4">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="experience">Experience</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="education">Education</TabsTrigger>
            <TabsTrigger value="competencies">Competencies</TabsTrigger>
            <TabsTrigger value="ventures">Ventures</TabsTrigger>
            <TabsTrigger value="languages">Languages</TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input
                      value={profileForm.full_name || cvData?.full_name || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, full_name: e.target.value }))}
                      placeholder="Your full name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Professional Title</Label>
                    <Input
                      value={profileForm.title || cvData?.title || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, title: e.target.value }))}
                      placeholder="e.g., Business Strategist • AI Expert"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={profileForm.email || cvData?.email || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, email: e.target.value }))}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input
                      value={profileForm.phone || cvData?.phone || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, phone: e.target.value }))}
                      placeholder="+1 234 567 890"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      value={profileForm.location || cvData?.location || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, location: e.target.value }))}
                      placeholder="City, Country"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Photo URL</Label>
                    <Input
                      value={profileForm.photo_url || cvData?.photo_url || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, photo_url: e.target.value }))}
                      placeholder="https://your-photo-url.com/photo.jpg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>LinkedIn URL</Label>
                    <Input
                      value={profileForm.linkedin_url || cvData?.linkedin_url || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, linkedin_url: e.target.value }))}
                      placeholder="linkedin.com/in/yourprofile"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Website URL</Label>
                    <Input
                      value={profileForm.website_url || cvData?.website_url || ""}
                      onChange={(e) => setProfileForm((p) => ({ ...p, website_url: e.target.value }))}
                      placeholder="yourwebsite.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Professional Summary</Label>
                  <Textarea
                    value={profileForm.summary || cvData?.summary || ""}
                    onChange={(e) => setProfileForm((p) => ({ ...p, summary: e.target.value }))}
                    placeholder="Brief professional summary..."
                    rows={4}
                  />
                </div>

                {profileForm.photo_url && (
                  <div className="flex items-center gap-4">
                    <Label>Preview:</Label>
                    <img
                      src={profileForm.photo_url}
                      alt="Profile preview"
                      className="w-20 h-20 rounded-lg object-cover border"
                    />
                  </div>
                )}

                <Button
                  onClick={() => updateProfileMutation.mutate(profileForm)}
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Profile
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Experience Tab */}
          <TabsContent value="experience" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Work Experience</h3>
              <Button onClick={() => addExperienceMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Experience
              </Button>
            </div>

            <div className="space-y-4">
              {experience.map((exp: any) => (
                <Card key={exp.id}>
                  <CardContent className="pt-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{exp.job_title}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteExperienceMutation.mutate(exp.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        defaultValue={exp.job_title}
                        placeholder="Job Title"
                        onBlur={(e) =>
                          updateExperienceMutation.mutate({ id: exp.id, job_title: e.target.value })
                        }
                      />
                      <Input
                        defaultValue={exp.company}
                        placeholder="Company"
                        onBlur={(e) =>
                          updateExperienceMutation.mutate({ id: exp.id, company: e.target.value })
                        }
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <Input
                        defaultValue={exp.start_date}
                        placeholder="Start Date (e.g., 2020)"
                        onBlur={(e) =>
                          updateExperienceMutation.mutate({ id: exp.id, start_date: e.target.value })
                        }
                      />
                      <Input
                        defaultValue={exp.end_date || ""}
                        placeholder="End Date (or leave empty)"
                        onBlur={(e) =>
                          updateExperienceMutation.mutate({ id: exp.id, end_date: e.target.value })
                        }
                      />
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={exp.is_current}
                          onChange={(e) =>
                            updateExperienceMutation.mutate({ id: exp.id, is_current: e.target.checked })
                          }
                        />
                        <Label>Current</Label>
                      </div>
                    </div>

                    <Textarea
                      defaultValue={(exp.achievements || []).join("\n")}
                      placeholder="Achievements (one per line)"
                      rows={3}
                      onBlur={(e) =>
                        updateExperienceMutation.mutate({
                          id: exp.id,
                          achievements: e.target.value.split("\n").filter(Boolean),
                        })
                      }
                    />
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Technical Skills</h3>
              <Button onClick={() => addSkillMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Skill
              </Button>
            </div>

            <Card>
              <CardContent className="pt-4">
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill: any) => (
                    <div
                      key={skill.id}
                      className="flex items-center gap-1 bg-secondary px-3 py-1 rounded-full"
                    >
                      <Input
                        defaultValue={skill.name}
                        className="h-6 w-24 text-xs border-none bg-transparent p-0"
                        onBlur={(e) => updateSkillMutation.mutate({ id: skill.id, name: e.target.value })}
                      />
                      <button
                        onClick={() => deleteSkillMutation.mutate(skill.id)}
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Education Tab */}
          <TabsContent value="education" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Education</h3>
              <Button onClick={() => addEducationMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Education
              </Button>
            </div>

            <div className="space-y-4">
              {education.map((edu: any) => (
                <Card key={edu.id}>
                  <CardContent className="pt-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{edu.degree}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteEducationMutation.mutate(edu.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        defaultValue={edu.degree}
                        placeholder="Degree"
                        onBlur={(e) =>
                          updateEducationMutation.mutate({ id: edu.id, degree: e.target.value })
                        }
                      />
                      <Input
                        defaultValue={edu.institution}
                        placeholder="Institution"
                        onBlur={(e) =>
                          updateEducationMutation.mutate({ id: edu.id, institution: e.target.value })
                        }
                      />
                    </div>

                    <Input
                      defaultValue={edu.year || ""}
                      placeholder="Year (e.g., 2018 - 2022)"
                      onBlur={(e) =>
                        updateEducationMutation.mutate({ id: edu.id, year: e.target.value })
                      }
                    />
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex justify-between items-center mt-8">
              <h3 className="font-semibold">Certifications</h3>
              <Button onClick={() => addCertificationMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Certification
              </Button>
            </div>

            <div className="space-y-4">
              {certifications.map((cert: any) => (
                <Card key={cert.id}>
                  <CardContent className="pt-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{cert.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteCertificationMutation.mutate(cert.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <Input
                        defaultValue={cert.name}
                        placeholder="Certification Name"
                        onBlur={(e) =>
                          updateCertificationMutation.mutate({ id: cert.id, name: e.target.value })
                        }
                      />
                      <Input
                        defaultValue={cert.issuer || ""}
                        placeholder="Issuer"
                        onBlur={(e) =>
                          updateCertificationMutation.mutate({ id: cert.id, issuer: e.target.value })
                        }
                      />
                      <Input
                        defaultValue={cert.year || ""}
                        placeholder="Year"
                        onBlur={(e) =>
                          updateCertificationMutation.mutate({ id: cert.id, year: e.target.value })
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Competencies Tab */}
          <TabsContent value="competencies" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Core Competencies</h3>
              <Button onClick={() => addCompetencyMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Competency
              </Button>
            </div>

            <div className="space-y-4">
              {competencies.map((comp: any) => (
                <Card key={comp.id}>
                  <CardContent className="pt-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{comp.title}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteCompetencyMutation.mutate(comp.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        defaultValue={comp.title}
                        placeholder="Competency Title"
                        onBlur={(e) =>
                          updateCompetencyMutation.mutate({ id: comp.id, title: e.target.value })
                        }
                      />
                      <Input
                        defaultValue={comp.subtitle || ""}
                        placeholder="Subtitle (optional)"
                        onBlur={(e) =>
                          updateCompetencyMutation.mutate({ id: comp.id, subtitle: e.target.value })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Color Theme</Label>
                      <select
                        defaultValue={comp.color || "cyan"}
                        className="w-full p-2 rounded border bg-background"
                        onChange={(e) =>
                          updateCompetencyMutation.mutate({ id: comp.id, color: e.target.value })
                        }
                      >
                        <option value="cyan">Cyan</option>
                        <option value="purple">Purple</option>
                        <option value="green">Green</option>
                        <option value="orange">Orange</option>
                        <option value="pink">Pink</option>
                        <option value="blue">Blue</option>
                      </select>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Ventures Tab */}
          <TabsContent value="ventures" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Ventures & Projects</h3>
              <Button onClick={() => addVentureMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Venture
              </Button>
            </div>

            <div className="space-y-4">
              {ventures.map((venture: any) => (
                <Card key={venture.id}>
                  <CardContent className="pt-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{venture.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteVentureMutation.mutate(venture.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>

                    <Input
                      defaultValue={venture.name}
                      placeholder="Venture Name"
                      onBlur={(e) =>
                        updateVentureMutation.mutate({ id: venture.id, name: e.target.value })
                      }
                    />

                    <Textarea
                      defaultValue={venture.description || ""}
                      placeholder="Description"
                      rows={3}
                      onBlur={(e) =>
                        updateVentureMutation.mutate({ id: venture.id, description: e.target.value })
                      }
                    />
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Languages Tab */}
          <TabsContent value="languages" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Languages</h3>
              <Button onClick={() => addLanguageMutation.mutate()} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Language
              </Button>
            </div>

            <div className="space-y-4">
              {languages.map((lang: any) => (
                <Card key={lang.id}>
                  <CardContent className="pt-4 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">{lang.language}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteLanguageMutation.mutate(lang.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        defaultValue={lang.language}
                        placeholder="Language"
                        onBlur={(e) =>
                          updateLanguageMutation.mutate({ id: lang.id, language: e.target.value })
                        }
                      />
                      <select
                        defaultValue={lang.proficiency}
                        className="w-full p-2 rounded border bg-background"
                        onChange={(e) =>
                          updateLanguageMutation.mutate({ id: lang.id, proficiency: e.target.value })
                        }
                      >
                        <option value="Native">Native</option>
                        <option value="Fluent">Fluent</option>
                        <option value="Proficient">Proficient</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Basic">Basic</option>
                      </select>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
    </AdminLayout>
  );
};

export default Resume;
