import { useState, useEffect } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Calendar, Clock, User, Mail, Phone, FileText, CheckCircle, XCircle, Clock3, Trash2, Eye } from 'lucide-react';
import { format } from 'date-fns';

interface Booking {
  id: string;
  client_name: string;
  client_email: string;
  client_phone: string | null;
  service_id: string | null;
  booking_date: string;
  start_time: string;
  end_time: string;
  status: string | null;
  notes: string | null;
  created_at: string;
}

interface Service {
  id: string;
  name: string;
}

const BookingsAdmin = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const { toast } = useToast();

  const fetchBookings = async () => {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('booking_date', { ascending: true })
      .order('start_time', { ascending: true });

    if (error) {
      toast({ title: 'Error loading bookings', description: error.message, variant: 'destructive' });
    } else {
      setBookings(data || []);
    }
    setIsLoading(false);
  };

  const fetchServices = async () => {
    const { data } = await supabase.from('services').select('id, name').eq('active', true);
    setServices(data || []);
  };

  useEffect(() => {
    fetchBookings();
    fetchServices();
  }, []);

  const getServiceName = (serviceId: string | null) => {
    if (!serviceId) return 'General Consultation';
    const service = services.find(s => s.id === serviceId);
    return service?.name || 'Unknown Service';
  };

  const updateBookingStatus = async (id: string, status: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status })
      .eq('id', id);

    if (error) {
      toast({ title: 'Error updating status', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Status updated', description: `Booking marked as ${status}` });
      fetchBookings();
      setIsDialogOpen(false);
    }
  };

  const deleteBooking = async (id: string) => {
    if (!confirm('Are you sure you want to delete this booking?')) return;

    const { error } = await supabase.from('bookings').delete().eq('id', id);

    if (error) {
      toast({ title: 'Error deleting booking', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Booking deleted' });
      fetchBookings();
      setIsDialogOpen(false);
    }
  };

  const getStatusBadge = (status: string | null) => {
    switch (status) {
      case 'confirmed':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30"><CheckCircle className="w-3 h-3 mr-1" />Confirmed</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30"><XCircle className="w-3 h-3 mr-1" />Cancelled</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      default:
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30"><Clock3 className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  const filteredBookings = filterStatus === 'all' 
    ? bookings 
    : bookings.filter(b => (b.status || 'pending') === filterStatus);

  const pendingCount = bookings.filter(b => !b.status || b.status === 'pending').length;
  const confirmedCount = bookings.filter(b => b.status === 'confirmed').length;
  const completedCount = bookings.filter(b => b.status === 'completed').length;

  return (
    <AdminLayout title="Bookings" description="Manage client appointments and scheduling">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="glass border-secondary/50">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Bookings</p>
              <p className="text-2xl font-bold">{bookings.length}</p>
            </div>
            <Calendar className="h-8 w-8 text-primary opacity-50" />
          </CardContent>
        </Card>
        <Card className="glass border-yellow-500/30">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-2xl font-bold text-yellow-400">{pendingCount}</p>
            </div>
            <Clock3 className="h-8 w-8 text-yellow-400 opacity-50" />
          </CardContent>
        </Card>
        <Card className="glass border-green-500/30">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Confirmed</p>
              <p className="text-2xl font-bold text-green-400">{confirmedCount}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-400 opacity-50" />
          </CardContent>
        </Card>
        <Card className="glass border-blue-500/30">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Completed</p>
              <p className="text-2xl font-bold text-blue-400">{completedCount}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-blue-400 opacity-50" />
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex justify-between items-center mb-4">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-48 bg-secondary/50 border-secondary">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Bookings</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bookings Table */}
      <Card className="glass border-secondary/50">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-12 text-center text-muted-foreground">Loading bookings...</div>
          ) : filteredBookings.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">No bookings found</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-secondary/50">
                  <TableHead>Client</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBookings.map((booking) => (
                  <TableRow key={booking.id} className="border-secondary/50">
                    <TableCell>
                      <div className="font-medium">{booking.client_name}</div>
                      <div className="text-sm text-muted-foreground">{booking.client_email}</div>
                    </TableCell>
                    <TableCell>{getServiceName(booking.service_id)}</TableCell>
                    <TableCell>
                      <div className="font-medium">{format(new Date(booking.booking_date), 'MMM d, yyyy')}</div>
                      <div className="text-sm text-muted-foreground">
                        {booking.start_time.slice(0, 5)} - {booking.end_time.slice(0, 5)}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(booking.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => { setSelectedBooking(booking); setIsDialogOpen(true); }}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteBooking(booking.id)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Booking Detail Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-background border-secondary max-w-lg">
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
          </DialogHeader>
          {selectedBooking && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <User className="h-4 w-4" /> Client Name
                  </div>
                  <p className="font-medium">{selectedBooking.client_name}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4" /> Email
                  </div>
                  <p className="font-medium">{selectedBooking.client_email}</p>
                </div>
                {selectedBooking.client_phone && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-4 w-4" /> Phone
                    </div>
                    <p className="font-medium">{selectedBooking.client_phone}</p>
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" /> Date
                  </div>
                  <p className="font-medium">{format(new Date(selectedBooking.booking_date), 'MMMM d, yyyy')}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" /> Time
                  </div>
                  <p className="font-medium">{selectedBooking.start_time.slice(0, 5)} - {selectedBooking.end_time.slice(0, 5)}</p>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-muted-foreground">Service</div>
                  <p className="font-medium">{getServiceName(selectedBooking.service_id)}</p>
                </div>
              </div>

              {selectedBooking.notes && (
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" /> Notes
                  </div>
                  <p className="bg-secondary/30 p-3 rounded-md text-sm">{selectedBooking.notes}</p>
                </div>
              )}

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Update Status</p>
                <div className="flex gap-2 flex-wrap">
                  <Button
                    size="sm"
                    variant={selectedBooking.status === 'confirmed' ? 'default' : 'outline'}
                    onClick={() => updateBookingStatus(selectedBooking.id, 'confirmed')}
                    className="border-green-500/30 hover:bg-green-500/20"
                  >
                    <CheckCircle className="h-4 w-4 mr-1" /> Confirm
                  </Button>
                  <Button
                    size="sm"
                    variant={selectedBooking.status === 'completed' ? 'default' : 'outline'}
                    onClick={() => updateBookingStatus(selectedBooking.id, 'completed')}
                    className="border-blue-500/30 hover:bg-blue-500/20"
                  >
                    <CheckCircle className="h-4 w-4 mr-1" /> Complete
                  </Button>
                  <Button
                    size="sm"
                    variant={selectedBooking.status === 'cancelled' ? 'default' : 'outline'}
                    onClick={() => updateBookingStatus(selectedBooking.id, 'cancelled')}
                    className="border-red-500/30 hover:bg-red-500/20"
                  >
                    <XCircle className="h-4 w-4 mr-1" /> Cancel
                  </Button>
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => window.location.href = `mailto:${selectedBooking.client_email}?subject=Regarding your booking on ${format(new Date(selectedBooking.booking_date), 'MMM d, yyyy')}`}
                >
                  <Mail className="h-4 w-4 mr-2" /> Email Client
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => deleteBooking(selectedBooking.id)}
                >
                  <Trash2 className="h-4 w-4 mr-2" /> Delete
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default BookingsAdmin;
