import { useState, useEffect } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Clock, DollarSign, GripVertical, Calendar } from 'lucide-react';

interface Service {
  id: string;
  name: string;
  description: string | null;
  duration: string | null;
  price_range: string | null;
  icon: string | null;
  features: string[] | null;
  active: boolean | null;
  display_order: number | null;
}

const ServicesAdmin = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    duration: '',
    price_range: '',
    icon: '',
    features: '',
    active: true,
    display_order: 0,
  });

  const fetchServices = async () => {
    const { data, error } = await supabase
      .from('services')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) {
      toast({ title: 'Error loading services', description: error.message, variant: 'destructive' });
    } else {
      setServices(data || []);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchServices();
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      duration: '',
      price_range: '',
      icon: '',
      features: '',
      active: true,
      display_order: services.length,
    });
    setEditingService(null);
  };

  const openEditDialog = (service: Service) => {
    setFormData({
      name: service.name,
      description: service.description || '',
      duration: service.duration || '',
      price_range: service.price_range || '',
      icon: service.icon || '',
      features: service.features?.join(', ') || '',
      active: service.active ?? true,
      display_order: service.display_order || 0,
    });
    setEditingService(service);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const serviceData = {
      name: formData.name,
      description: formData.description || null,
      duration: formData.duration || null,
      price_range: formData.price_range || null,
      icon: formData.icon || null,
      features: formData.features ? formData.features.split(',').map(f => f.trim()).filter(Boolean) : null,
      active: formData.active,
      display_order: formData.display_order,
    };

    if (editingService) {
      const { error } = await supabase
        .from('services')
        .update(serviceData)
        .eq('id', editingService.id);

      if (error) {
        toast({ title: 'Error updating service', description: error.message, variant: 'destructive' });
        return;
      }
      toast({ title: 'Service updated successfully' });
    } else {
      const { error } = await supabase.from('services').insert(serviceData);

      if (error) {
        toast({ title: 'Error creating service', description: error.message, variant: 'destructive' });
        return;
      }
      toast({ title: 'Service created successfully' });
    }

    setIsDialogOpen(false);
    resetForm();
    fetchServices();
  };

  const deleteService = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service?')) return;

    const { error } = await supabase.from('services').delete().eq('id', id);

    if (error) {
      toast({ title: 'Error deleting service', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Service deleted' });
      fetchServices();
    }
  };

  return (
    <AdminLayout title="Services" description="Manage your service offerings for booking">
      <div className="flex justify-between items-center mb-6">
        <p className="text-muted-foreground">
          {services.filter(s => s.active).length} active services
        </p>
        <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" /> Add Service
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-background border-secondary max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingService ? 'Edit Service' : 'Add New Service'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Service Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Strategy Consultation"
                  required
                  className="bg-secondary/50 border-secondary"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe what this service includes..."
                  className="bg-secondary/50 border-secondary"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration</Label>
                  <Input
                    id="duration"
                    value={formData.duration}
                    onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                    placeholder="e.g., 1 hour"
                    className="bg-secondary/50 border-secondary"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price_range">Price Range</Label>
                  <Input
                    id="price_range"
                    value={formData.price_range}
                    onChange={(e) => setFormData({ ...formData, price_range: e.target.value })}
                    placeholder="e.g., $150-$300"
                    className="bg-secondary/50 border-secondary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="icon">Icon Name (Lucide)</Label>
                <Input
                  id="icon"
                  value={formData.icon}
                  onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                  placeholder="e.g., Briefcase, Code, Palette"
                  className="bg-secondary/50 border-secondary"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="features">Features (comma-separated)</Label>
                <Textarea
                  id="features"
                  value={formData.features}
                  onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                  placeholder="e.g., 1-on-1 session, Action plan, Follow-up email"
                  className="bg-secondary/50 border-secondary"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                  />
                  <Label htmlFor="active">Active (visible to clients)</Label>
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
                  {editingService ? 'Update Service' : 'Create Service'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="glass border-secondary/50">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-12 text-center text-muted-foreground">Loading services...</div>
          ) : services.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              No services yet. Add your first service to enable booking.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-secondary/50">
                  <TableHead>Service</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {services.map((service) => (
                  <TableRow key={service.id} className="border-secondary/50">
                    <TableCell>
                      <div className="font-medium">{service.name}</div>
                      {service.description && (
                        <div className="text-sm text-muted-foreground line-clamp-1">{service.description}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      {service.duration && (
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {service.duration}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      {service.price_range && (
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <DollarSign className="h-3 w-3" />
                          {service.price_range}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${service.active ? 'bg-green-500/20 text-green-400' : 'bg-secondary text-muted-foreground'}`}>
                        {service.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(service)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteService(service.id)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </AdminLayout>
  );
};

export default ServicesAdmin;
