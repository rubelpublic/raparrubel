import { useState, useEffect } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2, Mail, Lock, User, Key, Bot, Eye, EyeOff, CheckCircle, AlertCircle, Zap, Sparkles, Brain, Cloud, Cpu, Globe, Radio, ChevronDown, ChevronUp, Settings2 } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UniversalApiConfig from '@/components/admin/UniversalApiConfig';

// AI Provider configurations
const AI_PROVIDERS = [
  {
    id: 'gemini',
    name: 'Google Gemini',
    icon: Sparkles,
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    description: 'Google AI with Gemini 2.0 Flash',
    keyPrefix: 'AIza',
    keyPlaceholder: 'AIza...',
    keyHint: 'Get your API key from Google AI Studio',
    testUrl: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
  },
  {
    id: 'openai',
    name: 'OpenAI',
    icon: Brain,
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/30',
    description: 'GPT-4o Mini & GPT-4',
    keyPrefix: 'sk-',
    keyPlaceholder: 'sk-...',
    keyHint: 'Get your API key from OpenAI Platform',
    testUrl: 'https://api.openai.com/v1/chat/completions',
  },
  {
    id: 'anthropic',
    name: 'Anthropic Claude',
    icon: Cloud,
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/30',
    description: 'Claude 3 Haiku, Sonnet & Opus',
    keyPrefix: 'sk-ant-',
    keyPlaceholder: 'sk-ant-...',
    keyHint: 'Get your API key from Anthropic Console',
    testUrl: 'https://api.anthropic.com/v1/messages',
  },
  {
    id: 'mistral',
    name: 'Mistral AI',
    icon: Cpu,
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/30',
    description: 'Mistral Small, Medium & Large',
    keyPrefix: '',
    keyPlaceholder: 'Enter Mistral API key...',
    keyHint: 'Get your API key from Mistral AI Console',
    testUrl: 'https://api.mistral.ai/v1/chat/completions',
  },
  {
    id: 'cohere',
    name: 'Cohere',
    icon: Globe,
    color: 'text-teal-500',
    bgColor: 'bg-teal-500/10',
    borderColor: 'border-teal-500/30',
    description: 'Command-R & Command-R+',
    keyPrefix: '',
    keyPlaceholder: 'Enter Cohere API key...',
    keyHint: 'Get your API key from Cohere Dashboard',
    testUrl: 'https://api.cohere.ai/v1/chat',
  },
  {
    id: 'groq',
    name: 'Groq',
    icon: Zap,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500/10',
    borderColor: 'border-yellow-500/30',
    description: 'Ultra-fast LLaMA inference',
    keyPrefix: 'gsk_',
    keyPlaceholder: 'gsk_...',
    keyHint: 'Get your API key from Groq Console',
    testUrl: 'https://api.groq.com/openai/v1/chat/completions',
  },
  {
    id: 'together',
    name: 'Together AI',
    icon: Radio,
    color: 'text-pink-500',
    bgColor: 'bg-pink-500/10',
    borderColor: 'border-pink-500/30',
    description: 'Open-source models at scale',
    keyPrefix: '',
    keyPlaceholder: 'Enter Together AI API key...',
    keyHint: 'Get your API key from Together AI',
    testUrl: 'https://api.together.xyz/v1/chat/completions',
  },
  {
    id: 'perplexity',
    name: 'Perplexity',
    icon: Globe,
    color: 'text-indigo-500',
    bgColor: 'bg-indigo-500/10',
    borderColor: 'border-indigo-500/30',
    description: 'AI-powered search & answers',
    keyPrefix: 'pplx-',
    keyPlaceholder: 'pplx-...',
    keyHint: 'Get your API key from Perplexity Labs',
    testUrl: 'https://api.perplexity.ai/chat/completions',
  },
] as const;

type ProviderId = typeof AI_PROVIDERS[number]['id'];

interface ProviderState {
  apiKey: string;
  isExpanded: boolean;
  isTesting: boolean;
  testResult: { success: boolean; message: string } | null;
}

const SettingsAdmin = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Email update state
  const [newEmail, setNewEmail] = useState('');
  const [isUpdatingEmail, setIsUpdatingEmail] = useState(false);
  
  // Password update state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  // API Settings state
  const [chatbotEnabled, setChatbotEnabled] = useState(true);
  const [isLoadingApi, setIsLoadingApi] = useState(true);
  const [isSavingApi, setIsSavingApi] = useState(false);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<ProviderId | null>(null);
  const [savedApiKey, setSavedApiKey] = useState('');
  const [showApiKeys, setShowApiKeys] = useState<Record<string, boolean>>({});
  
  // Provider states
  const [providerStates, setProviderStates] = useState<Record<ProviderId, ProviderState>>(
    AI_PROVIDERS.reduce((acc, provider) => ({
      ...acc,
      [provider.id]: {
        apiKey: '',
        isExpanded: false,
        isTesting: false,
        testResult: null,
      }
    }), {} as Record<ProviderId, ProviderState>)
  );

  // Load API settings on mount
  useEffect(() => {
    const loadApiSettings = async () => {
      try {
        const { data: apiKeyData } = await supabase
          .from('site_settings')
          .select('value')
          .eq('key', 'custom_api_key')
          .maybeSingle();
        
        const { data: chatbotData } = await supabase
          .from('site_settings')
          .select('value')
          .eq('key', 'chatbot_enabled')
          .maybeSingle();

        const { data: providerData } = await supabase
          .from('site_settings')
          .select('value')
          .eq('key', 'selected_ai_provider')
          .maybeSingle();

        if (apiKeyData?.value) {
          const keyValue = typeof apiKeyData.value === 'string' 
            ? apiKeyData.value 
            : JSON.stringify(apiKeyData.value).replace(/^"|"$/g, '');
          setSavedApiKey(keyValue);
          
          // Detect which provider this key belongs to
          const detectedProvider = detectProviderFromKey(keyValue);
          if (detectedProvider) {
            setProviderStates(prev => ({
              ...prev,
              [detectedProvider]: {
                ...prev[detectedProvider],
                apiKey: keyValue,
                isExpanded: true,
              }
            }));
          }
        }
        
        if (chatbotData?.value !== null && chatbotData?.value !== undefined) {
          setChatbotEnabled(Boolean(chatbotData.value));
        }

        if (providerData?.value && typeof providerData.value === 'string') {
          setSelectedProvider(providerData.value as ProviderId);
        }
      } catch (error) {
        console.log('No existing API settings found', error);
      } finally {
        setIsLoadingApi(false);
      }
    };

    loadApiSettings();
  }, []);

  const detectProviderFromKey = (key: string): ProviderId | null => {
    if (key.startsWith('AIza')) return 'gemini';
    if (key.startsWith('sk-ant-')) return 'anthropic';
    if (key.startsWith('gsk_')) return 'groq';
    if (key.startsWith('pplx-')) return 'perplexity';
    if (key.startsWith('sk-')) return 'openai';
    return null;
  };

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newEmail) {
      toast({
        title: "Error",
        description: "Please enter a new email address",
        variant: "destructive",
      });
      return;
    }

    setIsUpdatingEmail(true);
    
    try {
      const { error } = await supabase.auth.updateUser({ email: newEmail });
      
      if (error) throw error;
      
      toast({
        title: "Email Update Initiated",
        description: "Please check both your old and new email addresses to confirm the change.",
      });
      setNewEmail('');
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update email",
        variant: "destructive",
      });
    } finally {
      setIsUpdatingEmail(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newPassword || !confirmPassword) {
      toast({
        title: "Error",
        description: "Please fill in all password fields",
        variant: "destructive",
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match",
        variant: "destructive",
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "Error",
        description: "Password must be at least 6 characters",
        variant: "destructive",
      });
      return;
    }

    setIsUpdatingPassword(true);
    
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      
      if (error) throw error;
      
      toast({
        title: "Password Updated",
        description: "Your password has been changed successfully.",
      });
      setNewPassword('');
      setConfirmPassword('');
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update password",
        variant: "destructive",
      });
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  const handleTestApiKey = async (providerId: ProviderId) => {
    const provider = AI_PROVIDERS.find(p => p.id === providerId);
    const state = providerStates[providerId];
    
    if (!provider || !state.apiKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter an API key to test",
        variant: "destructive",
      });
      return;
    }

    setProviderStates(prev => ({
      ...prev,
      [providerId]: { ...prev[providerId], isTesting: true, testResult: null }
    }));

    try {
      let testUrl = '';
      let testBody = {};
      let testHeaders: Record<string, string> = { 'Content-Type': 'application/json' };

      switch (providerId) {
        case 'gemini':
          testUrl = `${provider.testUrl}?key=${state.apiKey}`;
          testBody = {
            contents: [{ parts: [{ text: 'Say "API key is valid" in exactly those words.' }] }],
            generationConfig: { maxOutputTokens: 20 }
          };
          break;
        case 'openai':
          testUrl = provider.testUrl;
          testHeaders['Authorization'] = `Bearer ${state.apiKey}`;
          testBody = {
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: 'Say "API key is valid" in exactly those words.' }],
            max_tokens: 20
          };
          break;
        case 'anthropic':
          testUrl = provider.testUrl;
          testHeaders['x-api-key'] = state.apiKey;
          testHeaders['anthropic-version'] = '2023-06-01';
          testHeaders['anthropic-dangerous-direct-browser-access'] = 'true';
          testBody = {
            model: 'claude-3-haiku-20240307',
            max_tokens: 20,
            messages: [{ role: 'user', content: 'Say "API key is valid" in exactly those words.' }]
          };
          break;
        case 'mistral':
          testUrl = provider.testUrl;
          testHeaders['Authorization'] = `Bearer ${state.apiKey}`;
          testBody = {
            model: 'mistral-small-latest',
            messages: [{ role: 'user', content: 'Say "API key is valid" in exactly those words.' }],
            max_tokens: 20
          };
          break;
        case 'cohere':
          testUrl = provider.testUrl;
          testHeaders['Authorization'] = `Bearer ${state.apiKey}`;
          testBody = {
            model: 'command-r',
            message: 'Say "API key is valid" in exactly those words.',
          };
          break;
        case 'groq':
          testUrl = provider.testUrl;
          testHeaders['Authorization'] = `Bearer ${state.apiKey}`;
          testBody = {
            model: 'llama-3.1-8b-instant',
            messages: [{ role: 'user', content: 'Say "API key is valid" in exactly those words.' }],
            max_tokens: 20
          };
          break;
        case 'together':
          testUrl = provider.testUrl;
          testHeaders['Authorization'] = `Bearer ${state.apiKey}`;
          testBody = {
            model: 'meta-llama/Llama-3-8b-chat-hf',
            messages: [{ role: 'user', content: 'Say "API key is valid" in exactly those words.' }],
            max_tokens: 20
          };
          break;
        case 'perplexity':
          testUrl = provider.testUrl;
          testHeaders['Authorization'] = `Bearer ${state.apiKey}`;
          testBody = {
            model: 'llama-3.1-sonar-small-128k-online',
            messages: [{ role: 'user', content: 'Say "API key is valid" in exactly those words.' }],
            max_tokens: 20
          };
          break;
      }

      const response = await fetch(testUrl, {
        method: 'POST',
        headers: testHeaders,
        body: JSON.stringify(testBody)
      });

      if (response.ok) {
        setProviderStates(prev => ({
          ...prev,
          [providerId]: {
            ...prev[providerId],
            testResult: {
              success: true,
              message: `✅ ${provider.name} API key is valid and working!`
            }
          }
        }));
        toast({
          title: "API Key Valid",
          description: `Your ${provider.name} API key is working correctly.`,
        });
      } else {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.error?.message || errorData.message || `HTTP ${response.status}`;
        setProviderStates(prev => ({
          ...prev,
          [providerId]: {
            ...prev[providerId],
            testResult: {
              success: false,
              message: `❌ API key validation failed: ${errorMessage}`
            }
          }
        }));
        toast({
          title: "API Key Invalid",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      setProviderStates(prev => ({
        ...prev,
        [providerId]: {
          ...prev[providerId],
          testResult: {
            success: false,
            message: `❌ Connection error: ${error.message}`
          }
        }
      }));
      toast({
        title: "Test Failed",
        description: error.message || "Failed to test API key",
        variant: "destructive",
      });
    } finally {
      setProviderStates(prev => ({
        ...prev,
        [providerId]: { ...prev[providerId], isTesting: false }
      }));
    }
  };

  const handleSaveProvider = async (providerId: ProviderId) => {
    const state = providerStates[providerId];
    const provider = AI_PROVIDERS.find(p => p.id === providerId);
    
    if (!state.apiKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter an API key",
        variant: "destructive",
      });
      return;
    }

    if (!state.testResult?.success) {
      toast({
        title: "Please Test API Key First",
        description: "Click 'Test' to verify the API key works before saving.",
        variant: "destructive",
      });
      return;
    }

    setIsSavingApi(true);
    setShowSaveSuccess(false);
    
    try {
      // Save the API key
      const { error: apiError } = await supabase
        .from('site_settings')
        .upsert(
          { 
            key: 'custom_api_key', 
            value: state.apiKey,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'key' }
        );
      
      if (apiError) throw apiError;

      // Save the selected provider
      const { error: providerError } = await supabase
        .from('site_settings')
        .upsert(
          { 
            key: 'selected_ai_provider', 
            value: providerId,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'key' }
        );
      
      if (providerError) throw providerError;

      // Save chatbot enabled state
      const { error: chatbotError } = await supabase
        .from('site_settings')
        .upsert(
          { 
            key: 'chatbot_enabled', 
            value: chatbotEnabled,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'key' }
        );
      
      if (chatbotError) throw chatbotError;
      
      setSavedApiKey(state.apiKey);
      setSelectedProvider(providerId);
      setShowSaveSuccess(true);
      
      setTimeout(() => setShowSaveSuccess(false), 5000);
      
      toast({
        title: "API Settings Saved",
        description: `${provider?.name} is now your active AI provider.`,
      });
    } catch (error: any) {
      console.error('Save error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save API settings",
        variant: "destructive",
      });
    } finally {
      setIsSavingApi(false);
    }
  };

  const toggleProviderExpanded = (providerId: ProviderId) => {
    setProviderStates(prev => ({
      ...prev,
      [providerId]: {
        ...prev[providerId],
        isExpanded: !prev[providerId].isExpanded
      }
    }));
  };

  const updateProviderApiKey = (providerId: ProviderId, value: string) => {
    setProviderStates(prev => ({
      ...prev,
      [providerId]: {
        ...prev[providerId],
        apiKey: value,
        testResult: null
      }
    }));
  };

  return (
    <AdminLayout title="Settings" description="Manage your account, API keys, and portfolio settings">
      <Tabs defaultValue="ai-providers" className="w-full max-w-5xl">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="ai-providers" className="text-xs sm:text-sm">
            <Bot className="h-4 w-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">AI Providers</span>
            <span className="sm:hidden">AI</span>
          </TabsTrigger>
          <TabsTrigger value="universal-api" className="text-xs sm:text-sm">
            <Settings2 className="h-4 w-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Universal APIs</span>
            <span className="sm:hidden">APIs</span>
          </TabsTrigger>
          <TabsTrigger value="account" className="text-xs sm:text-sm">
            <User className="h-4 w-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Account</span>
            <span className="sm:hidden">Account</span>
          </TabsTrigger>
        </TabsList>

        {/* AI Providers Tab */}
        <TabsContent value="ai-providers" className="space-y-4 sm:space-y-6">
          {/* AI Chatbot Configuration */}
          <Card className="glass border-secondary/50">
            <CardHeader className="pb-3 sm:pb-6">
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <Bot className="h-5 w-5 text-primary flex-shrink-0" />
              <span className="truncate">AI Chatbot Configuration</span>
            </CardTitle>
            <CardDescription className="text-sm">Configure your AI provider for the portfolio chatbot</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 sm:space-y-6">
            {isLoadingApi ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading settings...
              </div>
            ) : (
              <>
                {/* Enable/Disable Toggle */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 sm:p-4 rounded-lg bg-secondary/30 border border-border">
                  <div className="space-y-0.5">
                    <Label className="text-sm sm:text-base">Enable Chatbot</Label>
                    <p className="text-xs sm:text-sm text-muted-foreground">Show AI assistant on your portfolio</p>
                  </div>
                  <Switch
                    checked={chatbotEnabled}
                    onCheckedChange={setChatbotEnabled}
                  />
                </div>

                {/* Currently Active Provider */}
                {selectedProvider && savedApiKey && (
                  <div className="p-3 sm:p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                    <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                      <CheckCircle className="h-4 w-4 flex-shrink-0" />
                      <span className="font-medium">Active: {AI_PROVIDERS.find(p => p.id === selectedProvider)?.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 break-all">
                      Key: {savedApiKey.substring(0, 8)}...{savedApiKey.substring(savedApiKey.length - 4)}
                    </p>
                  </div>
                )}

                {showSaveSuccess && (
                  <div className="p-3 sm:p-4 rounded-lg bg-primary/10 border border-primary/20 animate-pulse">
                    <div className="flex items-center gap-2 text-sm text-primary">
                      <CheckCircle className="h-4 w-4 flex-shrink-0" />
                      <span className="font-medium">Settings saved successfully!</span>
                    </div>
                  </div>
                )}

                {/* Provider Cards */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Choose AI Provider</Label>
                  <div className="grid gap-3">
                    {AI_PROVIDERS.map((provider) => {
                      const state = providerStates[provider.id];
                      const Icon = provider.icon;
                      const isActive = selectedProvider === provider.id && savedApiKey;
                      
                      return (
                        <Collapsible 
                          key={provider.id} 
                          open={state.isExpanded}
                          onOpenChange={() => toggleProviderExpanded(provider.id)}
                        >
                          <Card className={`transition-all duration-200 ${
                            isActive 
                              ? `${provider.borderColor} ${provider.bgColor}` 
                              : 'border-border hover:border-primary/30'
                          }`}>
                            <CollapsibleTrigger className="w-full">
                              <CardHeader className="p-3 sm:p-4 cursor-pointer">
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                                    <div className={`p-1.5 sm:p-2 rounded-lg ${provider.bgColor} flex-shrink-0`}>
                                      <Icon className={`h-4 w-4 sm:h-5 sm:w-5 ${provider.color}`} />
                                    </div>
                                    <div className="text-left min-w-0 flex-1">
                                      <div className="flex items-center gap-2 flex-wrap">
                                        <h4 className="font-semibold text-sm sm:text-base truncate">{provider.name}</h4>
                                        {isActive && (
                                          <span className="text-xs px-1.5 py-0.5 rounded bg-green-500/20 text-green-600 dark:text-green-400 flex-shrink-0">
                                            Active
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-xs text-muted-foreground truncate hidden sm:block">{provider.description}</p>
                                    </div>
                                  </div>
                                  <div className="flex-shrink-0">
                                    {state.isExpanded ? (
                                      <ChevronUp className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                                    ) : (
                                      <ChevronDown className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                                    )}
                                  </div>
                                </div>
                              </CardHeader>
                            </CollapsibleTrigger>
                            
                            <CollapsibleContent>
                              <CardContent className="pt-0 px-3 pb-3 sm:px-4 sm:pb-4 space-y-3 sm:space-y-4">
                                <div className="space-y-2">
                                  <Label htmlFor={`${provider.id}-key`} className="flex items-center gap-2 text-sm">
                                    <Key className="h-3 w-3 sm:h-4 sm:w-4" />
                                    API Key
                                  </Label>
                                  <p className="text-xs text-muted-foreground">{provider.keyHint}</p>
                                  <div className="relative">
                                    <Input
                                      id={`${provider.id}-key`}
                                      type={showApiKeys[provider.id] ? "text" : "password"}
                                      placeholder={provider.keyPlaceholder}
                                      value={state.apiKey}
                                      onChange={(e) => updateProviderApiKey(provider.id, e.target.value)}
                                      className="bg-background/50 pr-10 text-sm"
                                    />
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                                      onClick={() => setShowApiKeys(prev => ({ ...prev, [provider.id]: !prev[provider.id] }))}
                                    >
                                      {showApiKeys[provider.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                    </Button>
                                  </div>
                                </div>

                                {state.testResult && (
                                  <div className={`p-2 sm:p-3 rounded-lg border ${
                                    state.testResult.success 
                                      ? 'bg-green-500/10 border-green-500/20' 
                                      : 'bg-destructive/10 border-destructive/20'
                                  }`}>
                                    <div className={`flex items-center gap-2 text-xs sm:text-sm ${
                                      state.testResult.success ? 'text-green-600 dark:text-green-400' : 'text-destructive'
                                    }`}>
                                      {state.testResult.success ? <CheckCircle className="h-4 w-4 flex-shrink-0" /> : <AlertCircle className="h-4 w-4 flex-shrink-0" />}
                                      <span className="font-medium break-all">{state.testResult.message}</span>
                                    </div>
                                  </div>
                                )}

                                <div className="flex flex-col sm:flex-row gap-2">
                                  <Button 
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleTestApiKey(provider.id)} 
                                    disabled={state.isTesting || !state.apiKey.trim()}
                                    className="flex-1 text-sm"
                                  >
                                    {state.isTesting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
                                    Test API Key
                                  </Button>
                                  <Button 
                                    size="sm"
                                    onClick={() => handleSaveProvider(provider.id)} 
                                    disabled={isSavingApi || !state.testResult?.success}
                                    className="flex-1 text-sm"
                                  >
                                    {isSavingApi && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    {isActive ? 'Update' : 'Activate'}
                                  </Button>
                                </div>
                              </CardContent>
                            </CollapsibleContent>
                          </Card>
                        </Collapsible>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      {/* Universal APIs Tab */}
      <TabsContent value="universal-api">
        <UniversalApiConfig />
      </TabsContent>

      {/* Account Tab */}
      <TabsContent value="account" className="space-y-4 sm:space-y-6">
        {/* Current Account Info */}
        <Card className="glass border-secondary/50">
          <CardHeader className="pb-3 sm:pb-6">
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <User className="h-5 w-5 flex-shrink-0" />
              Account Information
            </CardTitle>
            <CardDescription className="text-sm">Your current account details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="font-medium text-sm sm:text-base break-all">{user?.email}</p>
            </div>
          </CardContent>
        </Card>

        {/* Update Email */}
        <Card className="glass border-secondary/50">
          <CardHeader className="pb-3 sm:pb-6">
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <Mail className="h-5 w-5 flex-shrink-0" />
              Update Email
            </CardTitle>
            <CardDescription className="text-sm">Change your account email address</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateEmail} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="newEmail" className="text-sm">New Email Address</Label>
                <Input
                  id="newEmail"
                  type="email"
                  placeholder="Enter new email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="bg-background/50 text-sm"
                />
              </div>
              <Button type="submit" disabled={isUpdatingEmail} className="w-full sm:w-auto">
                {isUpdatingEmail && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update Email
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Update Password */}
        <Card className="glass border-secondary/50">
          <CardHeader className="pb-3 sm:pb-6">
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <Lock className="h-5 w-5 flex-shrink-0" />
              Update Password
            </CardTitle>
            <CardDescription className="text-sm">Change your account password</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="newPassword" className="text-sm">New Password</Label>
                <Input
                  id="newPassword"
                  type="password"
                  placeholder="Enter new password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="bg-background/50 text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-sm">Confirm New Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="bg-background/50 text-sm"
                />
              </div>
              <Button type="submit" disabled={isUpdatingPassword} className="w-full sm:w-auto">
                {isUpdatingPassword && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update Password
              </Button>
            </form>
          </CardContent>
        </Card>
      </TabsContent>
      </Tabs>
    </AdminLayout>
  );
};

export default SettingsAdmin;
