import { useEffect, useState } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Eye, Users, TrendingUp } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const AnalyticsAdmin = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [pageViews, setPageViews] = useState<any[]>([]);
  const [totalViews, setTotalViews] = useState(0);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const { data, error, count } = await supabase
          .from('page_views')
          .select('*', { count: 'exact' })
          .gte('created_at', subDays(new Date(), 30).toISOString())
          .order('created_at', { ascending: true });

        if (error) throw error;
        
        // Group by day
        const grouped = (data || []).reduce((acc: any, view: any) => {
          const day = format(new Date(view.created_at), 'MMM d');
          acc[day] = (acc[day] || 0) + 1;
          return acc;
        }, {});

        const chartData = Object.entries(grouped).map(([date, views]) => ({
          date,
          views,
        }));

        setPageViews(chartData);
        setTotalViews(count || 0);
      } catch (error) {
        console.error('Error fetching analytics:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (isLoading) {
    return (
      <AdminLayout title="Analytics" description="Track your portfolio performance">
        <div className="flex items-center justify-center h-48">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Analytics" description="Track your portfolio performance">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="glass border-secondary/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Page Views</CardTitle>
            <Eye className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalViews.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="glass border-secondary/50">
        <CardHeader>
          <CardTitle>Page Views (Last 30 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          {pageViews.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <TrendingUp className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No page view data yet. Analytics will appear as visitors view your portfolio.</p>
            </div>
          ) : (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={pageViews}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--secondary))" />
                  <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      background: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="views" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>
    </AdminLayout>
  );
};

export default AnalyticsAdmin;
