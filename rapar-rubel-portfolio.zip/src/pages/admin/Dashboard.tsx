import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AdminLayout from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import {
  FolderKanban,
  FileText,
  MessageSquareQuote,
  Mail,
  Users,
  Calendar,
  Eye,
  TrendingUp,
  Clock,
  ArrowRight,
  Settings,
  Bot,
  Star,
  Plus,
  RefreshCw,
} from 'lucide-react';
import { format } from 'date-fns';

interface Stats {
  projects: number;
  blogPosts: number;
  testimonials: number;
  contacts: number;
  subscribers: number;
  bookings: number;
  pageViews: number;
  pendingBookings: number;
}

interface RecentItem {
  id: string;
  type: 'contact' | 'booking' | 'testimonial' | 'subscriber';
  title: string;
  subtitle: string;
  created_at: string;
  status?: string;
}

const Dashboard = () => {
  const [stats, setStats] = useState<Stats>({
    projects: 0,
    blogPosts: 0,
    testimonials: 0,
    contacts: 0,
    subscribers: 0,
    bookings: 0,
    pageViews: 0,
    pendingBookings: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [recentItems, setRecentItems] = useState<RecentItem[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      // Batch all count queries in parallel
      const [
        projectsRes,
        blogRes,
        testimonialsRes,
        contactsRes,
        subscribersRes,
        bookingsRes,
        pageViewsRes,
        pendingBookingsRes,
      ] = await Promise.all([
        supabase.from('projects').select('id', { count: 'exact', head: true }),
        supabase.from('blog_posts').select('id', { count: 'exact', head: true }),
        supabase.from('testimonials').select('id', { count: 'exact', head: true }),
        supabase.from('contacts').select('id', { count: 'exact', head: true }),
        supabase.from('newsletter_subscribers').select('id', { count: 'exact', head: true }),
        supabase.from('bookings').select('id', { count: 'exact', head: true }),
        supabase.from('page_views').select('id', { count: 'exact', head: true }),
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
      ]);

      setStats({
        projects: projectsRes.count || 0,
        blogPosts: blogRes.count || 0,
        testimonials: testimonialsRes.count || 0,
        contacts: contactsRes.count || 0,
        subscribers: subscribersRes.count || 0,
        bookings: bookingsRes.count || 0,
        pageViews: pageViewsRes.count || 0,
        pendingBookings: pendingBookingsRes.count || 0,
      });

      // Set loading to false after stats are ready (faster perceived load)
      setIsLoading(false);

      // Fetch recent items in background after stats
      const [
        recentContactsRes,
        recentBookingsRes,
        recentTestimonialsRes,
        recentSubscribersRes,
      ] = await Promise.all([
        supabase.from('contacts').select('id, name, subject, message, created_at').order('created_at', { ascending: false }).limit(3),
        supabase.from('bookings').select('id, client_name, booking_date, start_time, created_at, status').order('created_at', { ascending: false }).limit(3),
        supabase.from('testimonials').select('id, client_name, content, created_at').order('created_at', { ascending: false }).limit(2),
        supabase.from('newsletter_subscribers').select('id, email, subscribed_at').order('subscribed_at', { ascending: false }).limit(2),
      ]);

      // Combine recent items
      const items: RecentItem[] = [];
      
      recentContactsRes.data?.forEach(c => items.push({
        id: c.id,
        type: 'contact',
        title: c.name,
        subtitle: c.subject || (c.message?.substring(0, 50) + '...'),
        created_at: c.created_at,
      }));

      recentBookingsRes.data?.forEach(b => items.push({
        id: b.id,
        type: 'booking',
        title: b.client_name,
        subtitle: `${format(new Date(b.booking_date), 'MMM d')} at ${b.start_time}`,
        created_at: b.created_at,
        status: b.status || undefined,
      }));

      recentTestimonialsRes.data?.forEach(t => items.push({
        id: t.id,
        type: 'testimonial',
        title: t.client_name,
        subtitle: (t.content?.substring(0, 50) + '...'),
        created_at: t.created_at,
      }));

      recentSubscribersRes.data?.forEach(s => items.push({
        id: s.id,
        type: 'subscriber',
        title: s.email,
        subtitle: 'Newsletter subscription',
        created_at: s.subscribed_at,
      }));

      // Sort by date and take top 8
      items.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      setRecentItems(items.slice(0, 8));
    } catch (error) {
      console.error('Error fetching stats:', error);
      setIsLoading(false);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRefresh = () => {
    setIsRefreshing(true);
    fetchData();
  };

  const statCards = [
    { label: 'Projects', value: stats.projects, icon: FolderKanban, color: 'text-primary', path: '/admin/projects' },
    { label: 'Blog Posts', value: stats.blogPosts, icon: FileText, color: 'text-accent', path: '/admin/blog' },
    { label: 'Testimonials', value: stats.testimonials, icon: MessageSquareQuote, color: 'text-yellow-500', path: '/admin/testimonials' },
    { label: 'Contacts', value: stats.contacts, icon: Mail, color: 'text-green-500', path: '/admin/contacts' },
    { label: 'Subscribers', value: stats.subscribers, icon: Users, color: 'text-blue-500', path: '/admin/subscribers' },
    { label: 'Total Bookings', value: stats.bookings, icon: Calendar, color: 'text-purple-500', path: '/admin/bookings' },
    { label: 'Page Views', value: stats.pageViews, icon: Eye, color: 'text-orange-500', path: '/admin/analytics' },
    { label: 'Pending Bookings', value: stats.pendingBookings, icon: TrendingUp, color: 'text-red-500', path: '/admin/bookings' },
  ];

  const getItemIcon = (type: RecentItem['type']) => {
    switch (type) {
      case 'contact': return <Mail className="h-4 w-4 text-green-500" />;
      case 'booking': return <Calendar className="h-4 w-4 text-purple-500" />;
      case 'testimonial': return <Star className="h-4 w-4 text-yellow-500" />;
      case 'subscriber': return <Users className="h-4 w-4 text-blue-500" />;
    }
  };

  const getItemPath = (item: RecentItem) => {
    switch (item.type) {
      case 'contact': return '/admin/contacts';
      case 'booking': return '/admin/bookings';
      case 'testimonial': return '/admin/testimonials';
      case 'subscriber': return '/admin/subscribers';
    }
  };

  return (
    <AdminLayout
      title="Dashboard"
      description="Overview of your portfolio performance"
    >
      {/* Refresh Button */}
      <div className="flex justify-end mb-4">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          disabled={isRefreshing}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? (
          // Skeleton loading for stats
          Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="glass border-secondary/50">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4 rounded" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))
        ) : (
          statCards.map((stat) => (
            <Link key={stat.label} to={stat.path}>
              <Card className="glass border-secondary/50 hover:border-primary/50 transition-all cursor-pointer group">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.label}
                  </CardTitle>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold flex items-center justify-between">
                    {stat.value.toLocaleString()}
                    <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>

      {/* Main Content Grid */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <Card className="glass border-secondary/50 lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Activity
              </CardTitle>
              <CardDescription>Latest updates across your portfolio</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="h-12 bg-secondary/50 rounded animate-pulse" />
                ))}
              </div>
            ) : recentItems.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No recent activity</p>
            ) : (
              <div className="space-y-3">
                {recentItems.map((item) => (
                  <Link 
                    key={`${item.type}-${item.id}`} 
                    to={getItemPath(item)}
                    className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors group"
                  >
                    <div className="h-9 w-9 rounded-full bg-background flex items-center justify-center">
                      {getItemIcon(item.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{item.title}</p>
                      <p className="text-sm text-muted-foreground truncate">{item.subtitle}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {item.status && (
                        <Badge variant={item.status === 'pending' ? 'secondary' : 'outline'} className="text-xs">
                          {item.status}
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {format(new Date(item.created_at), 'MMM d')}
                      </span>
                      <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="space-y-6">
          <Card className="glass border-secondary/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3">
              <Link
                to="/admin/projects"
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <FolderKanban className="h-5 w-5 text-primary" />
                <span>Add Project</span>
              </Link>
              <Link
                to="/admin/blog"
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <FileText className="h-5 w-5 text-accent" />
                <span>Write Blog Post</span>
              </Link>
              <Link
                to="/admin/bookings"
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <Calendar className="h-5 w-5 text-purple-500" />
                <span>Manage Bookings</span>
              </Link>
              <Link
                to="/admin/settings"
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <Bot className="h-5 w-5 text-green-500" />
                <span>Configure Chatbot API</span>
              </Link>
            </CardContent>
          </Card>

          <Card className="glass border-secondary/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="h-5 w-5" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Chatbot</span>
                <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                  Active
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Booking System</span>
                <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                  Active
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Newsletter</span>
                <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                  Active
                </Badge>
              </div>
              <Link 
                to="/admin/settings" 
                className="block mt-4 text-sm text-primary hover:underline"
              >
                Configure Settings →
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Dashboard;
