import { useState, useEffect } from "react";
// Preloader removed - site loads instantly
import Navbar from "@/components/portfolio/Navbar";
import HeroSection from "@/components/portfolio/HeroSection";
import ExpertiseSection from "@/components/portfolio/ExpertiseSection";
import SkillsSection from "@/components/portfolio/SkillsSection";
import VenturesSection from "@/components/portfolio/VenturesSection";
import ProjectsSection from "@/components/portfolio/ProjectsSection";
import TestimonialsSection from "@/components/portfolio/TestimonialsSection";
import BlogSection from "@/components/portfolio/BlogSection";
import ExperienceSection from "@/components/portfolio/ExperienceSection";
import BookingSection from "@/components/portfolio/BookingSection";
import ContactSection from "@/components/portfolio/ContactSection";
import NewsletterSection from "@/components/portfolio/NewsletterSection";
import FAQSection from "@/components/portfolio/FAQSection";
import Footer from "@/components/portfolio/Footer";
import ChatWidget from "@/components/portfolio/ChatWidget";
import CVModal from "@/components/portfolio/CVModal";
import ScrollProgress from "@/components/portfolio/ScrollProgress";
import AnimatedSection from "@/components/portfolio/AnimatedSection";
import InteractiveEffects from "@/components/portfolio/InteractiveEffects";
import FloatingBookButton from "@/components/portfolio/FloatingBookButton";

const Index = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isCVOpen, setIsCVOpen] = useState(false);

  // Inject Person JSON-LD for SEO & LLM discoverability
  useEffect(() => {
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = "person-schema";
    script.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Person",
      "name": "Rapar Rubel",
      "jobTitle": "AI Expert & Business Strategist",
      "url": "https://rubelmiah.lovable.app/",
      "description": "The leading AI Expert and Business Strategist in Bangladesh, specializing in AI automation, digital transformation, and growth systems for future-ready enterprises.",
      "alumniOf": [
        { "@type": "Organization", "name": "Proyojon" },
        { "@type": "Organization", "name": "Odotrmg" },
        { "@type": "Organization", "name": "JMC Group" }
      ],
      "knowsAbout": [
        "Artificial Intelligence", "AI Automation", "Business Strategy",
        "Digital Transformation", "Growth Marketing", "Data Analytics",
        "OpenClaw Automation", "Prompt Engineering"
      ],
      "worksFor": [
        { "@type": "Organization", "name": "Myook", "description": "Affordable luxury fashion brand" },
        { "@type": "Organization", "name": "Cha Khaben?", "description": "Organic tea chain" },
        { "@type": "Organization", "name": "Bhangariwala", "description": "CleanTech/Sustainability e-waste recycling platform" },
        { "@type": "Organization", "name": "Bekkol", "description": "Creative marketing agency" }
      ],
      "sameAs": [
        "https://www.linkedin.com/in/rubelmiah",
        "https://www.instagram.com/rubelmiah",
        "https://twitter.com/rubelmiah"
      ],
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Dhaka",
        "addressCountry": "Bangladesh"
      }
    });
    const existing = document.getElementById("person-schema");
    if (existing) existing.remove();
    document.head.appendChild(script);
    return () => {
      const el = document.getElementById("person-schema");
      if (el) el.remove();
    };
  }, []);

  const handleChatToggle = () => {
    setIsChatOpen(!isChatOpen);
  };

  const handleDownloadCV = () => {
    setIsCVOpen(true);
  };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <ScrollProgress />
      <Navbar onChatToggle={handleChatToggle} onDownloadCV={handleDownloadCV} />
      
      <AnimatedSection direction="up" delay={0.2}>
        <HeroSection onChatToggle={handleChatToggle} onDownloadCV={handleDownloadCV} />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <ExpertiseSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <SkillsSection />
      </AnimatedSection>
      
      {/* Booking placed early - marketing psychology: capture interest while engagement is high */}
      <AnimatedSection direction="up" delay={0.1}>
        <BookingSection />
      </AnimatedSection>
      
      <AnimatedSection direction="left" delay={0.1}>
        <VenturesSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <ProjectsSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <TestimonialsSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <BlogSection />
      </AnimatedSection>
      
      <AnimatedSection direction="right" delay={0.1}>
        <ExperienceSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <NewsletterSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <FAQSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <ContactSection />
      </AnimatedSection>
      
      <AnimatedSection direction="up" delay={0.1}>
        <Footer />
      </AnimatedSection>
      
      <ChatWidget isOpen={isChatOpen} onToggle={handleChatToggle} />
      <CVModal isOpen={isCVOpen} onClose={() => setIsCVOpen(false)} />
      <InteractiveEffects />
      <FloatingBookButton />
    </div>
  );
};

export default Index;
