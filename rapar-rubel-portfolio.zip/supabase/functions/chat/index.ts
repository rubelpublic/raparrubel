import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const getSystemPrompt = (language: string = "English", additionalPrompts: string[] = []) => {
  const basePrompt = `You are Rubel's AI assistant on his personal portfolio website. You are knowledgeable, professional, and helpful.
IMPORTANT: Always respond in ${language}. The user has selected this as their preferred language.

About Rubel:
- Multidisciplinary strategist and systems thinker
- 6+ years in business development, startup growth, and tech ecosystems
- Expert in AI Automation, Marketing Strategy, Software & Product Development
- Founder of multiple ventures: Myook (fashion brand), Cha Khaben? (tea chain), Bhangariwala (e-waste recycling), Bekkol (marketplace)
- Currently: Head of Business Development at JEEON Ltd, Co-Founder at Myook
- Previous: Business Development at JEEON Ltd, Strategy Consultant at Aimon Agency
- Education: BBA from East West University, Major in Marketing
- Contact: rubel.public@gmail.com, +880 1676 464807
- Location: Dhaka, Bangladesh
- LinkedIn: linkedin.com/in/rubelkhan/

Your role:
- Answer questions about Rubel's experience, ventures, and expertise
- Help visitors understand his services: AI Automation, Business Strategy, Digital Marketing
- Guide potential clients or collaborators to book meetings
- Be conversational but professional
- Keep responses concise but informative (2-3 sentences when possible)
- If asked about hiring or collaboration, encourage them to reach out via email or the provided contact details
- ALWAYS respond in ${language}, regardless of what language the user types in

IMPORTANT - Web Crawling & Search Capabilities:
You have access to web crawling and search tools. When users ask you to:
- "Scrape", "crawl", or "get content from" a URL → Use the scrape tool
- "Search" or "find information about" something on the web → Use the search tool
- "What does [website] say about..." → Use the scrape tool

When you need to use these tools, respond with a special JSON format:
{"tool": "scrape", "url": "https://example.com"} or {"tool": "search", "query": "search terms"}

After receiving tool results, summarize them helpfully for the user in ${language}.`;

  if (additionalPrompts.length > 0) {
    return basePrompt + "\n\nADDITIONAL CAPABILITIES:\n" + additionalPrompts.join("\n\n");
  }

  return basePrompt;
};

// Custom API interface
interface CustomApi {
  id: string;
  name: string;
  description: string;
  apiUrl: string;
  apiKey: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers: Record<string, string>;
  bodyTemplate: string;
  responseParser: string;
  enabled: boolean;
  category: 'ai' | 'scraper' | 'search' | 'tool' | 'webhook' | 'database';
}

interface AgenticCapability {
  id: string;
  name: string;
  description: string;
  triggerKeywords: string[];
  apiId: string;
  enabled: boolean;
  systemPromptAddition: string;
}

// Helper function to parse JSON path
function getNestedValue(obj: any, path: string): any {
  if (!path) return obj;
  const parts = path.split('.').map(p => {
    const match = p.match(/^(\w+)\[(\d+)\]$/);
    if (match) return { key: match[1], index: parseInt(match[2]) };
    return { key: p, index: null };
  });

  let current = obj;
  for (const part of parts) {
    if (current === null || current === undefined) return null;
    current = current[part.key];
    if (part.index !== null && Array.isArray(current)) {
      current = current[part.index];
    }
  }
  return current;
}

// Helper function to replace template variables
function replaceTemplateVariables(template: string, message: string, context: string): string {
  return template
    .replace(/\{\{message\}\}/g, message)
    .replace(/\{\{context\}\}/g, context);
}

// Call a custom API
async function callCustomApiEndpoint(api: CustomApi, message: string, context: string): Promise<string> {
  console.log(`Calling custom API: ${api.name} (${api.category})`);
  
  try {
    const headers: Record<string, string> = { ...api.headers };
    if (api.apiKey) {
      headers['Authorization'] = `Bearer ${api.apiKey}`;
    }

    const bodyContent = replaceTemplateVariables(api.bodyTemplate, message, context);
    
    const response = await fetch(api.apiUrl, {
      method: api.method,
      headers,
      body: api.method !== 'GET' ? bodyContent : undefined,
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => '');
      console.error(`Custom API ${api.name} error:`, response.status, errorText);
      return `Error calling ${api.name}: ${response.status}`;
    }

    const data = await response.json().catch(() => response.text());
    const result = api.responseParser ? getNestedValue(data, api.responseParser) : data;
    
    return typeof result === 'string' ? result : JSON.stringify(result, null, 2);
  } catch (error) {
    console.error(`Error calling custom API ${api.name}:`, error);
    return `Error: ${error instanceof Error ? error.message : 'Unknown error'}`;
  }
}

// Detect if a message triggers any agentic capability
function detectAgenticIntent(
  message: string, 
  capabilities: AgenticCapability[]
): AgenticCapability | null {
  const lowerMsg = message.toLowerCase();
  
  for (const capability of capabilities) {
    if (!capability.enabled) continue;
    
    for (const keyword of capability.triggerKeywords) {
      if (lowerMsg.includes(keyword.toLowerCase())) {
        console.log(`Detected agentic capability: ${capability.name} (keyword: ${keyword})`);
        return capability;
      }
    }
  }
  
  return null;
}

// Helper function to detect if user wants to use Firecrawl
function detectFirecrawlIntent(message: string): { tool: string; param: string } | null {
  const lowerMsg = message.toLowerCase();
  
  // Detect scrape/crawl intent
  const scrapePatterns = [
    /(?:scrape|crawl|get content from|fetch|extract from|read|check)\s+(?:the\s+)?(?:website\s+)?(?:at\s+)?(?:url\s+)?["']?(https?:\/\/[^\s"']+|www\.[^\s"']+|[a-z0-9-]+\.[a-z]{2,}[^\s"']*)/i,
    /(?:what does|what's on|show me|tell me about)\s+(?:the\s+)?(?:website\s+)?["']?(https?:\/\/[^\s"']+|www\.[^\s"']+)/i,
  ];
  
  for (const pattern of scrapePatterns) {
    const match = message.match(pattern);
    if (match && match[1]) {
      let url = match[1];
      if (!url.startsWith('http')) url = 'https://' + url;
      return { tool: 'scrape', param: url };
    }
  }
  
  // Detect search intent
  if (lowerMsg.includes('search') || lowerMsg.includes('find on the web') || lowerMsg.includes('look up online')) {
    const searchPatterns = [
      /(?:search|find|look up|google|research)\s+(?:for\s+)?(?:information\s+)?(?:about\s+)?(?:on\s+)?["']?(.+?)["']?$/i,
      /(?:what is|who is|what are|tell me about)\s+(.+?)(?:\?|$)/i,
    ];
    
    for (const pattern of searchPatterns) {
      const match = message.match(pattern);
      if (match && match[1] && match[1].length > 3) {
        return { tool: 'search', param: match[1].trim() };
      }
    }
  }
  
  return null;
}

// Function to call Firecrawl
async function callFirecrawl(tool: string, param: string): Promise<string> {
  const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");
  
  if (!FIRECRAWL_API_KEY) {
    return "Web crawling is not available at the moment.";
  }
  
  try {
    if (tool === 'scrape') {
      console.log("Scraping URL:", param);
      const response = await fetch("https://api.firecrawl.dev/v1/scrape", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${FIRECRAWL_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: param,
          formats: ["markdown"],
          onlyMainContent: true,
        }),
      });
      
      const data = await response.json();
      if (!response.ok || !data.success) {
        return `Failed to scrape the website: ${data.error || 'Unknown error'}`;
      }
      
      const content = data.data?.markdown || data.markdown || '';
      const title = data.data?.metadata?.title || data.metadata?.title || param;
      
      const maxLength = 4000;
      const truncatedContent = content.length > maxLength 
        ? content.substring(0, maxLength) + "\n\n[Content truncated...]"
        : content;
      
      return `**Scraped content from "${title}":**\n\n${truncatedContent}`;
    } else if (tool === 'search') {
      console.log("Searching for:", param);
      const response = await fetch("https://api.firecrawl.dev/v1/search", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${FIRECRAWL_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: param,
          limit: 5,
          scrapeOptions: { formats: ["markdown"] },
        }),
      });
      
      const data = await response.json();
      if (!response.ok || !data.success) {
        return `Failed to search: ${data.error || 'Unknown error'}`;
      }
      
      const results = data.data || [];
      if (results.length === 0) {
        return `No results found for "${param}".`;
      }
      
      let searchResults = `**Search results for "${param}":**\n\n`;
      results.slice(0, 3).forEach((result: any, index: number) => {
        const title = result.title || result.metadata?.title || 'Untitled';
        const url = result.url || result.metadata?.sourceURL || '';
        const snippet = result.markdown?.substring(0, 300) || result.description || '';
        searchResults += `${index + 1}. **${title}**\n   ${url}\n   ${snippet}...\n\n`;
      });
      
      return searchResults;
    }
  } catch (error) {
    console.error("Firecrawl error:", error);
    return `Error using web tools: ${error instanceof Error ? error.message : 'Unknown error'}`;
  }
  
  return "Unknown tool requested.";
}

// API Provider Types
type ApiProvider = 'gemini' | 'openai' | 'anthropic' | 'mistral' | 'cohere' | 'groq' | 'together' | 'perplexity' | 'unknown';

// Detect API type from key format
function detectApiType(apiKey: string): ApiProvider {
  if (apiKey.startsWith('AIza')) return 'gemini';
  if (apiKey.startsWith('sk-ant-')) return 'anthropic';
  if (apiKey.startsWith('mistral-') || apiKey.length === 32) return 'mistral';
  if (apiKey.startsWith('co-') || apiKey.length === 40) return 'cohere';
  if (apiKey.startsWith('gsk_')) return 'groq';
  if (apiKey.length === 64 || apiKey.startsWith('together-')) return 'together';
  if (apiKey.startsWith('pplx-')) return 'perplexity';
  if (apiKey.startsWith('sk-')) return 'openai';
  return 'unknown';
}

// Call custom API based on type
async function callCustomApi(
  apiKey: string, 
  apiType: ApiProvider, 
  messages: any[], 
  systemPrompt: string
): Promise<Response> {
  console.log(`Using custom API: ${apiType}`);
  
  if (apiType === 'gemini') {
    const geminiMessages = messages.map((m: any) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));
    
    const requestBody = {
      contents: geminiMessages,
      systemInstruction: {
        parts: [{ text: systemPrompt }]
      },
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 2048,
      }
    };
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:streamGenerateContent?alt=sse&key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      }
    );
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API error:", response.status, errorText);
      throw new Error(`Gemini API error: ${response.status}`);
    }
    
    const transformStream = new TransformStream({
      transform(chunk, controller) {
        const text = new TextDecoder().decode(chunk);
        const lines = text.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              const content = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
              if (content) {
                const openaiFormat = {
                  choices: [{ delta: { content } }]
                };
                controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(openaiFormat)}\n\n`));
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      },
      flush(controller) {
        controller.enqueue(new TextEncoder().encode('data: [DONE]\n\n'));
      }
    });
    
    return new Response(response.body?.pipeThrough(transformStream), {
      headers: { "Content-Type": "text/event-stream" }
    });
  } else if (apiType === 'openai') {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("OpenAI API error:", response.status, errorText);
      throw new Error(`OpenAI API error: ${response.status}`);
    }
    
    return response;
  } else if (apiType === 'anthropic') {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-3-haiku-20240307",
        max_tokens: 2048,
        system: systemPrompt,
        messages: messages,
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Anthropic API error:", response.status, errorText);
      throw new Error(`Anthropic API error: ${response.status}`);
    }
    
    const transformStream = new TransformStream({
      transform(chunk, controller) {
        const text = new TextDecoder().decode(chunk);
        const lines = text.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.type === 'content_block_delta' && data.delta?.text) {
                const openaiFormat = {
                  choices: [{ delta: { content: data.delta.text } }]
                };
                controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(openaiFormat)}\n\n`));
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      },
      flush(controller) {
        controller.enqueue(new TextEncoder().encode('data: [DONE]\n\n'));
      }
    });
    
    return new Response(response.body?.pipeThrough(transformStream), {
      headers: { "Content-Type": "text/event-stream" }
    });
  } else if (apiType === 'mistral') {
    const response = await fetch("https://api.mistral.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "mistral-small-latest",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Mistral API error:", response.status, errorText);
      throw new Error(`Mistral API error: ${response.status}`);
    }
    
    return response;
  } else if (apiType === 'cohere') {
    const response = await fetch("https://api.cohere.ai/v1/chat", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "command-r",
        message: messages[messages.length - 1]?.content || "",
        preamble: systemPrompt,
        chat_history: messages.slice(0, -1).map((m: any) => ({
          role: m.role === 'assistant' ? 'CHATBOT' : 'USER',
          message: m.content
        })),
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Cohere API error:", response.status, errorText);
      throw new Error(`Cohere API error: ${response.status}`);
    }
    
    const transformStream = new TransformStream({
      transform(chunk, controller) {
        const text = new TextDecoder().decode(chunk);
        const lines = text.split('\n');
        
        for (const line of lines) {
          if (line.trim()) {
            try {
              const data = JSON.parse(line);
              if (data.event_type === 'text-generation' && data.text) {
                const openaiFormat = {
                  choices: [{ delta: { content: data.text } }]
                };
                controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(openaiFormat)}\n\n`));
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      },
      flush(controller) {
        controller.enqueue(new TextEncoder().encode('data: [DONE]\n\n'));
      }
    });
    
    return new Response(response.body?.pipeThrough(transformStream), {
      headers: { "Content-Type": "text/event-stream" }
    });
  } else if (apiType === 'groq') {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3.1-8b-instant",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Groq API error:", response.status, errorText);
      throw new Error(`Groq API error: ${response.status}`);
    }
    
    return response;
  } else if (apiType === 'together') {
    const response = await fetch("https://api.together.xyz/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "meta-llama/Llama-3-8b-chat-hf",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Together API error:", response.status, errorText);
      throw new Error(`Together API error: ${response.status}`);
    }
    
    return response;
  } else if (apiType === 'perplexity') {
    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3.1-sonar-small-128k-online",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Perplexity API error:", response.status, errorText);
      throw new Error(`Perplexity API error: ${response.status}`);
    }
    
    return response;
  }
  
  throw new Error("Unsupported API type");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, language = "English" } = await req.json();
    
    // Create Supabase client to fetch custom API key
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Check for custom API key and other settings
    let customApiKey: string | null = null;
    let chatbotEnabled = true;
    let selectedProvider: ApiProvider | null = null;
    let customApis: CustomApi[] = [];
    let agenticCapabilities: AgenticCapability[] = [];
    
    try {
      const [apiKeyRes, chatbotRes, providerRes, customApisRes, capabilitiesRes] = await Promise.all([
        supabase.from('site_settings').select('value').eq('key', 'custom_api_key').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'chatbot_enabled').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'selected_ai_provider').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'custom_apis').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'agentic_capabilities').maybeSingle(),
      ]);
      
      if (apiKeyRes.data?.value) {
        const keyValue = apiKeyRes.data.value;
        if (typeof keyValue === 'string' && keyValue.length > 10) {
          customApiKey = keyValue;
          console.log("Found custom API key, length:", customApiKey.length);
        }
      }
      
      if (chatbotRes.data?.value !== null && chatbotRes.data?.value !== undefined) {
        chatbotEnabled = Boolean(chatbotRes.data.value);
      }
      
      if (providerRes.data?.value && typeof providerRes.data.value === 'string') {
        selectedProvider = providerRes.data.value as ApiProvider;
        console.log("Selected provider:", selectedProvider);
      }
      
      if (customApisRes.data?.value && Array.isArray(customApisRes.data.value)) {
        customApis = customApisRes.data.value as unknown as CustomApi[];
        console.log("Loaded custom APIs:", customApis.length);
      }
      
      if (capabilitiesRes.data?.value && Array.isArray(capabilitiesRes.data.value)) {
        agenticCapabilities = capabilitiesRes.data.value as unknown as AgenticCapability[];
        console.log("Loaded agentic capabilities:", agenticCapabilities.length);
      }
    } catch (error) {
      console.log("Error fetching settings:", error);
    }
    
    // Check if chatbot is disabled
    if (!chatbotEnabled) {
      return new Response(JSON.stringify({ 
        error: "Chatbot is currently disabled by the administrator." 
      }), {
        status: 503,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get the last user message
    const lastMessage = messages[messages.length - 1];
    const userMessage = lastMessage?.content || "";
    
    // Build context from chat history
    const chatContext = messages.slice(0, -1).map((m: any) => `${m.role}: ${m.content}`).join('\n');
    
    // Check for agentic capabilities first
    const enabledCapabilities = agenticCapabilities.filter(c => c.enabled);
    const matchedCapability = detectAgenticIntent(userMessage, enabledCapabilities);
    
    let augmentedMessages = [...messages];
    let additionalPrompts: string[] = [];
    
    if (matchedCapability) {
      const linkedApi = customApis.find(api => api.id === matchedCapability.apiId && api.enabled);
      
      if (linkedApi) {
        console.log(`Executing agentic capability: ${matchedCapability.name} with API: ${linkedApi.name}`);
        
        const apiResult = await callCustomApiEndpoint(linkedApi, userMessage, chatContext);
        
        augmentedMessages = [
          ...messages.slice(0, -1),
          {
            role: "user",
            content: `${userMessage}\n\n---\n**${matchedCapability.name} Result (from ${linkedApi.name}):**\n${apiResult}\n---\n\nPlease process this data and respond helpfully to the user.`
          }
        ];
        
        if (matchedCapability.systemPromptAddition) {
          additionalPrompts.push(matchedCapability.systemPromptAddition);
        }
      }
    }
    
    // Check if user wants to use Firecrawl
    const firecrawlIntent = detectFirecrawlIntent(userMessage);
    
    if (firecrawlIntent && augmentedMessages.length === messages.length) {
      console.log("Detected Firecrawl intent:", firecrawlIntent);
      
      const firecrawlResult = await callFirecrawl(firecrawlIntent.tool, firecrawlIntent.param);
      
      augmentedMessages = [
        ...messages.slice(0, -1),
        {
          role: "user",
          content: `${userMessage}\n\n---\n**Web Data Retrieved:**\n${firecrawlResult}\n---\n\nPlease summarize and present this information helpfully to the user.`
        }
      ];
    }

    console.log("Processing chat request with", augmentedMessages.length, "messages in", language);
    
    const systemPrompt = getSystemPrompt(language, additionalPrompts);

    // Try custom API first if available
    if (customApiKey) {
      const apiType = selectedProvider || detectApiType(customApiKey);
      console.log("Detected/Selected API type:", apiType);
      
      if (apiType !== 'unknown') {
        try {
          const customResponse = await callCustomApi(customApiKey, apiType, augmentedMessages, systemPrompt);
          return new Response(customResponse.body, {
            headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
          });
        } catch (error) {
          console.error("Custom API failed, falling back to Lovable AI:", error);
        }
      } else {
        console.log("Unknown API key format, trying as Gemini...");
        try {
          const customResponse = await callCustomApi(customApiKey, 'gemini', augmentedMessages, systemPrompt);
          return new Response(customResponse.body, {
            headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
          });
        } catch (error) {
          console.error("Gemini attempt failed:", error);
        }
      }
    }

    // Fallback to Lovable AI
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!LOVABLE_API_KEY) {
      throw new Error("No API key available. Please configure a custom API key in Settings.");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...augmentedMessages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI service unavailable. Please configure a custom API key in admin settings." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "Failed to get AI response" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("chat error:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Unknown error" 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
