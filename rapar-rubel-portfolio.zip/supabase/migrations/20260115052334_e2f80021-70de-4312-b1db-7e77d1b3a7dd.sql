-- Create CV/Resume data table
CREATE TABLE public.cv_data (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name text NOT NULL DEFAULT 'Your Name',
  title text NOT NULL DEFAULT 'Your Professional Title',
  email text,
  phone text,
  location text,
  linkedin_url text,
  website_url text,
  photo_url text,
  summary text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV experience table
CREATE TABLE public.cv_experience (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_title text NOT NULL,
  company text NOT NULL,
  start_date text NOT NULL,
  end_date text,
  is_current boolean DEFAULT false,
  achievements text[] DEFAULT '{}',
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV education table
CREATE TABLE public.cv_education (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  degree text NOT NULL,
  institution text NOT NULL,
  year text,
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV certifications table
CREATE TABLE public.cv_certifications (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  issuer text,
  year text,
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV skills table
CREATE TABLE public.cv_skills (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  category text,
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV competencies table
CREATE TABLE public.cv_competencies (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title text NOT NULL,
  subtitle text,
  color text DEFAULT 'cyan',
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV ventures table
CREATE TABLE public.cv_ventures (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create CV languages table
CREATE TABLE public.cv_languages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  language text NOT NULL,
  proficiency text NOT NULL,
  display_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.cv_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_experience ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_education ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_certifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_competencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_ventures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cv_languages ENABLE ROW LEVEL SECURITY;

-- Anyone can view CV data (public resume)
CREATE POLICY "Anyone can view cv_data" ON public.cv_data FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_experience" ON public.cv_experience FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_education" ON public.cv_education FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_certifications" ON public.cv_certifications FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_skills" ON public.cv_skills FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_competencies" ON public.cv_competencies FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_ventures" ON public.cv_ventures FOR SELECT USING (true);
CREATE POLICY "Anyone can view cv_languages" ON public.cv_languages FOR SELECT USING (true);

-- Admins can manage all CV data
CREATE POLICY "Admins can manage cv_data" ON public.cv_data FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_experience" ON public.cv_experience FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_education" ON public.cv_education FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_certifications" ON public.cv_certifications FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_skills" ON public.cv_skills FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_competencies" ON public.cv_competencies FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_ventures" ON public.cv_ventures FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage cv_languages" ON public.cv_languages FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_cv_data_updated_at
  BEFORE UPDATE ON public.cv_data
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default CV data
INSERT INTO public.cv_data (full_name, title, email, phone, location, linkedin_url, website_url, summary)
VALUES (
  'RUBEL MIAH',
  'Business Strategist • AI Automation Expert • Operations Leader',
  'rubel.public@gmail.com',
  '+880 1676 464807',
  'Dhaka, Bangladesh',
  'linkedin.com/in/rubelmiah',
  'rubelmiah.com',
  'Multidisciplinary professional with 6+ years of experience bridging business vision and execution. Specializing in scaling brands, designing intelligent systems, and AI-driven workflow automation. Proven track record of launching and growing multiple ventures, delivering measurable business outcomes.'
);

-- Insert default experience
INSERT INTO public.cv_experience (job_title, company, start_date, end_date, is_current, achievements, display_order) VALUES
('Project & Operations Manager', 'Proyojon', '2021', NULL, true, ARRAY['Lead end-to-end project planning and execution', 'Design operational workflows increasing efficiency by 40%', 'Manage cross-functional teams and stakeholders'], 1),
('Product & System Strategist', 'Odotrmg', '2018', '2021', false, ARRAY['Strategic input on ERP/POS logic and architecture', 'Led MaintenanceMen product from concept to launch'], 2),
('Business Development Lead', 'JMC Group', '2015', '2018', false, ARRAY['Executed growth initiatives with 150% revenue increase', 'Built strategic partnerships and client relationships'], 3);

-- Insert default education
INSERT INTO public.cv_education (degree, institution, year, display_order) VALUES
('Bachelor''s in Marketing', 'National University, BD', NULL, 1);

-- Insert default certifications
INSERT INTO public.cv_certifications (name, issuer, display_order) VALUES
('Digital Marketing', 'BASIS', 1),
('Graphics Design', 'ICT Ministry', 2),
('Mobile App Dev', 'ICT Ministry', 3),
('Photography', 'Ghoori Learning', 4);

-- Insert default skills
INSERT INTO public.cv_skills (name, display_order) VALUES
('Figma', 1), ('Adobe Suite', 2), ('Notion', 3), ('Airtable', 4),
('Make/Zapier', 5), ('ChatGPT', 6), ('Claude AI', 7), ('Google Analytics', 8),
('Meta Ads', 9), ('Slack', 10), ('Trello', 11), ('Jira', 12);

-- Insert default competencies
INSERT INTO public.cv_competencies (title, subtitle, color, display_order) VALUES
('Business Strategy', 'Growth & Scalability', 'cyan', 1),
('AI & Automation', 'Workflow Design', 'purple', 2),
('Product Management', 'SaaS & UX', 'green', 3),
('Digital Marketing', 'Performance & Analytics', 'orange', 4);

-- Insert default ventures
INSERT INTO public.cv_ventures (name, description, display_order) VALUES
('Myook', 'Premium Fashion Brand', 1),
('Cha Khaben?', 'Premium Tea Chain', 2),
('Bhangariwala', 'Recycling Platform', 3),
('Bekkol', 'Creative Agency', 4);

-- Insert default languages
INSERT INTO public.cv_languages (language, proficiency, display_order) VALUES
('Bengali', 'Native', 1),
('English', 'Professional', 2),
('Hindi', 'Conversational', 3);