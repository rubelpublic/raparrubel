-- Drop the existing restrictive policies
DROP POLICY IF EXISTS "Anyone can view active services" ON public.services;
DROP POLICY IF EXISTS "Admins can view all services" ON public.services;
DROP POLICY IF EXISTS "Admins can manage services" ON public.services;

-- Create permissive policies (PERMISSIVE is the default)
CREATE POLICY "Anyone can view active services"
ON public.services
FOR SELECT
TO public
USING (active = true);

CREATE POLICY "Admins can view all services"
ON public.services
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage services"
ON public.services
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Also fix available_slots RLS policies
DROP POLICY IF EXISTS "Anyone can view active slots" ON public.available_slots;
DROP POLICY IF EXISTS "Admins can manage slots" ON public.available_slots;

CREATE POLICY "Anyone can view active slots"
ON public.available_slots
FOR SELECT
TO public
USING (is_active = true);

CREATE POLICY "Admins can manage slots"
ON public.available_slots
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));